[CmdletBinding()]
param(
    [string]$RepoRoot = (Get-Location).ProviderPath,
    [string]$RunSettingsPath = (Join-Path $RepoRoot 'tests/Pester.runsettings.psd1'),
    [string]$ConfigPath = (Join-Path $RepoRoot 'local-ci/ubuntu/config.yaml')
)
$ErrorActionPreference = 'Stop'
function Assert-FileExists {
    param([string]$Path,[string]$Description)
    if (-not (Test-Path -LiteralPath $Path)) {
        throw "[$Description] Required file '$Path' not found."
    }
}
Assert-FileExists -Path $RunSettingsPath -Description 'Pester runsettings'
$config = Import-PowerShellDataFile -LiteralPath $RunSettingsPath
if (-not $config.ContainsKey('Run') -or -not $config.Run.Path) {
    throw '[Pester] Run.Path not defined in runsettings.'
}
$paths = @()
foreach ($entry in $config.Run.Path) {
    $full = Resolve-Path -LiteralPath (Join-Path $RepoRoot $entry) -ErrorAction SilentlyContinue
    if (-not $full) {
        throw "[Pester] Run.Path entry '$entry' does not resolve under $RepoRoot."
    }
    $paths += $full.ProviderPath
}
Write-Host "[Intent] Pester paths:"
$paths | ForEach-Object { Write-Host "  - $_" }
$tagFilters = @($config.Filter.Tag)
if ($tagFilters -and $tagFilters.Count -gt 0) {
    Write-Host "[Intent] Tag filters enabled: $($tagFilters -join ', ')"
} else {
    Write-Host '[Intent] No tag filters configured.'
}
Assert-FileExists -Path $ConfigPath -Description 'Ubuntu config'
function Convert-FromYamlFile {
    param([string]$Path)
    $module = Get-Module -Name powershell-yaml -ListAvailable | Select-Object -First 1
    if (-not $module) {
        throw '[Config] Module powershell-yaml is required but not installed.'
    }
    Import-Module $module -ErrorAction Stop | Out-Null
    $yaml = Get-Content -LiteralPath $Path -Raw
    return ConvertFrom-Yaml -Yaml $yaml
}
$configObj = Convert-FromYamlFile -Path $ConfigPath
$viCompare = $configObj.vi_compare
if ($null -eq $viCompare) {
    throw "[Config] vi_compare block missing in $ConfigPath."
}
if ($viCompare.enabled -eq $false) {
    Write-Host '[Intent] VI compare disabled via config.'
} elseif ([string]::IsNullOrWhiteSpace($viCompare.requests_template)) {
    Write-Host '[Intent] VI compare enabled with generated stub requests.'
} else {
    $templatePath = Join-Path $RepoRoot $viCompare.requests_template
    Assert-FileExists -Path $templatePath -Description 'VI compare template'
    Write-Host "[Intent] VI compare requests template: $templatePath"
}
Write-Host '[Intent] Tooling sanity checks completed successfully.'
