#Requires -Version 7.0
<#
.SYNOPSIS
  Consistent entry point for running the repository's Pester suite.

.DESCRIPTION
  Loads tests/Pester.runsettings.psd1, applies optional tag/exclude filters,
  and runs Invoke-Pester. When -CI is specified, writes JUnit output under
  out/test-results/pester.xml (creating the folder if needed).

.PARAMETER Tag
  Only run tests tagged with any of the specified values.

.PARAMETER ExcludeTag
  Skip tests tagged with any of the specified values.

.PARAMETER CI
  Enables JUnit output to out/test-results/pester.xml.
#>

[CmdletBinding()]
param(
  [string[]]$Tag,
  [string[]]$ExcludeTag,
  [switch]$CI
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repoRoot = Resolve-Path (Join-Path $PSScriptRoot '..')
$configPath = Join-Path $repoRoot 'tests' 'Pester.runsettings.psd1'
if (-not (Test-Path $configPath)) {
  throw "Pester configuration not found: $configPath"
}

$config = Import-PowerShellDataFile -LiteralPath $configPath

# Normalize relative paths based on repo root
$config.Run.Path = @(
  $config.Run.Path | ForEach-Object {
    (Resolve-Path (Join-Path $repoRoot $_)).ProviderPath
  }
)
$resolvedResultPath = Resolve-Path (Join-Path $repoRoot $config.TestResult.OutputPath) -ErrorAction SilentlyContinue
if ($resolvedResultPath) {
  $config.TestResult.OutputPath = $resolvedResultPath.ProviderPath
} else {
  $config.TestResult.OutputPath = Join-Path $repoRoot 'out/test-results/pester.xml'
}
if (-not $config.TestResult.OutputPath) {
  $config.TestResult.OutputPath = Join-Path $repoRoot 'out/test-results/pester.xml'
}

if ($Tag) {
  $config.Filter.Tag = @($Tag)
}
if ($ExcludeTag) {
  $config.Filter.ExcludeTag = @($ExcludeTag)
}

if ($CI) {
  $resultsPath = $config.TestResult.OutputPath
  $resultsDir = Split-Path $resultsPath -Parent
  if (-not (Test-Path $resultsDir)) { New-Item -ItemType Directory -Path $resultsDir -Force | Out-Null }
  $config.TestResult.Enabled = $true
  Write-Host "CI mode: writing Pester results to $resultsPath"
} else {
  $config.TestResult.Enabled = $false
}

Write-Host "Invoking Pester with tags: $($config.Filter.Tag -join ', ')" -ForegroundColor Cyan
Invoke-Pester -Configuration $config

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDYd2uoPAkTXPJb
# bn+j5BoktSlFrWLc2tx3vJ8l5hj/eaCCAxYwggMSMIIB+qADAgECAhBZKONVfS6W
# i05iXFP9t6Y5MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTE0MDAwODM3WhcNMjUxMTI4MDAxODM3WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA2mv1yIafoK62qhR5wk1l8+IbGIA3y+GJObRUgaSCecf6
# lcMWpZc1+oIeAKguEHIh1D7UVtLfoFMeC6wXJ2oojVJ4ShfBxsYcMvw8ab93QNV5
# 0MJLjXfParQYif+DXI1mzOEvzZQxX+G3WNohvgm5orBKT1SPCsEGBvLHch4N5vcJ
# neEzmz+aeJis7h6JhGcUcEDoGjZImPohi7qTNw20vDQJ0/pkDB879jShRepan3FB
# U+KZtgMe35YorD8Yn2KwyTwDV56+zDZXhtfWilnb5SI6NmdqmOfFP4u+OrDCWyKh
# 9Ha5k6lkAbetZLX8XW6dgA4zDJRuYHE8YktenosXOQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFJeEZsGgvnSO
# kABw2ReYtxwpT5mWMA0GCSqGSIb3DQEBCwUAA4IBAQCXdSQ5yOrMuLoxrb8Rnhjo
# i6QzqTkbvqmNsXWjo0+Akl1+JDUs2/WPmGSMRYyMyP9JOeuapPy4uhxyXDNBdjzJ
# Y4JU02cwDQV4fUs0Wud5lY432hGc+nwK6X25fIY6OOme+uEvzat3WZ8zdKH4A/pc
# 6I1zqJjgLYXZh2yu177ShEkY3dm8rvlltZpEciM7mzl5YHDNxna1h8kBVTO+ojPl
# 4mecjD+0M3OOhnhmwFtAkFb4oimG7vT+7L1yMKg5VSdzb0AS6UOXkWsrEKWBad1R
# c8oonPMXXsAtGshwJ2dsNyeYsc5PsAmE2pVRDuPXS4lRpslq5x7n3svEiT1oxmnH
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBZKONVfS6Wi05iXFP9t6Y5MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEII11SC6wt7Xz
# Nju6w2mLIcqzI70/iCgkEho6gi7yzw2NMA0GCSqGSIb3DQEBAQUABIIBAJacZvHG
# y1jzERUYkePVku9D5OMgJPcwcDM0ext8VW7ToyMXAhfpGa2TESTKf8rPXF48IYel
# niOSkX1oLocP4epzeoo7MiUOC6vMT82z8OSbs7QGTO/aGOB3B7gHxUmBCi/9IeQY
# 63Fjq6RiWSs9cKPTKkabpaxfS7diGwe5j8QVhtxkWF0/OqOcRvVJzCLsu67KkSrU
# zeC9s65owPNQHvrnfbYJc8p9MIG/YCs/0Ew1dwqaqTZTgxQtWPD5jxXyumqjD0qz
# EAH4kFNj2g7z/w/WaikpW+puv+GCaPE32RdxOEPuXIJHWGnbS7tx3MV2S09grNY0
# J7bxlAxDlpgzNO8=
# SIG # End signature block
