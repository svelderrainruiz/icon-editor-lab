#Requires -Version 7.0
[CmdletBinding()]
param(
    [string]$Root = 'out/semver-bundle'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$rootPath = [System.IO.Path]::GetFullPath($Root)
if (-not (Test-Path -LiteralPath $rootPath -PathType Container)) {
    throw "[SVB300] No SemVer bundles found under $rootPath"
}

$bundle = Get-ChildItem -LiteralPath $rootPath -Directory | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $bundle) {
    throw "[SVB300] No SemVer bundles found under $rootPath"
}

$summaryPath = Join-Path $bundle.FullName 'semver-summary.json'
$summary = $null
if (Test-Path -LiteralPath $summaryPath -PathType Leaf) {
    try {
        $summary = Get-Content -LiteralPath $summaryPath -Raw | ConvertFrom-Json -ErrorAction Stop
    } catch {
        Write-Warning ("[SVB202] Failed to read summary JSON: {0}" -f $_.Exception.Message)
    }
}

[pscustomobject]@{
    BundleRoot = $bundle.FullName
    ZipPath    = "$($bundle.FullName).zip"
    Summary    = $summary
}

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDX1yHpgv4n6QSq
# t5kkJikX+boV/u0FrptEuQebx9o3l6CCAxYwggMSMIIB+qADAgECAhBZKONVfS6W
# i05iXFP9t6Y5MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTE0MDAwODM3WhcNMjUxMTI4MDAxODM3WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA2mv1yIafoK62qhR5wk1l8+IbGIA3y+GJObRUgaSCecf6
# lcMWpZc1+oIeAKguEHIh1D7UVtLfoFMeC6wXJ2oojVJ4ShfBxsYcMvw8ab93QNV5
# 0MJLjXfParQYif+DXI1mzOEvzZQxX+G3WNohvgm5orBKT1SPCsEGBvLHch4N5vcJ
# neEzmz+aeJis7h6JhGcUcEDoGjZImPohi7qTNw20vDQJ0/pkDB879jShRepan3FB
# U+KZtgMe35YorD8Yn2KwyTwDV56+zDZXhtfWilnb5SI6NmdqmOfFP4u+OrDCWyKh
# 9Ha5k6lkAbetZLX8XW6dgA4zDJRuYHE8YktenosXOQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFJeEZsGgvnSO
# kABw2ReYtxwpT5mWMA0GCSqGSIb3DQEBCwUAA4IBAQCXdSQ5yOrMuLoxrb8Rnhjo
# i6QzqTkbvqmNsXWjo0+Akl1+JDUs2/WPmGSMRYyMyP9JOeuapPy4uhxyXDNBdjzJ
# Y4JU02cwDQV4fUs0Wud5lY432hGc+nwK6X25fIY6OOme+uEvzat3WZ8zdKH4A/pc
# 6I1zqJjgLYXZh2yu177ShEkY3dm8rvlltZpEciM7mzl5YHDNxna1h8kBVTO+ojPl
# 4mecjD+0M3OOhnhmwFtAkFb4oimG7vT+7L1yMKg5VSdzb0AS6UOXkWsrEKWBad1R
# c8oonPMXXsAtGshwJ2dsNyeYsc5PsAmE2pVRDuPXS4lRpslq5x7n3svEiT1oxmnH
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBZKONVfS6Wi05iXFP9t6Y5MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIEYBD5Y3r8tS
# z19YGGp/FTByrUm5EHI8CkcR3OTA0txvMA0GCSqGSIb3DQEBAQUABIIBAAQym+86
# 8Nvkcwv9YlOUpc+NcJcEog4AtqSeyt4BMPF4s9GnkGmAOopNRtp28XNL/UlhUyLi
# XWiM9OCgYnS0uo+lbdT5kZzMjuth9FhsGl4lf+AbpXTca7X/fHuhBipP1SCfARJj
# ISlhVal6UT3nnoEEq4Bt21EGwGR4t+wIWF5qaYegfx0RRFHpyds0RCD093W7L4pK
# /XZEcVlZ9dzJFDuO/q0yWRcoHw1KQ8pjIJs9U1YX8Uflh9sHqEC+WL/hGAiUU5Dj
# Aem6tuF1fQ9R60EVdt44eh8dh1ICkbmiToRHWHehsgT3SsnEP5C8k4JQ4/lcnoKM
# wXDD/MJvdEmi2qw=
# SIG # End signature block
