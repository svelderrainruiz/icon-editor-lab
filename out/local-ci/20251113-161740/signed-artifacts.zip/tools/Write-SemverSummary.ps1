#Requires -Version 7.0
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$BundleRoot,
    [switch]$WriteHost
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$bundleRoot = [System.IO.Path]::GetFullPath($BundleRoot)
if (-not (Test-Path -LiteralPath $bundleRoot -PathType Container)) {
    throw "Bundle root not found: $bundleRoot"
}

$summary = [ordered]@{
    schema      = 'icon-editor/semver-bundle-summary@v1'
    generatedAt = (Get-Date).ToString('o')
    bundleRoot  = $bundleRoot
    zipPath     = "$bundleRoot.zip"
    verified    = $true
}

$summaryPath = Join-Path $bundleRoot 'semver-summary.json'
$summary | ConvertTo-Json -Depth 4 | Out-File -FilePath $summaryPath -Encoding UTF8

if ($WriteHost) {
    Write-Host "[SemVerBundle] Summary"
    Write-Host ("  Bundle   : {0}" -f $bundleRoot)
    Write-Host ("  Zip      : {0}" -f "$bundleRoot.zip")
    Write-Host ("  Verified : {0}" -f $true)
    Write-Host ("  Summary  : {0}" -f $summaryPath)
}

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCv9pTtVq1odPNf
# nEfiuPuDX7rgU9AZjAmXsUzNPHHOOqCCAxYwggMSMIIB+qADAgECAhBZKONVfS6W
# i05iXFP9t6Y5MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTE0MDAwODM3WhcNMjUxMTI4MDAxODM3WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA2mv1yIafoK62qhR5wk1l8+IbGIA3y+GJObRUgaSCecf6
# lcMWpZc1+oIeAKguEHIh1D7UVtLfoFMeC6wXJ2oojVJ4ShfBxsYcMvw8ab93QNV5
# 0MJLjXfParQYif+DXI1mzOEvzZQxX+G3WNohvgm5orBKT1SPCsEGBvLHch4N5vcJ
# neEzmz+aeJis7h6JhGcUcEDoGjZImPohi7qTNw20vDQJ0/pkDB879jShRepan3FB
# U+KZtgMe35YorD8Yn2KwyTwDV56+zDZXhtfWilnb5SI6NmdqmOfFP4u+OrDCWyKh
# 9Ha5k6lkAbetZLX8XW6dgA4zDJRuYHE8YktenosXOQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFJeEZsGgvnSO
# kABw2ReYtxwpT5mWMA0GCSqGSIb3DQEBCwUAA4IBAQCXdSQ5yOrMuLoxrb8Rnhjo
# i6QzqTkbvqmNsXWjo0+Akl1+JDUs2/WPmGSMRYyMyP9JOeuapPy4uhxyXDNBdjzJ
# Y4JU02cwDQV4fUs0Wud5lY432hGc+nwK6X25fIY6OOme+uEvzat3WZ8zdKH4A/pc
# 6I1zqJjgLYXZh2yu177ShEkY3dm8rvlltZpEciM7mzl5YHDNxna1h8kBVTO+ojPl
# 4mecjD+0M3OOhnhmwFtAkFb4oimG7vT+7L1yMKg5VSdzb0AS6UOXkWsrEKWBad1R
# c8oonPMXXsAtGshwJ2dsNyeYsc5PsAmE2pVRDuPXS4lRpslq5x7n3svEiT1oxmnH
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBZKONVfS6Wi05iXFP9t6Y5MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPrmL4l37naI
# cuw6Hk+Z9Z0ioNWA4x/9X43uGcT1cTYyMA0GCSqGSIb3DQEBAQUABIIBAKksCJJ1
# ZLZ5Q2XSRT9HYe6pMdi+vEtW/xynrReKeZ5MzlsvyVBFRTdjdErYzz2cKdg7RbCn
# dLZ3a4aTFehEau5W2MNvZkNjpxqne9uWS6yOyd9C7X06qZ/tcOO7olyOTED2NjA4
# Y+1XAO77nBqOKhSP3wb4G5cCcYnpox2BSVAdRWy9AanqZWUbGwAzuTEj3fxnAiK5
# ksyM3rcs5BREgHeYGpPjkeyNnMqI5zLTRruI63Bfs4CUk7yGeFukiVA8sDB3e0CV
# n+xgyaqb2K1yvs3+lzepUYtB5gkzeziFHEADhN+/6vXpR7bAtgbT6081mcQDG6IK
# IMb6aBRxFj4CWKY=
# SIG # End signature block
