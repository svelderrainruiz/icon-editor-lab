# Secure-Process.psm1
Set-StrictMode -Version Latest
. (Join-Path $PSScriptRoot 'Validate-Paths.ps1')
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Invoke-ProcessSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$FilePath,
        [Parameter()][string[]]$ArgumentList = @(),
        [Parameter()][int]$TimeoutSec = 600,
        [Parameter()][string]$WorkingDirectory = (Get-Location).Path
    )
    if (-not (Test-Path -LiteralPath $FilePath -PathType Leaf)) { throw "FilePath not found: $FilePath" }
    $psi = [System.Diagnostics.ProcessStartInfo]::new()
    $psi.FileName = $FilePath
    $psi.WorkingDirectory = (Validate-PathSafe -Path $WorkingDirectory)
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.UseShellExecute = $false
    foreach ($a in $ArgumentList) { $null = $psi.ArgumentList.Add($a) }

    $p = [System.Diagnostics.Process]::new()
    $p.StartInfo = $psi
    if (-not $p.Start()) { throw "Failed to start process: $FilePath" }
    try {
        if (-not $p.WaitForExit($TimeoutSec * 1000)) {
            try { $p.Kill($true) } catch {}
            throw "Process timed out after $TimeoutSec s: $FilePath"
        }
        $stdout = $p.StandardOutput.ReadToEnd()
        $stderr = $p.StandardError.ReadToEnd()
        return [pscustomobject]@{
            ExitCode = $p.ExitCode
            StdOut = $stdout
            StdErr = $stderr
        }
    } finally {
        if (-not $p.HasExited) { try { $p.Kill($true) } catch {} }
        $p.Dispose()
    }
}
Export-ModuleMember -Function Invoke-ProcessSafe

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDLM/hZ77J6ko3k
# J1T1SnSI3Zjg9T8EF5sOyyHIvgXLgqCCAxYwggMSMIIB+qADAgECAhBZKONVfS6W
# i05iXFP9t6Y5MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTE0MDAwODM3WhcNMjUxMTI4MDAxODM3WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA2mv1yIafoK62qhR5wk1l8+IbGIA3y+GJObRUgaSCecf6
# lcMWpZc1+oIeAKguEHIh1D7UVtLfoFMeC6wXJ2oojVJ4ShfBxsYcMvw8ab93QNV5
# 0MJLjXfParQYif+DXI1mzOEvzZQxX+G3WNohvgm5orBKT1SPCsEGBvLHch4N5vcJ
# neEzmz+aeJis7h6JhGcUcEDoGjZImPohi7qTNw20vDQJ0/pkDB879jShRepan3FB
# U+KZtgMe35YorD8Yn2KwyTwDV56+zDZXhtfWilnb5SI6NmdqmOfFP4u+OrDCWyKh
# 9Ha5k6lkAbetZLX8XW6dgA4zDJRuYHE8YktenosXOQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFJeEZsGgvnSO
# kABw2ReYtxwpT5mWMA0GCSqGSIb3DQEBCwUAA4IBAQCXdSQ5yOrMuLoxrb8Rnhjo
# i6QzqTkbvqmNsXWjo0+Akl1+JDUs2/WPmGSMRYyMyP9JOeuapPy4uhxyXDNBdjzJ
# Y4JU02cwDQV4fUs0Wud5lY432hGc+nwK6X25fIY6OOme+uEvzat3WZ8zdKH4A/pc
# 6I1zqJjgLYXZh2yu177ShEkY3dm8rvlltZpEciM7mzl5YHDNxna1h8kBVTO+ojPl
# 4mecjD+0M3OOhnhmwFtAkFb4oimG7vT+7L1yMKg5VSdzb0AS6UOXkWsrEKWBad1R
# c8oonPMXXsAtGshwJ2dsNyeYsc5PsAmE2pVRDuPXS4lRpslq5x7n3svEiT1oxmnH
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBZKONVfS6Wi05iXFP9t6Y5MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPEK5pYr/oiP
# 6zXDh72ZtLHO5VLyj1aDMXhTjDbbSs4wMA0GCSqGSIb3DQEBAQUABIIBACh3HTUT
# OsN1pf9jEPEs44HktrnxJdm0NSbTL1WL6KDcR8lb+NHiEpr4A+hHytSdu8f65zUC
# CR0SUWC7/Q/4eZF/iopRAU5N9gsXy7PoJ+LFl5NL4xfvIjWzX8ZzANktNQicXFPI
# mtV6I0P23GXNZsJW9e0Z/v5Bda85AzH4MEf5m6sM89RokwtogbV3gBEha7GcYtl0
# PBbs6gg2OLz4ErhGexSjH5PIRc0UnCvAKdHl58MFicLm+38CCF0yEaEyW18JrM0j
# pfAdz/OT1PtExXCmUen3RXP2EwXzPJfpyaFZ9pZRwuOPQNuxLFvjH/hFO0FJJxQH
# Wg0hwF+RczqNsrg=
# SIG # End signature block
