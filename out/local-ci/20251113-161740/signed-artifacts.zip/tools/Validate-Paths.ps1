# Validate-Paths.ps1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Test-PathSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter()][switch]$RequireAbsolute
    )
    if ($Path -match '[;&|`]' -or $Path -match '\.\.') { return $false }
    try {
        $rp = Resolve-Path -LiteralPath $Path -ErrorAction Stop
        if ($RequireAbsolute -and -not ($rp.Path -match '^(?:[A-Za-z]:[\\/]|/)')) { return $false }
        return $true
    } catch { return $false }
}

function Validate-PathSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter()][switch]$RequireAbsolute
    )
    if (-not (Test-PathSafe -Path $Path -RequireAbsolute:$RequireAbsolute)) {
        throw "Unsafe or invalid path: $Path"
    }
    return (Resolve-Path -LiteralPath $Path).Path
}

Export-ModuleMember -Function Test-PathSafe, Validate-PathSafe

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBRKRGFgRiwJrUW
# ser+RbKUtmM3v2Ar6IG3lNNJMXHBxaCCAxYwggMSMIIB+qADAgECAhBZKONVfS6W
# i05iXFP9t6Y5MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTE0MDAwODM3WhcNMjUxMTI4MDAxODM3WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA2mv1yIafoK62qhR5wk1l8+IbGIA3y+GJObRUgaSCecf6
# lcMWpZc1+oIeAKguEHIh1D7UVtLfoFMeC6wXJ2oojVJ4ShfBxsYcMvw8ab93QNV5
# 0MJLjXfParQYif+DXI1mzOEvzZQxX+G3WNohvgm5orBKT1SPCsEGBvLHch4N5vcJ
# neEzmz+aeJis7h6JhGcUcEDoGjZImPohi7qTNw20vDQJ0/pkDB879jShRepan3FB
# U+KZtgMe35YorD8Yn2KwyTwDV56+zDZXhtfWilnb5SI6NmdqmOfFP4u+OrDCWyKh
# 9Ha5k6lkAbetZLX8XW6dgA4zDJRuYHE8YktenosXOQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFJeEZsGgvnSO
# kABw2ReYtxwpT5mWMA0GCSqGSIb3DQEBCwUAA4IBAQCXdSQ5yOrMuLoxrb8Rnhjo
# i6QzqTkbvqmNsXWjo0+Akl1+JDUs2/WPmGSMRYyMyP9JOeuapPy4uhxyXDNBdjzJ
# Y4JU02cwDQV4fUs0Wud5lY432hGc+nwK6X25fIY6OOme+uEvzat3WZ8zdKH4A/pc
# 6I1zqJjgLYXZh2yu177ShEkY3dm8rvlltZpEciM7mzl5YHDNxna1h8kBVTO+ojPl
# 4mecjD+0M3OOhnhmwFtAkFb4oimG7vT+7L1yMKg5VSdzb0AS6UOXkWsrEKWBad1R
# c8oonPMXXsAtGshwJ2dsNyeYsc5PsAmE2pVRDuPXS4lRpslq5x7n3svEiT1oxmnH
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBZKONVfS6Wi05iXFP9t6Y5MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEINpvsU+HHb6K
# gYnFC+DOD7Pi21ghNNfHTvYHF7x5UIBMMA0GCSqGSIb3DQEBAQUABIIBANdw0hex
# QTqJ1arcO6wYd1l5TY15eaBUA36TELOdmpw/D17X4XoRzmRQr6y5K4sv/fHfxPhU
# oybRP1jSgOEWMcClQjAeh9kaSW9jxJZAnEkQWWLDyPIrKwqEYR5e/0knLaPkYCgg
# RvJ2PP3hvmwnS2Xd7bhdj8mnYfy3bcVc03UGpQG3mlqZ11BiGiUr3Pekol6MxPFu
# mF18JXgIggmZD977ExjIUMfcD1OEyh8fGGNSq0Esl7i4KA+N1M+1o0ahXY7Wtmft
# gkJ7ADXuiOmO+sADpfRfm3WeOyUXjBZuIBNfwZWM1+AMPRRdEdoPPbPmDwdiMHZb
# hTdx5l4qtBryNng=
# SIG # End signature block
