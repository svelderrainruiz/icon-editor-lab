#Requires -Version 7.0
[CmdletBinding()]
param(
    [string]$Root = 'out/semver-bundle'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$rootPath = [System.IO.Path]::GetFullPath($Root)
if (-not (Test-Path -LiteralPath $rootPath -PathType Container)) {
    throw "[SVB300] No SemVer bundles found under $rootPath"
}

$bundle = Get-ChildItem -LiteralPath $rootPath -Directory | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $bundle) {
    throw "[SVB300] No SemVer bundles found under $rootPath"
}

$summaryPath = Join-Path $bundle.FullName 'semver-summary.json'
$summary = $null
if (Test-Path -LiteralPath $summaryPath -PathType Leaf) {
    try {
        $summary = Get-Content -LiteralPath $summaryPath -Raw | ConvertFrom-Json -ErrorAction Stop
    } catch {
        Write-Warning ("[SVB202] Failed to read summary JSON: {0}" -f $_.Exception.Message)
    }
}

[pscustomobject]@{
    BundleRoot = $bundle.FullName
    ZipPath    = "$($bundle.FullName).zip"
    Summary    = $summary
}

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDX1yHpgv4n6QSq
# t5kkJikX+boV/u0FrptEuQebx9o3l6CCAxYwggMSMIIB+qADAgECAhBZBMnA1IEQ
# rUoc5VTi/eQSMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMjEwOTQ2WhcNMjUxMTI3MjExOTQ2WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAzM/Tz+bDJhpbc2ctiygsTdoTO7Eer4BGzx5XqI088x+v
# 0IyhGzASdWiC3STh05h96RlSQOLbzotbwK0ADVKHI87OrkilknDP2n+efrX7BzNz
# TdbwCjNRtLctanjLGXQN1UVVKIRLDWlw7OsYr/MEGFtB+BZkT61RT8rDhN/WOecW
# xi0DG0uWB3yoGWVjI3NTPN5o7BT9K85hH1fcV/45XMNvNkgNpNgG8cIn/NVb+sJJ
# qG17D0ik7rHrskKqNPuaN6ZYTYWsOAZ3hgJft+aPhkUCpa6yvbTYLC2ZXl6ghPTW
# 3QpLUmMWu55HAxJGhddguTeohK+G2U7ENP4CB6akvQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFI9AcFJ2lQ4Q
# aeShYlIQPBdErEK3MA0GCSqGSIb3DQEBCwUAA4IBAQAPFUwwWu2Of1u/jRp1tYFY
# uukuYvTFtNoMFcLEmnfQndCJXXPxVDLzY1Y3A9O7VyMMI0QPZU9Id6mZhcICgRy1
# t8LTp3DJ7fA0Il37UV5AHBIiJDiBQb0X09nYPjXPHyfA/zBDchV5VJyiexIX4Xqv
# jGKCm1qZyJjUhTM8L9dGJctRVG/bQE7cZPFsZcYMSsJTFXyRVbspQFNaU/z9ZJ2U
# F7qqNhSCt8YpOPcwm6q0djj8gdjm4f2sFGohfbPDPO8gvIf7hSUUvDixegCq51La
# rmg8tm9ktx7l5vLICFMVwYZsmYH0vi1eAFxiKyITVBGh1dGC6Sge6JFolB38+ocS
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBZBMnA1IEQrUoc5VTi/eQSMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIEYBD5Y3r8tS
# z19YGGp/FTByrUm5EHI8CkcR3OTA0txvMA0GCSqGSIb3DQEBAQUABIIBAB4scdbP
# O5UhsK5kF5SkGCv54y3A46RKhwrv78JYcbt4Ykfqvnxy1HVvu7fNB8v9wb/gmu8r
# GZantetMvkxXPG0udsfqASk+O3U6IcczIToqZF4AIjxFxrfm9Q0sd/2TbnfNQeJf
# IV23IY1LXYqcM8jCXLPiIONPCN14BmkaCCCN8SADV4GUIBi16HagVWpuEAIE0r/M
# sVf5rQ3y7SvMg0zdGNu63ksBfhgfCZMTnR9sE14u9c7ZDkWlk1hTPpPk7sPBH+dk
# 6q0m0ejjsqQJGmxjcmoS3QYFUYl4kTD07OthIWC9BWeOu4dkDJ16W7HJkZLp+TVh
# +kh7t6yKD8Qixl8=
# SIG # End signature block
