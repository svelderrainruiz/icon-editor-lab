# EnvGuard.psm1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Get-EnvSnapshot {
    [CmdletBinding()]
    param([string[]]$AllowList = @('PATH','TEMP','TMP','HOME','USERPROFILE'))
    $snap = @{}
    foreach ($name in [Environment]::GetEnvironmentVariables().Keys) {
        if ($AllowList -contains $name) { $snap[$name] = [Environment]::GetEnvironmentVariable($name,'Process') }
    }
    return $snap
}

function Set-EnvFromSnapshot {
    [CmdletBinding()]
    param([Parameter(Mandatory)][hashtable]$Snapshot)
    foreach ($k in $Snapshot.Keys) {
        [Environment]::SetEnvironmentVariable($k, [string]$Snapshot[$k], 'Process')
    }
}

Export-ModuleMember -Function Get-EnvSnapshot, Set-EnvFromSnapshot

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAzwwfWBljXiDkz
# 9AHE9bg618B2oMEor3Mbt2BkcXsxKKCCAxYwggMSMIIB+qADAgECAhBZBMnA1IEQ
# rUoc5VTi/eQSMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMjEwOTQ2WhcNMjUxMTI3MjExOTQ2WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAzM/Tz+bDJhpbc2ctiygsTdoTO7Eer4BGzx5XqI088x+v
# 0IyhGzASdWiC3STh05h96RlSQOLbzotbwK0ADVKHI87OrkilknDP2n+efrX7BzNz
# TdbwCjNRtLctanjLGXQN1UVVKIRLDWlw7OsYr/MEGFtB+BZkT61RT8rDhN/WOecW
# xi0DG0uWB3yoGWVjI3NTPN5o7BT9K85hH1fcV/45XMNvNkgNpNgG8cIn/NVb+sJJ
# qG17D0ik7rHrskKqNPuaN6ZYTYWsOAZ3hgJft+aPhkUCpa6yvbTYLC2ZXl6ghPTW
# 3QpLUmMWu55HAxJGhddguTeohK+G2U7ENP4CB6akvQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFI9AcFJ2lQ4Q
# aeShYlIQPBdErEK3MA0GCSqGSIb3DQEBCwUAA4IBAQAPFUwwWu2Of1u/jRp1tYFY
# uukuYvTFtNoMFcLEmnfQndCJXXPxVDLzY1Y3A9O7VyMMI0QPZU9Id6mZhcICgRy1
# t8LTp3DJ7fA0Il37UV5AHBIiJDiBQb0X09nYPjXPHyfA/zBDchV5VJyiexIX4Xqv
# jGKCm1qZyJjUhTM8L9dGJctRVG/bQE7cZPFsZcYMSsJTFXyRVbspQFNaU/z9ZJ2U
# F7qqNhSCt8YpOPcwm6q0djj8gdjm4f2sFGohfbPDPO8gvIf7hSUUvDixegCq51La
# rmg8tm9ktx7l5vLICFMVwYZsmYH0vi1eAFxiKyITVBGh1dGC6Sge6JFolB38+ocS
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBZBMnA1IEQrUoc5VTi/eQSMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIJlQaYHytxsd
# hJ21/Xd1OOTWhUd4iNiRCRC/DDWxp9vgMA0GCSqGSIb3DQEBAQUABIIBAB9WPyNx
# xUk/MFmfu1Z9UV/e47JtXmQOgwjQ5tk3k1kSVhaIXkpkc8Okxw9sklGIrJjOZoJs
# 6+5Rda1ER0wiZWYz1oM0/jtMNGRnjaaZaQ/0S1xTebRUAOFqnyz8bH5NwsJYeFa0
# IFan2AldOGytl1b+OqcnmxCFdK7/pIZ8lPK27dlFvqbEXCHn9oeLSbjDNhewjfCj
# bl1yKmCKRSlPeYN1k6dQs3nuxC5me81o7YT654vRFTmP8Lx/Ie9Dm+E6jy0nvsPY
# YNRRJyWkaXy7wpiIbMaLasmU5WeUzAIFKKKaEBTn2NhYhw+gzbEaqjDRj8RDKZMj
# HLW6sF1k/RnKv0M=
# SIG # End signature block
