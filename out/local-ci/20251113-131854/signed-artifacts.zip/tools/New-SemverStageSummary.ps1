#Requires -Version 7.0
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$BundleRoot,
    [string]$Stage = 'SemVerBundle',
    [switch]$Verified,
    [string]$ErrorCode,
    [string]$ErrorMessage
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$bundleRootFull = [System.IO.Path]::GetFullPath($BundleRoot)
$summaryPath = Join-Path $bundleRootFull 'semver-summary.json'
if (-not (Test-Path -LiteralPath $summaryPath -PathType Leaf)) {
    throw "[SVB202] summary file not found at $summaryPath"
}
$summary = Get-Content -LiteralPath $summaryPath -Raw | ConvertFrom-Json -ErrorAction Stop

Write-Host "[SemVerBundle] Summary"
Write-Host ("  Stage    : {0}" -f $Stage)
Write-Host ("  Bundle   : {0}" -f $bundleRootFull)
Write-Host ("  Zip      : {0}" -f (Join-Path $bundleRootFull 'semver-bundle.zip'))
Write-Host ("  Verified : {0}" -f ($Verified.IsPresent ? $true : ($summary.verified ?? $false)))
if ($ErrorCode) {
    Write-Host ("  Error    : {0} {1}" -f $ErrorCode, $ErrorMessage) -ForegroundColor Yellow
}

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBIb5CN+Ok42ZjX
# JZj4HcLU5jYGdD8KcA5M4VekqCLxvKCCAxYwggMSMIIB+qADAgECAhBZBMnA1IEQ
# rUoc5VTi/eQSMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMjEwOTQ2WhcNMjUxMTI3MjExOTQ2WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAzM/Tz+bDJhpbc2ctiygsTdoTO7Eer4BGzx5XqI088x+v
# 0IyhGzASdWiC3STh05h96RlSQOLbzotbwK0ADVKHI87OrkilknDP2n+efrX7BzNz
# TdbwCjNRtLctanjLGXQN1UVVKIRLDWlw7OsYr/MEGFtB+BZkT61RT8rDhN/WOecW
# xi0DG0uWB3yoGWVjI3NTPN5o7BT9K85hH1fcV/45XMNvNkgNpNgG8cIn/NVb+sJJ
# qG17D0ik7rHrskKqNPuaN6ZYTYWsOAZ3hgJft+aPhkUCpa6yvbTYLC2ZXl6ghPTW
# 3QpLUmMWu55HAxJGhddguTeohK+G2U7ENP4CB6akvQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFI9AcFJ2lQ4Q
# aeShYlIQPBdErEK3MA0GCSqGSIb3DQEBCwUAA4IBAQAPFUwwWu2Of1u/jRp1tYFY
# uukuYvTFtNoMFcLEmnfQndCJXXPxVDLzY1Y3A9O7VyMMI0QPZU9Id6mZhcICgRy1
# t8LTp3DJ7fA0Il37UV5AHBIiJDiBQb0X09nYPjXPHyfA/zBDchV5VJyiexIX4Xqv
# jGKCm1qZyJjUhTM8L9dGJctRVG/bQE7cZPFsZcYMSsJTFXyRVbspQFNaU/z9ZJ2U
# F7qqNhSCt8YpOPcwm6q0djj8gdjm4f2sFGohfbPDPO8gvIf7hSUUvDixegCq51La
# rmg8tm9ktx7l5vLICFMVwYZsmYH0vi1eAFxiKyITVBGh1dGC6Sge6JFolB38+ocS
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBZBMnA1IEQrUoc5VTi/eQSMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIOgQhZBcSKfN
# v0yWWz7SAnyf864SJfmJdvgEMXm/Vmv5MA0GCSqGSIb3DQEBAQUABIIBAKG+eS/Q
# kMcDSgWA/NC4pSOt2LOx0dPSkbM08z3TyvjMQopVUe0WK0aJAz6eeLriKjh+90HM
# 7sTMRVwkv9vbngTLmrou7xkIiGc95UnH3rdtu/FtEclfTa+Pndq9WbjPJeJkTVKt
# ykvL0TIdaScypDA+Zu82DvHXRAGlbe+1u7f4eiv15tDrqWog5HIR841+Ic/Vwb9l
# 786SswO7casAP67vw6zPNQZGhT3i04Dr1j/WMM1kXFT18ShKr0qJWFd34LQDVjBh
# 20ARaT9thZ8p7Xl1hZvD60xz20yCXdKbFQhmH1w1APXuTE60umyuoRce+TcDJ6Cy
# VHGEakfFI6ntHjo=
# SIG # End signature block
