#Requires -Version 7.0
[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$BundlePath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Resolve-Manifest {
  param([string]$Path)
  if ((Test-Path -LiteralPath $Path -PathType Container)) {
    $candidate = Join-Path $Path 'bundle.json'
    if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) {
      throw "bundle.json not found under $Path"
    }
    return $candidate
  }
  if ((Test-Path -LiteralPath $Path -PathType Leaf) -and $Path.EndsWith('.zip')) {
    $tempDir = New-Item -ItemType Directory -Force -Path (Join-Path $env:TEMP "semver-bundle-$(Get-Random)")
    Expand-Archive -LiteralPath $Path -DestinationPath $tempDir -Force
    $manifest = Join-Path $tempDir 'bundle.json'
    if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) {
      throw "bundle.json missing inside archive $Path"
    }
    return $manifest
  }
  throw "Unsupported bundle path: $Path"
}

$manifestPath = Resolve-Manifest -Path $BundlePath
$bundleRoot = Split-Path -Parent $manifestPath
$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
$failures = @()

foreach ($file in $manifest.files) {
  $fullPath = Join-Path $bundleRoot $file.relativePath
  if (-not (Test-Path -LiteralPath $fullPath -PathType Leaf)) {
    $failures += "Missing file: $($file.relativePath)"
    continue
  }
  $hash = (Get-FileHash -LiteralPath $fullPath -Algorithm SHA256).Hash
  if ($hash -ne $file.sha256) {
    $failures += "Hash mismatch ($($file.relativePath)) expected $($file.sha256) actual $hash"
  }
}

if ($failures.Count -gt 0) {
  Write-Error "Bundle verification failed:" -ErrorAction Stop
}

Write-Host "Bundle verified successfully: $bundleRoot" -ForegroundColor Green

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDjr3yXkH4ndjxr
# 1Y11zhgNRCuKm1tcHCh7s0nCEGFYb6CCAxYwggMSMIIB+qADAgECAhBZBMnA1IEQ
# rUoc5VTi/eQSMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMjEwOTQ2WhcNMjUxMTI3MjExOTQ2WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAzM/Tz+bDJhpbc2ctiygsTdoTO7Eer4BGzx5XqI088x+v
# 0IyhGzASdWiC3STh05h96RlSQOLbzotbwK0ADVKHI87OrkilknDP2n+efrX7BzNz
# TdbwCjNRtLctanjLGXQN1UVVKIRLDWlw7OsYr/MEGFtB+BZkT61RT8rDhN/WOecW
# xi0DG0uWB3yoGWVjI3NTPN5o7BT9K85hH1fcV/45XMNvNkgNpNgG8cIn/NVb+sJJ
# qG17D0ik7rHrskKqNPuaN6ZYTYWsOAZ3hgJft+aPhkUCpa6yvbTYLC2ZXl6ghPTW
# 3QpLUmMWu55HAxJGhddguTeohK+G2U7ENP4CB6akvQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFI9AcFJ2lQ4Q
# aeShYlIQPBdErEK3MA0GCSqGSIb3DQEBCwUAA4IBAQAPFUwwWu2Of1u/jRp1tYFY
# uukuYvTFtNoMFcLEmnfQndCJXXPxVDLzY1Y3A9O7VyMMI0QPZU9Id6mZhcICgRy1
# t8LTp3DJ7fA0Il37UV5AHBIiJDiBQb0X09nYPjXPHyfA/zBDchV5VJyiexIX4Xqv
# jGKCm1qZyJjUhTM8L9dGJctRVG/bQE7cZPFsZcYMSsJTFXyRVbspQFNaU/z9ZJ2U
# F7qqNhSCt8YpOPcwm6q0djj8gdjm4f2sFGohfbPDPO8gvIf7hSUUvDixegCq51La
# rmg8tm9ktx7l5vLICFMVwYZsmYH0vi1eAFxiKyITVBGh1dGC6Sge6JFolB38+ocS
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBZBMnA1IEQrUoc5VTi/eQSMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEILQuIDyMgfaK
# B382xHdCDlgpFW4Gkiy8p3BaoHKMRV6AMA0GCSqGSIb3DQEBAQUABIIBAEE/TPhe
# sY7DF6pZv1o4yO2AnuAQ8N3w1aMg8VzJW7HBj85Fa5GaaeIgN6dZwTPV26+9UU6i
# Zqm+lomrmF1XXbbJ13SgWoTcnnS/toXWzfuBaOGtx59f4L2WO0ioLOKCZ+Km8jhk
# irN2undSbIIH4Mpx53p8ytfGvqBAVSnC4Pf7HJ8Jh5ffl8jhmz7Aic1wQyHeQoWw
# C1BvaOtlu70J6y6oFT7LIt4kRWgidk9SzcVaIGNJGqwfKWFEPoITTNUISMUR5y5z
# +1EaX0w4iwUI/4j28WVkiYERLOjF4QFQ+IKo44O5tSZzzg+7etJCExyzkGzYrHm8
# my7p9bZlRYiRGks=
# SIG # End signature block
