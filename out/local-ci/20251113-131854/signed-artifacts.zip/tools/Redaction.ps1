# Redaction.ps1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Write-LogSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Message,
        [Parameter()][ValidateSet('INFO','WARN','ERROR')][string]$Level = 'INFO'
    )
    # Redact common secret/token patterns (simple heuristic)
    $msg = $Message -replace '([A-Za-z0-9-_]{20,})','****' `
                    -replace '(?i)(secret|token|password)\s*[:=]\s*[^ \t\r\n]+','$1=****'
    $ts = (Get-Date).ToString('s')
    Write-Output "[$ts][$Level] $msg"
}
if ($ExecutionContext.SessionState.Module) {
    Export-ModuleMember -Function Write-LogSafe
}

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCB5QE8/zfwZTTR5
# g9if2C7NwESBApxi1XkQIcw6fBWi3aCCAxYwggMSMIIB+qADAgECAhBZBMnA1IEQ
# rUoc5VTi/eQSMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMjEwOTQ2WhcNMjUxMTI3MjExOTQ2WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAzM/Tz+bDJhpbc2ctiygsTdoTO7Eer4BGzx5XqI088x+v
# 0IyhGzASdWiC3STh05h96RlSQOLbzotbwK0ADVKHI87OrkilknDP2n+efrX7BzNz
# TdbwCjNRtLctanjLGXQN1UVVKIRLDWlw7OsYr/MEGFtB+BZkT61RT8rDhN/WOecW
# xi0DG0uWB3yoGWVjI3NTPN5o7BT9K85hH1fcV/45XMNvNkgNpNgG8cIn/NVb+sJJ
# qG17D0ik7rHrskKqNPuaN6ZYTYWsOAZ3hgJft+aPhkUCpa6yvbTYLC2ZXl6ghPTW
# 3QpLUmMWu55HAxJGhddguTeohK+G2U7ENP4CB6akvQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFI9AcFJ2lQ4Q
# aeShYlIQPBdErEK3MA0GCSqGSIb3DQEBCwUAA4IBAQAPFUwwWu2Of1u/jRp1tYFY
# uukuYvTFtNoMFcLEmnfQndCJXXPxVDLzY1Y3A9O7VyMMI0QPZU9Id6mZhcICgRy1
# t8LTp3DJ7fA0Il37UV5AHBIiJDiBQb0X09nYPjXPHyfA/zBDchV5VJyiexIX4Xqv
# jGKCm1qZyJjUhTM8L9dGJctRVG/bQE7cZPFsZcYMSsJTFXyRVbspQFNaU/z9ZJ2U
# F7qqNhSCt8YpOPcwm6q0djj8gdjm4f2sFGohfbPDPO8gvIf7hSUUvDixegCq51La
# rmg8tm9ktx7l5vLICFMVwYZsmYH0vi1eAFxiKyITVBGh1dGC6Sge6JFolB38+ocS
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBZBMnA1IEQrUoc5VTi/eQSMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIEfHLCIlw9Py
# EI3fUHQlFhw4tq7Q+oRZQIlIetQ/aFBMMA0GCSqGSIb3DQEBAQUABIIBAGJtWOnY
# t6MpD261U9m9hfXuRkC5Ng2LUquFamTar3UGdvEsFQ5Duj4IY+hW7ZgLAc6OYdjs
# bTrS/kfrzpvdQbZr94D9ZqGC04peIC4Wo3ec410YCrU9zOlVT6U8KXPfPNat+1Ko
# 6k3lBK2qweoBzvVnSgTM3mpOW7o0EZA9OGnrw5WqCx1Xj7z2Vn44giD2Q1Hio8mM
# PwwWwTOq2ZKkETVqxyFmxR5YYoUcRg3mCLLHPkUKsbOqnnqIYfDuTayf0j5rIHcA
# wifJ07/I5PNwQ9mmR1X2jxq4QDKj9iR2hJPLKrw1Ni326+jHAhwBWhBTp1wMutzK
# YbkwTEn1GgcDxN4=
# SIG # End signature block
