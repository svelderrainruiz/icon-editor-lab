# Validate-Paths.ps1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Test-PathSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter()][switch]$RequireAbsolute
    )
    if ($Path -match '[;&|`]' -or $Path -match '\.\.') { return $false }
    try {
        $rp = Resolve-Path -LiteralPath $Path -ErrorAction Stop
        if ($RequireAbsolute -and -not ($rp.Path -match '^(?:[A-Za-z]:[\\/]|/)')) { return $false }
        return $true
    } catch { return $false }
}

function Validate-PathSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter()][switch]$RequireAbsolute
    )
    if (-not (Test-PathSafe -Path $Path -RequireAbsolute:$RequireAbsolute)) {
        throw "Unsafe or invalid path: $Path"
    }
    return (Resolve-Path -LiteralPath $Path).Path
}

Export-ModuleMember -Function Test-PathSafe, Validate-PathSafe

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBRKRGFgRiwJrUW
# ser+RbKUtmM3v2Ar6IG3lNNJMXHBxaCCAxYwggMSMIIB+qADAgECAhBZBMnA1IEQ
# rUoc5VTi/eQSMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMjEwOTQ2WhcNMjUxMTI3MjExOTQ2WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAzM/Tz+bDJhpbc2ctiygsTdoTO7Eer4BGzx5XqI088x+v
# 0IyhGzASdWiC3STh05h96RlSQOLbzotbwK0ADVKHI87OrkilknDP2n+efrX7BzNz
# TdbwCjNRtLctanjLGXQN1UVVKIRLDWlw7OsYr/MEGFtB+BZkT61RT8rDhN/WOecW
# xi0DG0uWB3yoGWVjI3NTPN5o7BT9K85hH1fcV/45XMNvNkgNpNgG8cIn/NVb+sJJ
# qG17D0ik7rHrskKqNPuaN6ZYTYWsOAZ3hgJft+aPhkUCpa6yvbTYLC2ZXl6ghPTW
# 3QpLUmMWu55HAxJGhddguTeohK+G2U7ENP4CB6akvQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFI9AcFJ2lQ4Q
# aeShYlIQPBdErEK3MA0GCSqGSIb3DQEBCwUAA4IBAQAPFUwwWu2Of1u/jRp1tYFY
# uukuYvTFtNoMFcLEmnfQndCJXXPxVDLzY1Y3A9O7VyMMI0QPZU9Id6mZhcICgRy1
# t8LTp3DJ7fA0Il37UV5AHBIiJDiBQb0X09nYPjXPHyfA/zBDchV5VJyiexIX4Xqv
# jGKCm1qZyJjUhTM8L9dGJctRVG/bQE7cZPFsZcYMSsJTFXyRVbspQFNaU/z9ZJ2U
# F7qqNhSCt8YpOPcwm6q0djj8gdjm4f2sFGohfbPDPO8gvIf7hSUUvDixegCq51La
# rmg8tm9ktx7l5vLICFMVwYZsmYH0vi1eAFxiKyITVBGh1dGC6Sge6JFolB38+ocS
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBZBMnA1IEQrUoc5VTi/eQSMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEINpvsU+HHb6K
# gYnFC+DOD7Pi21ghNNfHTvYHF7x5UIBMMA0GCSqGSIb3DQEBAQUABIIBAFJGunLA
# YC+IWiGHjCqk5VYGPOyKfxRFJFqfqbtJVna2B9hg+RFsF15UDZY3tbRRucuRY5Pv
# f3/qJvYomWZQ6Tj2jTJVyFHpydVVF0pU7MOlWLVV8Uz4+ycy1FthhKQwW0h72Om1
# kArfSU+VKPEW7Zk4F+YcnRkb61E4O3SAUuN15ckW8gI/qkA4l7LUN4hp1JV9YS61
# V8cbfqmrzag4cmAouKAifJU7/yfJ7KrdIfB1dlt5fIoDdTLjGOetamtqXxsG7xcQ
# A8cJmsQBgAFtRLhFZTWvFCNV/dF0bKx112pxkHm2LM53W6GV05FjmN2ZZjX9hIsZ
# z8mYdDvY3M4QPaE=
# SIG # End signature block
