# Verify-Signatures.ps1
[CmdletBinding()]
param(
  [Parameter()][string]$SearchRoot = (Get-Location).Path,
  [Parameter()][string[]]$Include = @("*.ps1","*.psm1"),
  [Parameter()][string[]]$ExcludeDirs = @(".git",".github",".venv","node_modules")
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'
$files = Get-ChildItem -LiteralPath $SearchRoot -Recurse -File -Include $Include | Where-Object {
  $rel = $_.FullName.Substring($SearchRoot.Length).TrimStart('\','/')
  -not ($ExcludeDirs | ForEach-Object { $rel -like ("{0}\*" -f $_) })
}
$bad = @()
foreach ($f in $files) {
  $sig = Get-AuthenticodeSignature -LiteralPath $f.FullName
  if ($sig.Status -ne 'Valid') { $bad += [pscustomobject]@{ Path = $f.FullName; Status = $sig.Status } }
}
if ($bad.Count -gt 0) {
  $bad | Format-Table -AutoSize | Out-String | Write-Output
  throw "Signature check failed for $($bad.Count) file(s)."
}
Write-Output "All script signatures are VALID."

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDA5chJevy6MGSV
# tHJMuyIwbEkqLQdD7aRYKil20DYfiaCCAxYwggMSMIIB+qADAgECAhBy6HyAYrJM
# p0+I2LuzXdTFMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTgyODQ5WhcNMjUxMTI3MTgzODQ5WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAw96CKg44SS02bmaAIBhqnDr4e4UQP3gmqVqzvdbpKIze
# Ycq08UgXQAGDrWKKlX5ZhlViwIoDzVBPhDfCacr6fz8+AdTkLJTUlrCbbaJFIhpm
# X/g9ZELnpot1CM/0AJv2PtzgAd7swf6KYLipEI+dCBdfSoOYtCKp1AOqwchduJWj
# k52wS4Gy86bnEGX56SW1KY1i4wm1yvy7L0BI3wToDuDAbaihlQYBLk+OxZ+nyvLL
# hHxp4AnozLCJoQUX4WNONmRSZ/7FHxy7yieuci5DQuH5w0m5SkCEd3a9cOVT3pPY
# qsqPZw646Z1YYUvc9Dx6AWAjSj1i1ofXd4V3wAJ3rQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFGU2a2WnQ4EA
# cGtJ1TTMlm8JaI82MA0GCSqGSIb3DQEBCwUAA4IBAQCSpCOxAfaGgtKXNWiFyo9b
# f6PE+gDtRjuYGyfdKm8uPM3qj2xajetGze37nk+YD/gxqJWnvatnPW2sx9dQZ5iQ
# VD3V0oZ/OTWxzvSdEYjOt+8kF/GRyf3hBbV1jKyngTm0tls4RntqGGYDFpNQvLF9
# 93Pxhkedwa1uNYj/s/PVahS+RamUEDCkFypkSbSObEpwpZZmPmY28UyUoi9FtRYh
# YMhsvvtEjZTvrug3h++GkgpxHZ3Vws614DLUkMM6gUJrXfrYaxNRAw6/rQ/uU08j
# i+fTZqj80w1nkXLnXsNyb/bvspg2VgFT2fMQVzqIJt8NOvoAsx24likgE5ct56PT
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBy6HyAYrJMp0+I2LuzXdTFMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIIEZpCeYMGc2
# kHxmC59rnv7kFfu0+1EDOsevLQv84+74MA0GCSqGSIb3DQEBAQUABIIBAKHSgEm0
# Qp1+ziK10HMIpONxVMENvLQ/ZWlT8OFl1nsBsDyMsD6ilIVCU0SOOOzR7W4vL1qW
# qumMP9CndS3p4wpSI4lvncauDtauszY81iaOwi1fCxVV19ppyRnY2pcAeAxRW7Lb
# Hf2uplVH3WTZZ0lThkQHbvIgBXk17nVjl6pc2i9DkLRYwLuqz04Y5wNBjh13YzJx
# xae7DFvsQj7QYLTtyKS6ejSej78UtrIcVPQ9Srw/Q/eQMkjuHKQ21ABQ/ivYnPS5
# DIGTdLf1ZgXj8F//2ecL1fB9T0PFA+iYjcsS64oIDJYCCk4SE8fdSNNswi4fM/m9
# 8JYz5W2/MvYkraM=
# SIG # End signature block
