# Validate-Paths.ps1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Test-PathSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter()][switch]$RequireAbsolute
    )
    if ($Path -match '[;&|`]' -or $Path -match '\.\.') { return $false }
    try {
        $rp = Resolve-Path -LiteralPath $Path -ErrorAction Stop
        if ($RequireAbsolute -and -not ($rp.Path -match '^(?:[A-Za-z]:[\\/]|/)')) { return $false }
        return $true
    } catch { return $false }
}

function Validate-PathSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter()][switch]$RequireAbsolute
    )
    if (-not (Test-PathSafe -Path $Path -RequireAbsolute:$RequireAbsolute)) {
        throw "Unsafe or invalid path: $Path"
    }
    return (Resolve-Path -LiteralPath $Path).Path
}

Export-ModuleMember -Function Test-PathSafe, Validate-PathSafe

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBRKRGFgRiwJrUW
# ser+RbKUtmM3v2Ar6IG3lNNJMXHBxaCCAxYwggMSMIIB+qADAgECAhBy6HyAYrJM
# p0+I2LuzXdTFMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTgyODQ5WhcNMjUxMTI3MTgzODQ5WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAw96CKg44SS02bmaAIBhqnDr4e4UQP3gmqVqzvdbpKIze
# Ycq08UgXQAGDrWKKlX5ZhlViwIoDzVBPhDfCacr6fz8+AdTkLJTUlrCbbaJFIhpm
# X/g9ZELnpot1CM/0AJv2PtzgAd7swf6KYLipEI+dCBdfSoOYtCKp1AOqwchduJWj
# k52wS4Gy86bnEGX56SW1KY1i4wm1yvy7L0BI3wToDuDAbaihlQYBLk+OxZ+nyvLL
# hHxp4AnozLCJoQUX4WNONmRSZ/7FHxy7yieuci5DQuH5w0m5SkCEd3a9cOVT3pPY
# qsqPZw646Z1YYUvc9Dx6AWAjSj1i1ofXd4V3wAJ3rQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFGU2a2WnQ4EA
# cGtJ1TTMlm8JaI82MA0GCSqGSIb3DQEBCwUAA4IBAQCSpCOxAfaGgtKXNWiFyo9b
# f6PE+gDtRjuYGyfdKm8uPM3qj2xajetGze37nk+YD/gxqJWnvatnPW2sx9dQZ5iQ
# VD3V0oZ/OTWxzvSdEYjOt+8kF/GRyf3hBbV1jKyngTm0tls4RntqGGYDFpNQvLF9
# 93Pxhkedwa1uNYj/s/PVahS+RamUEDCkFypkSbSObEpwpZZmPmY28UyUoi9FtRYh
# YMhsvvtEjZTvrug3h++GkgpxHZ3Vws614DLUkMM6gUJrXfrYaxNRAw6/rQ/uU08j
# i+fTZqj80w1nkXLnXsNyb/bvspg2VgFT2fMQVzqIJt8NOvoAsx24likgE5ct56PT
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBy6HyAYrJMp0+I2LuzXdTFMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEINpvsU+HHb6K
# gYnFC+DOD7Pi21ghNNfHTvYHF7x5UIBMMA0GCSqGSIb3DQEBAQUABIIBAHVOTyYY
# gUXzcU4gJCR42amqV8QQOGJyazcu7IRY1dw14C3cSOo4hJ3+rAl2MI9LLsM1E0+A
# /q88bNf/N0RsHmZKLUSfPVnbuYCnCU2e312mnbQxAzC/QR4kBJH1G1wy7hK5bTp1
# 25juzdlLJMM10SaKzw0eUXXqhqjw4L1IMwQUYO65HOUGRPgHmtzM2XQLGPA+UGfN
# aayQQEXfSMdpy1BHxiyOZTmbQU76AO1aBrcqwoK+UQGuoyG1NVuwCRU+VyAyoVhZ
# Lt7volSHV+xreFpzjWWRSCvsL94FcjG1y1QKye1TS7WqpXZAqtQwypDosmz4zX9p
# yaI+2qiMWHBZHSw=
# SIG # End signature block
