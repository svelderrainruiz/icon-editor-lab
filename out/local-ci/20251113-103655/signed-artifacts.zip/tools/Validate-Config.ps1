[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$ConfigPath,
  [Parameter()][string]$SchemaPath = (Join-Path $PSScriptRoot '..' 'configs' 'schema' 'vi-diff-heuristics.schema.json')
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'
. (Join-Path $PSScriptRoot 'Redaction.ps1')
$cfgContent = Get-Content -LiteralPath $ConfigPath -Raw
# Basic JSON validity check
$null = $cfgContent | ConvertFrom-Json -ErrorAction Stop
# Schema validation (if schema exists)
if (Test-Path -LiteralPath $SchemaPath -PathType Leaf) {
  $cfgContent | Test-Json -SchemaFile $SchemaPath -ErrorAction Stop | Out-Null
}
Write-Output "Config validated successfully:" (Resolve-Path -LiteralPath $ConfigPath).Path

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAtM1F8YzQ4xa9F
# 7QuDGJd4jTwMhZsuR+3nhXLiXLTUlKCCAxYwggMSMIIB+qADAgECAhBy6HyAYrJM
# p0+I2LuzXdTFMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTgyODQ5WhcNMjUxMTI3MTgzODQ5WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAw96CKg44SS02bmaAIBhqnDr4e4UQP3gmqVqzvdbpKIze
# Ycq08UgXQAGDrWKKlX5ZhlViwIoDzVBPhDfCacr6fz8+AdTkLJTUlrCbbaJFIhpm
# X/g9ZELnpot1CM/0AJv2PtzgAd7swf6KYLipEI+dCBdfSoOYtCKp1AOqwchduJWj
# k52wS4Gy86bnEGX56SW1KY1i4wm1yvy7L0BI3wToDuDAbaihlQYBLk+OxZ+nyvLL
# hHxp4AnozLCJoQUX4WNONmRSZ/7FHxy7yieuci5DQuH5w0m5SkCEd3a9cOVT3pPY
# qsqPZw646Z1YYUvc9Dx6AWAjSj1i1ofXd4V3wAJ3rQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFGU2a2WnQ4EA
# cGtJ1TTMlm8JaI82MA0GCSqGSIb3DQEBCwUAA4IBAQCSpCOxAfaGgtKXNWiFyo9b
# f6PE+gDtRjuYGyfdKm8uPM3qj2xajetGze37nk+YD/gxqJWnvatnPW2sx9dQZ5iQ
# VD3V0oZ/OTWxzvSdEYjOt+8kF/GRyf3hBbV1jKyngTm0tls4RntqGGYDFpNQvLF9
# 93Pxhkedwa1uNYj/s/PVahS+RamUEDCkFypkSbSObEpwpZZmPmY28UyUoi9FtRYh
# YMhsvvtEjZTvrug3h++GkgpxHZ3Vws614DLUkMM6gUJrXfrYaxNRAw6/rQ/uU08j
# i+fTZqj80w1nkXLnXsNyb/bvspg2VgFT2fMQVzqIJt8NOvoAsx24likgE5ct56PT
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBy6HyAYrJMp0+I2LuzXdTFMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPGNlwZgDGGO
# 4eoZqf6qFtcbYyZe5LvdTuTwGIaPVsX8MA0GCSqGSIb3DQEBAQUABIIBAMIguUUp
# nZLqEt7RPl32lLY3gFBOjvJEy0Be8+Khc1c4EmN1FZN5zg3AJBD30h0AhlIeeQWI
# 5hp+SYtbdN+CsiWo9pHvfgcsyNxK7oNOufhLv9NbuAdYyLGYTS1rz9UMYs9YAW6o
# fhTzZ5xRks+Sdpf+yt4cW34aXYlZfXHEibrvWO0KcnU8YF3cmJZPvv5Ay9AREiW1
# OHpIFUdXk7EYyJrAE51Qbn3RObkddUJaK5yfwCe6+LNJn+Z3PzRpbva3l2iGLb+x
# 07gIvgnBZdN63OT+L03AktpWQlzd6ZgmEfadetI4+P78vkIoxk8quz/PaIdWtXb9
# dwSfregtOQMWclM=
# SIG # End signature block
