#Requires -Version 7.0
<#
.SYNOPSIS
  Consistent entry point for running the repository's Pester suite.

.DESCRIPTION
  Loads tests/Pester.runsettings.psd1, applies optional tag/exclude filters,
  and runs Invoke-Pester. When -CI is specified, writes JUnit output under
  out/test-results/pester.xml (creating the folder if needed).

.PARAMETER Tag
  Only run tests tagged with any of the specified values.

.PARAMETER ExcludeTag
  Skip tests tagged with any of the specified values.

.PARAMETER CI
  Enables JUnit output to out/test-results/pester.xml.
#>

[CmdletBinding()]
param(
  [string[]]$Tag,
  [string[]]$ExcludeTag,
  [switch]$CI
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repoRoot = Resolve-Path (Join-Path $PSScriptRoot '..')
$configPath = Join-Path $repoRoot 'tests' 'Pester.runsettings.psd1'
if (-not (Test-Path $configPath)) {
  throw "Pester configuration not found: $configPath"
}

$config = Import-PowerShellDataFile -LiteralPath $configPath

# Normalize relative paths based on repo root
$config.Run.Path = @(
  $config.Run.Path | ForEach-Object {
    (Resolve-Path (Join-Path $repoRoot $_)).ProviderPath
  }
)
$resolvedResultPath = Resolve-Path (Join-Path $repoRoot $config.TestResult.OutputPath) -ErrorAction SilentlyContinue
if ($resolvedResultPath) {
  $config.TestResult.OutputPath = $resolvedResultPath.ProviderPath
} else {
  $config.TestResult.OutputPath = Join-Path $repoRoot 'out/test-results/pester.xml'
}
if (-not $config.TestResult.OutputPath) {
  $config.TestResult.OutputPath = Join-Path $repoRoot 'out/test-results/pester.xml'
}

if ($Tag) {
  $config.Filter.Tag = @($Tag)
}
if ($ExcludeTag) {
  $config.Filter.ExcludeTag = @($ExcludeTag)
}

if ($CI) {
  $resultsPath = $config.TestResult.OutputPath
  $resultsDir = Split-Path $resultsPath -Parent
  if (-not (Test-Path $resultsDir)) { New-Item -ItemType Directory -Path $resultsDir -Force | Out-Null }
  $config.TestResult.Enabled = $true
  Write-Host "CI mode: writing Pester results to $resultsPath"
} else {
  $config.TestResult.Enabled = $false
}

Write-Host "Invoking Pester with tags: $($config.Filter.Tag -join ', ')" -ForegroundColor Cyan
Invoke-Pester -Configuration $config

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDYd2uoPAkTXPJb
# bn+j5BoktSlFrWLc2tx3vJ8l5hj/eaCCAxYwggMSMIIB+qADAgECAhBy6HyAYrJM
# p0+I2LuzXdTFMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTgyODQ5WhcNMjUxMTI3MTgzODQ5WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAw96CKg44SS02bmaAIBhqnDr4e4UQP3gmqVqzvdbpKIze
# Ycq08UgXQAGDrWKKlX5ZhlViwIoDzVBPhDfCacr6fz8+AdTkLJTUlrCbbaJFIhpm
# X/g9ZELnpot1CM/0AJv2PtzgAd7swf6KYLipEI+dCBdfSoOYtCKp1AOqwchduJWj
# k52wS4Gy86bnEGX56SW1KY1i4wm1yvy7L0BI3wToDuDAbaihlQYBLk+OxZ+nyvLL
# hHxp4AnozLCJoQUX4WNONmRSZ/7FHxy7yieuci5DQuH5w0m5SkCEd3a9cOVT3pPY
# qsqPZw646Z1YYUvc9Dx6AWAjSj1i1ofXd4V3wAJ3rQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFGU2a2WnQ4EA
# cGtJ1TTMlm8JaI82MA0GCSqGSIb3DQEBCwUAA4IBAQCSpCOxAfaGgtKXNWiFyo9b
# f6PE+gDtRjuYGyfdKm8uPM3qj2xajetGze37nk+YD/gxqJWnvatnPW2sx9dQZ5iQ
# VD3V0oZ/OTWxzvSdEYjOt+8kF/GRyf3hBbV1jKyngTm0tls4RntqGGYDFpNQvLF9
# 93Pxhkedwa1uNYj/s/PVahS+RamUEDCkFypkSbSObEpwpZZmPmY28UyUoi9FtRYh
# YMhsvvtEjZTvrug3h++GkgpxHZ3Vws614DLUkMM6gUJrXfrYaxNRAw6/rQ/uU08j
# i+fTZqj80w1nkXLnXsNyb/bvspg2VgFT2fMQVzqIJt8NOvoAsx24likgE5ct56PT
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBy6HyAYrJMp0+I2LuzXdTFMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEII11SC6wt7Xz
# Nju6w2mLIcqzI70/iCgkEho6gi7yzw2NMA0GCSqGSIb3DQEBAQUABIIBAJcZr5Hp
# LlVdQhJ43vsBzNLzvKOrlijFKK3ftrSWF+8mWGIyO7yPD84zy2DBjKn58K8xc5+Z
# TDF31jpsx3/GuUU9SwmvoSlmVD7MU606mD2xk0R/zJ2VuIry465TwNxYM8vFqx8n
# ynxzb9PvLtefl8Z1tMmdIg6aFPijiV6iJLEBoNjYO4vvoUHG00gAxsbSg9cWgAj7
# Ym4DzKzFX4FtvTdjmI417Y9Zo94DzGNUlmz8zuo7fdKTvwZ2lB1FTZuIrp77GTGk
# ca4a3Htq60SoOZUqtgavxyE7YCdS+ac1hKa1On1b8i9OFSiy/naJkgZxkmhbrUQ9
# Lj8NTEHqHZMO5yQ=
# SIG # End signature block
