#Requires -Version 7.0
<#
.SYNOPSIS
  Runs fork-mode and trusted-mode signing batches locally to mirror CI behavior.

.DESCRIPTION
  - Prepares SIGN_ROOT by copying repo scripts (tools/, scripts/) plus sample payloads.
  - Generates an ephemeral certificate for each mode and runs Invoke-ScriptSigningBatch.ps1.
  - Prints the summary output so we can compare with GitHub runners.

.PARAMETER SignRoot
  Directory to stage unsigned artifacts. Defaults to 'out'.

.PARAMETER MaxFiles
  Max script count to process (passed through to the batch helper).

.PARAMETER TimeoutSeconds
  Timeout for timestamping; batch helper uses it for per-file waits.

.PARAMETER ToolsOnly
  Limit the test payload to scripts under tools/.

.PARAMETER ScriptsOnly
  Limit the test payload to scripts under scripts/.

.PARAMETER SkipToolTests
  Skip running the harness Pester suite (tools and scripts tags). By default the suite runs.

.NOTES
  Every run captures a transcript under out/local-signing-logs for traceability.
#>

[CmdletBinding()]
param(
  [string]$SignRoot = 'out',
  [int]$MaxFiles = 200,
  [int]$TimeoutSeconds = 20,
  [string]$TimestampServer = 'https://timestamp.digicert.com',
  [switch]$ToolsOnly,
  [switch]$ScriptsOnly,
  [switch]$IncludeSamples = $true,
  [switch]$SimulateTimestampFailure,
  [switch]$SkipToolTests,
  [string[]]$ExcludePaths = @('local-signing-logs','local-ci')
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

if ($ToolsOnly -and $ScriptsOnly) {
  throw "Use either -ToolsOnly or -ScriptsOnly, not both."
}

function Test-IsExcludedPath {
  param(
    [string]$RelativePath,
    [string[]]$Excludes
  )
  if (-not $RelativePath) { return $false }
  $segments = $RelativePath -split '[\\/]' | Where-Object { $_ }
  foreach ($segment in $segments) {
    if ($Excludes -contains $segment) { return $true }
  }
  return $false
}

function Get-RootsToCopy {
  if ($ToolsOnly)   { return @('tools') }
  if ($ScriptsOnly) { return @('scripts') }
  return @('tools','scripts')
}

function Prepare-SignRoot {
  param(
    [string]$Root,
    [string[]]$SourceRoots,
    [string[]]$ExcludeFolders
  )
  if (-not (Test-Path $Root)) {
    New-Item -ItemType Directory -Path $Root | Out-Null
  } else {
    Get-ChildItem -Path $Root -Force | Where-Object { $ExcludeFolders -notcontains $_.Name } | Remove-Item -Recurse -Force
    foreach ($folder in $ExcludeFolders) {
      $path = Join-Path $Root $folder
      if (-not (Test-Path $path)) {
        New-Item -ItemType Directory -Path $path | Out-Null
      }
    }
  }

  $rootsToCopy = $SourceRoots

  foreach ($rr in $rootsToCopy) {
    $src = Join-Path $PWD $rr
    if (-not (Test-Path $src)) { continue }
    Get-ChildItem -Path $src -Include *.ps1,*.psm1 -Recurse -File |
      ForEach-Object {
        $relative = $_.FullName.Substring($PWD.ToString().Length + 1)
        $dest = Join-Path $Root $relative
        $destDir = Split-Path $dest -Parent
        if (-not (Test-Path $destDir)) { New-Item -ItemType Directory -Path $destDir -Force | Out-Null }
        Copy-Item -Path $_.FullName -Destination $dest -Force
      }
  }

  if ($IncludeSamples) {
    "Write-Output 'Sample payload for signing test.'" | Set-Content -Path (Join-Path $Root 'Sample-Signed.ps1') -Encoding UTF8
    [IO.File]::WriteAllBytes((Join-Path $Root 'sample.exe'), [byte[]](1..16))
  }
}

function Invoke-SigningMode {
  param(
    [string]$ModeLabel,
    [switch]$UseTimestamp,
    [int]$MaxFiles,
    [int]$TimeoutSeconds,
    [string]$TimestampServer,
    [string[]]$ExcludeFolders
  )
  $cert = New-SelfSignedCertificate -Subject "CN=CI Local $ModeLabel" -Type CodeSigningCert -CertStoreLocation Cert:\CurrentUser\My -NotAfter (Get-Date).AddDays(14)
  $thumb = $cert.Thumbprint
  $args = @(
    '-NoLogo','-NoProfile','-File','tools/Invoke-ScriptSigningBatch.ps1',
    '-Root', $SignRoot,
    '-CertificateThumbprint', $thumb,
    '-MaxFiles', $MaxFiles,
    '-TimeoutSeconds', $TimeoutSeconds,
    '-Mode', $ModeLabel
  )
  if ($ExcludeFolders -and $ExcludeFolders.Count -gt 0) {
    Write-Verbose ("[{0}] Excluding folders from signing: {1}" -f $ModeLabel, ($ExcludeFolders -join ', '))
    $args += '-ExcludePaths'
    $args += ($ExcludeFolders -join ',')
  }
  if ($UseTimestamp) {
    $tsa = if ([string]::IsNullOrWhiteSpace($TimestampServer)) { 'https://timestamp.digicert.com' } else { $TimestampServer }
    $args += @('-UseTimestamp','-TimestampServer', $tsa)
    if ($SimulateTimestampFailure -and $ModeLabel -like 'trusted*') {
      $args += '-SimulateTimestampFailure'
    }
  }
  Write-Host "`n== Running mode: $ModeLabel ==" -ForegroundColor Cyan
  $cmdInfo = Get-Command pwsh -ErrorAction SilentlyContinue
  $pwshCmd = $null
  if ($cmdInfo) {
    if ($cmdInfo.PSObject.Properties['Path']) { $pwshCmd = $cmdInfo.Path }
    elseif ($cmdInfo.PSObject.Properties['Source']) { $pwshCmd = $cmdInfo.Source }
  }
  if (-not $pwshCmd -and $IsWindows) {
    $candidate = Join-Path $PSHOME 'pwsh.exe'
    if (Test-Path -LiteralPath $candidate -PathType Leaf) { $pwshCmd = $candidate }
  }
  if (-not $pwshCmd) { $pwshCmd = 'pwsh' }
  & $pwshCmd @args
}

function Invoke-HarnessTests {
  param([string[]]$Tags)
  $effectiveTags = @($Tags | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
  if ($effectiveTags.Count -eq 0) {
    Write-Host "No harness tags selected; skipping Pester harness run." -ForegroundColor Yellow
    return
  }

  $runner = Join-Path $PSScriptRoot 'Invoke-RepoPester.ps1'
  if (-not (Test-Path $runner)) {
    throw "Cannot locate Invoke-RepoPester.ps1 at $runner"
  }

  Write-Host "`n== Running harness Pester suite (tags: $($effectiveTags -join ', ')) ==" -ForegroundColor Cyan
  & $runner -Tag $effectiveTags
}

$transcriptDir = Join-Path $PWD 'out/local-signing-logs'
if (-not (Test-Path $transcriptDir)) { New-Item -ItemType Directory -Path $transcriptDir -Force | Out-Null }
$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$logPath = Join-Path $transcriptDir "signing-$timestamp.log"
Start-Transcript -Path $logPath | Out-Null

try {
  $selectedRoots = Get-RootsToCopy
  Prepare-SignRoot -Root $SignRoot -SourceRoots $selectedRoots -ExcludeFolders $ExcludePaths
  Invoke-SigningMode -ModeLabel 'fork-local' -MaxFiles $MaxFiles -TimeoutSeconds $TimeoutSeconds -TimestampServer $TimestampServer -ExcludeFolders $ExcludePaths
  Invoke-SigningMode -ModeLabel 'trusted-local' -UseTimestamp -MaxFiles $MaxFiles -TimeoutSeconds $TimeoutSeconds -TimestampServer $TimestampServer -ExcludeFolders $ExcludePaths
  if (-not $SkipToolTests) {
    $harnessTags = @()
    if ($ToolsOnly) {
      $harnessTags = @('tools')
    } elseif ($ScriptsOnly) {
      $harnessTags = @('scripts')
    } else {
      $harnessTags = @('tools','scripts')
    }
    Invoke-HarnessTests -Tags $harnessTags
  } else {
    Write-Host "Skipping harness Pester suite (-SkipToolTests set)." -ForegroundColor Yellow
  }
} finally {
  Stop-Transcript | Out-Null
  Write-Host "Transcript written to $logPath" -ForegroundColor Yellow
}

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDO+zFXaWj3+laO
# hnO4RfAEKWl8MCj9PA4MztsChK6t/aCCAxYwggMSMIIB+qADAgECAhBK58c1rYPq
# l07ge8uIHwC2MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMDkxNjU5WhcNMjUxMTI3MDkyNjU5WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA0CPRk6ZBXfwCnia00SxxHLXHHQpoVn3e+SYJsL4ZYOMC
# qbgldP0yL4jvm+VH256ayUY9pGdDw9prbk0x7bFCWcNY4n/A+UkARMhzmi6jT53q
# qjo2ljO9sqObbIjJyaeSbNkXXJ5xsCIuo9JfjlG3kwEewtlWTer+mzn5/YWkror7
# sNFTr4iLHsmCOllUplrIz2rSdoDgybTdCN5tlpTtAaW7uDQ0zR5/8knE7Ro6TNf9
# UlE9Ji6aGPri63h5KMO8qW/N/BbMR6dEgDBhDh1594rEefBxTdKSLQwLGBBHzM7d
# CY+693Q0spphm9q6zwtf95CFCUpHEjRBoBe/Xb55dQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFL8i+Agh1t7M
# 9Mu60NcHH5ZVDjK5MA0GCSqGSIb3DQEBCwUAA4IBAQAIJB2jH1zXpRLE0dmMGV43
# eBBWtbKU+WraxyPfMWIKF4vhVrYE4vWQ57AME1UMqBAVpTMVi8RkksuVrbxWp1Mm
# FYKNjDvOCPxIZ0zufwcmJCdQxEBeRxJjz8tfKOnQ53V+iX0YSJ2K4zWRTIGiyYih
# c93fMkJ229NWa0NHJr/Te1RuA1s0rzESFjNyAw5R+q0gYQ5EHLkfB3k/6CwZUCl3
# H3RwjhprNU08X0flJ/3bVsnNA71wlnmhI9fWQ73LxVsQ5SPbzt/QKWMeMpD7A4kJ
# g8z+91NXNw4bUH6ErgmbL3MCoCf+8FwCHBrd9Br6aCr6wqgKGhRxiLzahzc5Z1hW
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBK58c1rYPql07ge8uIHwC2MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPoI+ZjLcgkx
# hAxXRw0BvaXK5KDJya48uWOrTX/uioWFMA0GCSqGSIb3DQEBAQUABIIBAI0HLR8A
# mqlrvT5XUB6WzG3CvHDizxP9EkqywXeaBgaamhJOazXw5Dve3GAx3oLKkfeESS4b
# jXLqGnrX+3SPW+6Wy/tg4vLIeBQK8JOJNGgr+cgcKZxgq0hMskbRhMjblSj3IM5I
# 9K/2if283OzRXNMQqBqXGTvFCVM/VsfcHq00DPMYQnVSW5DKpcfF5x5r/JIDHT5P
# HY7ls58OsBoyfo02EA8EMJ1v/MFM6E3KDaKJGs/pKYbA9HdgXrkcCF5BYVWlfjcm
# dAAGQPRzZTQSV89MBiwiaq6I+eVKnT81XfafS0QakC7/H5sFAP2AaH+hEPc/maGc
# O4KFf/qiI9ve/pI=
# SIG # End signature block
