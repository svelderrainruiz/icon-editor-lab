# Secure-Process.psm1
Set-StrictMode -Version Latest
. (Join-Path $PSScriptRoot 'Validate-Paths.ps1')
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Invoke-ProcessSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$FilePath,
        [Parameter()][string[]]$ArgumentList = @(),
        [Parameter()][int]$TimeoutSec = 600,
        [Parameter()][string]$WorkingDirectory = (Get-Location).Path
    )
    if (-not (Test-Path -LiteralPath $FilePath -PathType Leaf)) { throw "FilePath not found: $FilePath" }
    $psi = [System.Diagnostics.ProcessStartInfo]::new()
    $psi.FileName = $FilePath
    $psi.WorkingDirectory = (Validate-PathSafe -Path $WorkingDirectory)
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.UseShellExecute = $false
    foreach ($a in $ArgumentList) { $null = $psi.ArgumentList.Add($a) }

    $p = [System.Diagnostics.Process]::new()
    $p.StartInfo = $psi
    if (-not $p.Start()) { throw "Failed to start process: $FilePath" }
    try {
        if (-not $p.WaitForExit($TimeoutSec * 1000)) {
            try { $p.Kill($true) } catch {}
            throw "Process timed out after $TimeoutSec s: $FilePath"
        }
        $stdout = $p.StandardOutput.ReadToEnd()
        $stderr = $p.StandardError.ReadToEnd()
        return [pscustomobject]@{
            ExitCode = $p.ExitCode
            StdOut = $stdout
            StdErr = $stderr
        }
    } finally {
        if (-not $p.HasExited) { try { $p.Kill($true) } catch {} }
        $p.Dispose()
    }
}
Export-ModuleMember -Function Invoke-ProcessSafe

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDLM/hZ77J6ko3k
# J1T1SnSI3Zjg9T8EF5sOyyHIvgXLgqCCAxYwggMSMIIB+qADAgECAhBK58c1rYPq
# l07ge8uIHwC2MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMDkxNjU5WhcNMjUxMTI3MDkyNjU5WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA0CPRk6ZBXfwCnia00SxxHLXHHQpoVn3e+SYJsL4ZYOMC
# qbgldP0yL4jvm+VH256ayUY9pGdDw9prbk0x7bFCWcNY4n/A+UkARMhzmi6jT53q
# qjo2ljO9sqObbIjJyaeSbNkXXJ5xsCIuo9JfjlG3kwEewtlWTer+mzn5/YWkror7
# sNFTr4iLHsmCOllUplrIz2rSdoDgybTdCN5tlpTtAaW7uDQ0zR5/8knE7Ro6TNf9
# UlE9Ji6aGPri63h5KMO8qW/N/BbMR6dEgDBhDh1594rEefBxTdKSLQwLGBBHzM7d
# CY+693Q0spphm9q6zwtf95CFCUpHEjRBoBe/Xb55dQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFL8i+Agh1t7M
# 9Mu60NcHH5ZVDjK5MA0GCSqGSIb3DQEBCwUAA4IBAQAIJB2jH1zXpRLE0dmMGV43
# eBBWtbKU+WraxyPfMWIKF4vhVrYE4vWQ57AME1UMqBAVpTMVi8RkksuVrbxWp1Mm
# FYKNjDvOCPxIZ0zufwcmJCdQxEBeRxJjz8tfKOnQ53V+iX0YSJ2K4zWRTIGiyYih
# c93fMkJ229NWa0NHJr/Te1RuA1s0rzESFjNyAw5R+q0gYQ5EHLkfB3k/6CwZUCl3
# H3RwjhprNU08X0flJ/3bVsnNA71wlnmhI9fWQ73LxVsQ5SPbzt/QKWMeMpD7A4kJ
# g8z+91NXNw4bUH6ErgmbL3MCoCf+8FwCHBrd9Br6aCr6wqgKGhRxiLzahzc5Z1hW
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBK58c1rYPql07ge8uIHwC2MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPEK5pYr/oiP
# 6zXDh72ZtLHO5VLyj1aDMXhTjDbbSs4wMA0GCSqGSIb3DQEBAQUABIIBAJ6h32IW
# 4/1u/de9Td7SOo/xA+isuiCLoxL8Iy6mcFwVxHmbJsoo1t6qGQunXLsmVEHWW/6Y
# 8RQgJh3m6/2bKBFQ0XkUMzyyvPQ/P/Zr53SnHPsjY4lTnrJRSUVg/EVeOhOJqln3
# YkwP3wI5Jr73tFIkMPWEgG6eapgJ7cgHsK8jLbFQSjHmIFCe2TbiDuyBJse/SJ71
# 4O+tZ9ri9sEmDTUy+yp4usyGwQ6ZBT9/WnE7kfPsBSiKtqNN9WBsjvt8jrbuK9TY
# WliP2rBUgRHIsLE8/a16VIWXmLHmz/MYMGSDC146NEsEgKXlvwnvzmCl+CBfd/3G
# AzHR/HJiF5WlbB4=
# SIG # End signature block
