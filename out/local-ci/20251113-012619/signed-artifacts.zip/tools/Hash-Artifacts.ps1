# Hash-Artifacts.ps1
[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$Root,
  [Parameter()][string]$Output = 'checksums.sha256'
)

Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'

$rootAbs = Resolve-Path -LiteralPath $Root -ErrorAction Stop
$rootPath = $rootAbs.ProviderPath
$items = Get-ChildItem -LiteralPath $rootPath -Recurse -File -ErrorAction Stop
$lines = New-Object System.Collections.Generic.List[string]
foreach ($i in $items) {
  $h = Get-FileHash -LiteralPath $i.FullName -Algorithm SHA256
  $relativePath = [System.IO.Path]::GetRelativePath($rootPath, $i.FullName)
  try {
    $lines.Add(("{0}  {1}" -f $h.Hash.ToLower(), $relativePath))
  } catch {
    throw "Failed to format hash entry for '$($i.FullName)' relative '$relativePath': $($_.Exception.Message)"
  }
}
$pathOut = Join-Path $rootPath $Output
$lines | Set-Content -LiteralPath $pathOut -Encoding UTF8 -NoNewline:$false
Write-Output "Wrote checksums to $pathOut"

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCASG2cZB9SxQNBP
# DwVC9asjKlcJItPjhuWB1EHHmj/2laCCAxYwggMSMIIB+qADAgECAhBK58c1rYPq
# l07ge8uIHwC2MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMDkxNjU5WhcNMjUxMTI3MDkyNjU5WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA0CPRk6ZBXfwCnia00SxxHLXHHQpoVn3e+SYJsL4ZYOMC
# qbgldP0yL4jvm+VH256ayUY9pGdDw9prbk0x7bFCWcNY4n/A+UkARMhzmi6jT53q
# qjo2ljO9sqObbIjJyaeSbNkXXJ5xsCIuo9JfjlG3kwEewtlWTer+mzn5/YWkror7
# sNFTr4iLHsmCOllUplrIz2rSdoDgybTdCN5tlpTtAaW7uDQ0zR5/8knE7Ro6TNf9
# UlE9Ji6aGPri63h5KMO8qW/N/BbMR6dEgDBhDh1594rEefBxTdKSLQwLGBBHzM7d
# CY+693Q0spphm9q6zwtf95CFCUpHEjRBoBe/Xb55dQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFL8i+Agh1t7M
# 9Mu60NcHH5ZVDjK5MA0GCSqGSIb3DQEBCwUAA4IBAQAIJB2jH1zXpRLE0dmMGV43
# eBBWtbKU+WraxyPfMWIKF4vhVrYE4vWQ57AME1UMqBAVpTMVi8RkksuVrbxWp1Mm
# FYKNjDvOCPxIZ0zufwcmJCdQxEBeRxJjz8tfKOnQ53V+iX0YSJ2K4zWRTIGiyYih
# c93fMkJ229NWa0NHJr/Te1RuA1s0rzESFjNyAw5R+q0gYQ5EHLkfB3k/6CwZUCl3
# H3RwjhprNU08X0flJ/3bVsnNA71wlnmhI9fWQ73LxVsQ5SPbzt/QKWMeMpD7A4kJ
# g8z+91NXNw4bUH6ErgmbL3MCoCf+8FwCHBrd9Br6aCr6wqgKGhRxiLzahzc5Z1hW
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBK58c1rYPql07ge8uIHwC2MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIFwh7Ia6nNVg
# FzrXU1zSmX6Kq7zfAQC5vDsMmiqye02wMA0GCSqGSIb3DQEBAQUABIIBAFxdI+oK
# Sz+KyIzcuFEXico/CT4HecQYFowkXXypi5MbHdnAMAGqmy7TOR70S+B67IC1ZweF
# Q9JQ/arabXl7iv7XST9HFCUuqEPWJVa7O0n8x/Ve7KFQjurkbPBwSrPfmq1oNME/
# /NVz2cWa9Muy6RAUdBUtzYvwgM/o7/Ji4cppnbVYm+G+SAGUDlM/WNcKFGtlQxhb
# 1mtXMW0zMj8UqOwVvVJJ9gx8G21GcNtPG3cdBwzDnUXxxu2f3YXTlsyFmYnMUknG
# dGYn2LNzFbULThffen6X0pzr3Sp5U/UrY36EVW0PpszrX1nXrnzIhAb7sOLEtxgn
# 0OYQz/xFAyjt6bQ=
# SIG # End signature block
