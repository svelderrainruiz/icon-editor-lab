# Verify-Signatures.ps1
[CmdletBinding()]
param(
  [Parameter()][string]$SearchRoot = (Get-Location).Path,
  [Parameter()][string[]]$Include = @("*.ps1","*.psm1"),
  [Parameter()][string[]]$ExcludeDirs = @(".git",".github",".venv","node_modules")
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'
$files = Get-ChildItem -LiteralPath $SearchRoot -Recurse -File -Include $Include | Where-Object {
  $rel = $_.FullName.Substring($SearchRoot.Length).TrimStart('\','/')
  -not ($ExcludeDirs | ForEach-Object { $rel -like ("{0}\*" -f $_) })
}
$bad = @()
foreach ($f in $files) {
  $sig = Get-AuthenticodeSignature -LiteralPath $f.FullName
  if ($sig.Status -ne 'Valid') { $bad += [pscustomobject]@{ Path = $f.FullName; Status = $sig.Status } }
}
if ($bad.Count -gt 0) {
  $bad | Format-Table -AutoSize | Out-String | Write-Output
  throw "Signature check failed for $($bad.Count) file(s)."
}
Write-Output "All script signatures are VALID."

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDA5chJevy6MGSV
# tHJMuyIwbEkqLQdD7aRYKil20DYfiaCCAxYwggMSMIIB+qADAgECAhBK58c1rYPq
# l07ge8uIHwC2MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMDkxNjU5WhcNMjUxMTI3MDkyNjU5WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA0CPRk6ZBXfwCnia00SxxHLXHHQpoVn3e+SYJsL4ZYOMC
# qbgldP0yL4jvm+VH256ayUY9pGdDw9prbk0x7bFCWcNY4n/A+UkARMhzmi6jT53q
# qjo2ljO9sqObbIjJyaeSbNkXXJ5xsCIuo9JfjlG3kwEewtlWTer+mzn5/YWkror7
# sNFTr4iLHsmCOllUplrIz2rSdoDgybTdCN5tlpTtAaW7uDQ0zR5/8knE7Ro6TNf9
# UlE9Ji6aGPri63h5KMO8qW/N/BbMR6dEgDBhDh1594rEefBxTdKSLQwLGBBHzM7d
# CY+693Q0spphm9q6zwtf95CFCUpHEjRBoBe/Xb55dQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFL8i+Agh1t7M
# 9Mu60NcHH5ZVDjK5MA0GCSqGSIb3DQEBCwUAA4IBAQAIJB2jH1zXpRLE0dmMGV43
# eBBWtbKU+WraxyPfMWIKF4vhVrYE4vWQ57AME1UMqBAVpTMVi8RkksuVrbxWp1Mm
# FYKNjDvOCPxIZ0zufwcmJCdQxEBeRxJjz8tfKOnQ53V+iX0YSJ2K4zWRTIGiyYih
# c93fMkJ229NWa0NHJr/Te1RuA1s0rzESFjNyAw5R+q0gYQ5EHLkfB3k/6CwZUCl3
# H3RwjhprNU08X0flJ/3bVsnNA71wlnmhI9fWQ73LxVsQ5SPbzt/QKWMeMpD7A4kJ
# g8z+91NXNw4bUH6ErgmbL3MCoCf+8FwCHBrd9Br6aCr6wqgKGhRxiLzahzc5Z1hW
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBK58c1rYPql07ge8uIHwC2MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIIEZpCeYMGc2
# kHxmC59rnv7kFfu0+1EDOsevLQv84+74MA0GCSqGSIb3DQEBAQUABIIBAEUojRm9
# PLZpGcq1l2qKQQHWXLfv25RjX1+A3I4AfNJWSbYflCGHO1v6R4/6bsSOW+EOmg4m
# YQNqtUFqG7RrJcpQs2Ky/SZJ65h1IafqQfeG1FLiLZplx2RevhQ2K88nEJdP3Jqh
# jvxBUTvSoaOaAZRzlxgp46qLj4MobVFOBbFM1mm+P5ycJGdel5oanB8RHN20tvck
# V4bRuJGYWNefx62mvzpA0Pc0UCkh/21F9+lOHmc4pr3s6/vd/HILbKVk05l1y9oR
# /M04ZxyzdRj7RhpnrRPwiUjf31s59au9Ve5MRG07lM6NlFmlq7mJnoKZXL9iill3
# HhbP8u2g3OnGD+4=
# SIG # End signature block
