[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$ConfigPath,
  [Parameter()][string]$SchemaPath = (Join-Path $PSScriptRoot '..' 'configs' 'schema' 'vi-diff-heuristics.schema.json')
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'
. (Join-Path $PSScriptRoot 'Redaction.ps1')
$cfgContent = Get-Content -LiteralPath $ConfigPath -Raw
# Basic JSON validity check
$null = $cfgContent | ConvertFrom-Json -ErrorAction Stop
# Schema validation (if schema exists)
if (Test-Path -LiteralPath $SchemaPath -PathType Leaf) {
  $cfgContent | Test-Json -SchemaFile $SchemaPath -ErrorAction Stop | Out-Null
}
Write-Output "Config validated successfully:" (Resolve-Path -LiteralPath $ConfigPath).Path

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAtM1F8YzQ4xa9F
# 7QuDGJd4jTwMhZsuR+3nhXLiXLTUlKCCAxYwggMSMIIB+qADAgECAhBK58c1rYPq
# l07ge8uIHwC2MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMDkxNjU5WhcNMjUxMTI3MDkyNjU5WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA0CPRk6ZBXfwCnia00SxxHLXHHQpoVn3e+SYJsL4ZYOMC
# qbgldP0yL4jvm+VH256ayUY9pGdDw9prbk0x7bFCWcNY4n/A+UkARMhzmi6jT53q
# qjo2ljO9sqObbIjJyaeSbNkXXJ5xsCIuo9JfjlG3kwEewtlWTer+mzn5/YWkror7
# sNFTr4iLHsmCOllUplrIz2rSdoDgybTdCN5tlpTtAaW7uDQ0zR5/8knE7Ro6TNf9
# UlE9Ji6aGPri63h5KMO8qW/N/BbMR6dEgDBhDh1594rEefBxTdKSLQwLGBBHzM7d
# CY+693Q0spphm9q6zwtf95CFCUpHEjRBoBe/Xb55dQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFL8i+Agh1t7M
# 9Mu60NcHH5ZVDjK5MA0GCSqGSIb3DQEBCwUAA4IBAQAIJB2jH1zXpRLE0dmMGV43
# eBBWtbKU+WraxyPfMWIKF4vhVrYE4vWQ57AME1UMqBAVpTMVi8RkksuVrbxWp1Mm
# FYKNjDvOCPxIZ0zufwcmJCdQxEBeRxJjz8tfKOnQ53V+iX0YSJ2K4zWRTIGiyYih
# c93fMkJ229NWa0NHJr/Te1RuA1s0rzESFjNyAw5R+q0gYQ5EHLkfB3k/6CwZUCl3
# H3RwjhprNU08X0flJ/3bVsnNA71wlnmhI9fWQ73LxVsQ5SPbzt/QKWMeMpD7A4kJ
# g8z+91NXNw4bUH6ErgmbL3MCoCf+8FwCHBrd9Br6aCr6wqgKGhRxiLzahzc5Z1hW
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBK58c1rYPql07ge8uIHwC2MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPGNlwZgDGGO
# 4eoZqf6qFtcbYyZe5LvdTuTwGIaPVsX8MA0GCSqGSIb3DQEBAQUABIIBAGgBVpSh
# +aN3eRv/iuHRS6SZa7XcTWKtH4oMipmOHiB0zlNAfXWp5HnzL9C9kWKMvZ9cdbCU
# nJe0dI8A5L2B3eirfAiXhRxDoZ3fZ0iOieLB/n7B9khZnc8joCWp0pfktckdv245
# mDryqxZ8ekg2IxpD+1pKybXKskP1uXzued+LGQhbZ3tEbaYQRtjHFsCexMqOdnKn
# jX1wT9m3yDfNdFCDmnU0wbzYC11Ex/uAQfNU0tDZ9k6T0stTEFajljV/PtAVsoHv
# FgSUs5wDOd/CBXg9u+utwSKeuX18/+r4lc0kPew5HlKhA11fs2dSrpRy184EIZkJ
# mEJ02b/fQ1KYx4Q=
# SIG # End signature block
