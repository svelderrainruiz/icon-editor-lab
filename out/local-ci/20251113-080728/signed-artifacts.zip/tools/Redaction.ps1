# Redaction.ps1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Write-LogSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Message,
        [Parameter()][ValidateSet('INFO','WARN','ERROR')][string]$Level = 'INFO'
    )
    # Redact common secret/token patterns (simple heuristic)
    $msg = $Message -replace '([A-Za-z0-9-_]{20,})','****' `
                    -replace '(?i)(secret|token|password)\s*[:=]\s*[^ \t\r\n]+','$1=****'
    $ts = (Get-Date).ToString('s')
    Write-Output "[$ts][$Level] $msg"
}
if ($ExecutionContext.SessionState.Module) {
    Export-ModuleMember -Function Write-LogSafe
}

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCB5QE8/zfwZTTR5
# g9if2C7NwESBApxi1XkQIcw6fBWi3aCCAxYwggMSMIIB+qADAgECAhAQBh94RrM0
# pkG29b582wzNMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTU1ODMyWhcNMjUxMTI3MTYwODMyWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAu0OCpGJsxZMNwAqH36MTeB8Qbtt5jqW43/vNfBunYydi
# xhr16Kpr0laUaOkOVdiaxnVt+rzddKz9T4fzQ+vSjTWFPx2TQBA1f/QO9ssZONw/
# l29KRq9fbgnbsd7ziy9LvoPGkMzdEZTL9HThyULD5CZvauJNbRiXYLa6vfDiNAYP
# 2pGh62ERQ9lLbcNlrSPvCrlccf77+Ixu5e5I5GegKguvIKmADgRTIBSW8rXWFxT6
# 0JU59WljIxDyMoGJBMWTdPTLYcTcrgkW2r4FtjOMK+3gO5rBRxDzRAkiI55UlFWx
# XjYcDEWUEfHDSxABGEX6FZK1/woW8CgdOQ7HaZWVTQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFLyQGhfoPEUw
# I/lxey6B2aWx2o1wMA0GCSqGSIb3DQEBCwUAA4IBAQAAQQ4xu+xqsttHx7CirXVf
# 5P63tZNVxHc3sgm9hay3eiMirpnzL0/iv4Cqe460eNVig7W86B/8W5cw0kL9uuae
# /vpv9zJCu7K5DDPsSaL5vAbGCTlyt5VjKtmK1VVePYCoh+m4MYPahkGRoBqRZrA2
# 5I9QHn5RrF68gIwm8KCPChPdrZTnDCpBN9NMlEYgJX6Lc0uoDOPQl09qlo4vky4U
# /0vodiO6MnFxp/EQdpFSdk/MutBn549f86cXJYiEx0grp61YcBxwin+yae39qwNb
# WyriXoFrwbmTk0/acc3prYmPg+JHRaVxihfpJ6KywbZ18pGozGlcoMSSwVlX/4Su
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAQBh94RrM0pkG29b582wzNMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIEfHLCIlw9Py
# EI3fUHQlFhw4tq7Q+oRZQIlIetQ/aFBMMA0GCSqGSIb3DQEBAQUABIIBAJngM4nZ
# DwuPcTUL5JxnZrMtblq8ROse7xWT7HBMdjYLJp5Oa5/qdBU4zaYPPmK/pBE/DFm3
# 0RamW/u3xSK6QcvgMJSF8d+8FW127DWZXH6gwVqSBLYPhglH3StlGLc0E9G3Ak7P
# umCnvjhEDWl8t2eE0hsVu7kjMqiqmECGk1aIRAEYY6+iaNhEPurTdMW1MC2/c/dn
# VdSOvMqKjOr5O6pFx5mjzNT0fG1AleZgrbbTZwr6PeTjSAgXBVNJDUDVAbXnfb9s
# Ms3viD/E0vmeuzcrPOVE167SbuM24C34d1fCJBSgVvuxIGvyoh2F9j5TTDD9H21o
# PV0OdZsnO50uUko=
# SIG # End signature block
