# Sign-Scripts.ps1
[CmdletBinding()]
param(
  [Parameter()][string]$Thumbprint,
  [Parameter()][string]$SearchRoot = (Get-Location).Path,
  [Parameter()][string[]]$Include = @("*.ps1","*.psm1"),
  [Parameter()][string[]]$ExcludeDirs = @(".git",".github",".venv","node_modules"),
  [switch]$SkipTimestamp,
  [Parameter()][ValidateRange(1,1000)][int]$ProgressInterval = 25,
  [Parameter()][ValidateRange(0,1000)][int]$ThrottleMilliseconds = 0
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'
if (-not (Test-Path -LiteralPath $SearchRoot -PathType Container)) {
  throw "Search root not found: $SearchRoot"
}
Write-Host "Signing scripts under: $SearchRoot"
$includeMatchers = @(
  $Include | ForEach-Object {
    if ($_ -and $_.Trim()) {
      [System.Management.Automation.WildcardPattern]::new($_.Trim(),'IgnoreCase')
    }
  }
)
if ($includeMatchers.Count -eq 0) {
  $includeMatchers = @([System.Management.Automation.WildcardPattern]::new('*','IgnoreCase'))
}
function Get-GitTrackedFiles {
  param()
  $gitDir = Join-Path $SearchRoot '.git'
  if (-not (Test-Path -LiteralPath $gitDir -PathType Container)) {
    return @()
  }
  Push-Location $SearchRoot
  try {
    $arguments = @('ls-files','-z','--','*.ps1','*.psm1')
    $output = & git @arguments 2>$null
    if ($LASTEXITCODE -ne 0 -or -not $output) {
      return @()
    }
    return $output -split "`0" | Where-Object { $_ }
  }
  finally {
    Pop-Location
  }
}
function Get-CodeSigningCert {
  param([string]$Thumbprint)
  if ($Thumbprint) {
    $c = Get-ChildItem Cert:\CurrentUser\My\$Thumbprint -ErrorAction SilentlyContinue
    if ($c) { return $c }
  }
  $c = Get-ChildItem Cert:\CurrentUser\My | Where-Object { $_.HasPrivateKey -and $_.EnhancedKeyUsageList.FriendlyName -contains 'Code Signing' } | Select-Object -First 1
  if (-not $c) { throw 'No suitable code-signing certificate found.' }
  return $c
}
$cert = Get-CodeSigningCert -Thumbprint $Thumbprint
$gitCandidates = Get-GitTrackedFiles
if ($gitCandidates.Count -gt 0) {
  Write-Host ("Discovered {0} git-tracked candidate(s) via ls-files." -f $gitCandidates.Count)
  $candidates = @(
    $gitCandidates | ForEach-Object {
      $path = Join-Path $SearchRoot $_
      if (Test-Path -LiteralPath $path -PathType Leaf) { Get-Item -LiteralPath $path }
    } | Where-Object { $_ }
  )
}
else {
  Write-Host 'git ls-files returned no matches; falling back to filesystem enumeration.'
  $candidates = @(Get-ChildItem -LiteralPath $SearchRoot -Recurse -File)
}
Write-Host ("Discovered {0} candidate file(s) before filtering." -f $candidates.Count)
$files = @($candidates | Where-Object {
  $rel = $_.FullName.Substring($SearchRoot.Length).TrimStart('\','/')
  if ($ExcludeDirs | Where-Object { $rel -like ("{0}\*" -f $_) }) {
    return $false
  }
  foreach ($matcher in $includeMatchers) {
    if ($matcher.IsMatch($_.Name)) { return $true }
  }
  return $false
})
$total = $files.Count
if ($total -eq 0) {
  Write-Warning 'No files matched the signing criteria; nothing to do.'
  return
}
$stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
$processed = 0
foreach ($f in $files) {
  $sig = Get-AuthenticodeSignature -LiteralPath $f.FullName
  if ($sig.Status -ne 'Valid') {
    if ($SkipTimestamp) {
      Write-Verbose ("Signing {0} without timestamp (ephemeral cert)." -f $f.FullName)
      $null = Set-AuthenticodeSignature -LiteralPath $f.FullName -Certificate $cert
    }
    else {
      Write-Verbose ("Signing {0} with timestamp server." -f $f.FullName)
      $null = Set-AuthenticodeSignature -LiteralPath $f.FullName -Certificate $cert -TimestampServer 'http://timestamp.digicert.com'
    }
  }
  $processed++
  $logCheckpoint = ($ProgressInterval -gt 0) -and (($processed -eq 1) -or ($processed % $ProgressInterval -eq 0) -or ($processed -eq $total))
  if ($logCheckpoint) {
    Write-Host ("[{0}/{1}] Last signed: {2}" -f $processed, $total, $f.FullName)
  }
  if ($ThrottleMilliseconds -gt 0) {
    Start-Sleep -Milliseconds $ThrottleMilliseconds
  }
}
$stopwatch.Stop()
Write-Output ("Signed {0} script(s) in {1:n2}s." -f $processed, $stopwatch.Elapsed.TotalSeconds)

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDYpfv9H/2BrGi3
# 0MwBmTlEqdu/5KsCsUUBa2BGGZtVxKCCAxYwggMSMIIB+qADAgECAhAQBh94RrM0
# pkG29b582wzNMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTU1ODMyWhcNMjUxMTI3MTYwODMyWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAu0OCpGJsxZMNwAqH36MTeB8Qbtt5jqW43/vNfBunYydi
# xhr16Kpr0laUaOkOVdiaxnVt+rzddKz9T4fzQ+vSjTWFPx2TQBA1f/QO9ssZONw/
# l29KRq9fbgnbsd7ziy9LvoPGkMzdEZTL9HThyULD5CZvauJNbRiXYLa6vfDiNAYP
# 2pGh62ERQ9lLbcNlrSPvCrlccf77+Ixu5e5I5GegKguvIKmADgRTIBSW8rXWFxT6
# 0JU59WljIxDyMoGJBMWTdPTLYcTcrgkW2r4FtjOMK+3gO5rBRxDzRAkiI55UlFWx
# XjYcDEWUEfHDSxABGEX6FZK1/woW8CgdOQ7HaZWVTQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFLyQGhfoPEUw
# I/lxey6B2aWx2o1wMA0GCSqGSIb3DQEBCwUAA4IBAQAAQQ4xu+xqsttHx7CirXVf
# 5P63tZNVxHc3sgm9hay3eiMirpnzL0/iv4Cqe460eNVig7W86B/8W5cw0kL9uuae
# /vpv9zJCu7K5DDPsSaL5vAbGCTlyt5VjKtmK1VVePYCoh+m4MYPahkGRoBqRZrA2
# 5I9QHn5RrF68gIwm8KCPChPdrZTnDCpBN9NMlEYgJX6Lc0uoDOPQl09qlo4vky4U
# /0vodiO6MnFxp/EQdpFSdk/MutBn549f86cXJYiEx0grp61YcBxwin+yae39qwNb
# WyriXoFrwbmTk0/acc3prYmPg+JHRaVxihfpJ6KywbZ18pGozGlcoMSSwVlX/4Su
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAQBh94RrM0pkG29b582wzNMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIBiG+2ADMClH
# s6Yi2OyfzhR1yY57aD5XUqXcEBcdbcrjMA0GCSqGSIb3DQEBAQUABIIBACiC7c0I
# wcFTNAAYTMzYECPFWjFDeldDZM39Vg94X87OlQC8+XBVZGk66ghCKx9KGH3kbOi5
# 0IbX19oDNn0TxB8shu2qYZeKEIbpCAUWRPcPEyUx/8SiGRsPowoZaxT3fHTMPr2f
# 4b3pstCwO1pmwd+uJ3ObIdclnYj+34aNtrP+neKuy44W7Tnrom3eGoY/qv1UNOvV
# B28cWrN6paHswAjgrJ4H7lsUwPOowuZBtPN/tCAj6AqSQ9WRnU/3rp26HgGW54sz
# /PM9v0NAQPcnRluv3BO+iULDW2akfKZ01aYK16vUKTejihCuw0x1q4aQY5S8uSDh
# 59kYAlrhWdkXPtI=
# SIG # End signature block
