[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$ConfigPath,
  [Parameter()][string]$SchemaPath = (Join-Path $PSScriptRoot '..' 'configs' 'schema' 'vi-diff-heuristics.schema.json')
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'
. (Join-Path $PSScriptRoot 'Redaction.ps1')
$cfgContent = Get-Content -LiteralPath $ConfigPath -Raw
# Basic JSON validity check
$null = $cfgContent | ConvertFrom-Json -ErrorAction Stop
# Schema validation (if schema exists)
if (Test-Path -LiteralPath $SchemaPath -PathType Leaf) {
  $cfgContent | Test-Json -SchemaFile $SchemaPath -ErrorAction Stop | Out-Null
}
Write-Output "Config validated successfully:" (Resolve-Path -LiteralPath $ConfigPath).Path

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAtM1F8YzQ4xa9F
# 7QuDGJd4jTwMhZsuR+3nhXLiXLTUlKCCAxYwggMSMIIB+qADAgECAhAQBh94RrM0
# pkG29b582wzNMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTU1ODMyWhcNMjUxMTI3MTYwODMyWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAu0OCpGJsxZMNwAqH36MTeB8Qbtt5jqW43/vNfBunYydi
# xhr16Kpr0laUaOkOVdiaxnVt+rzddKz9T4fzQ+vSjTWFPx2TQBA1f/QO9ssZONw/
# l29KRq9fbgnbsd7ziy9LvoPGkMzdEZTL9HThyULD5CZvauJNbRiXYLa6vfDiNAYP
# 2pGh62ERQ9lLbcNlrSPvCrlccf77+Ixu5e5I5GegKguvIKmADgRTIBSW8rXWFxT6
# 0JU59WljIxDyMoGJBMWTdPTLYcTcrgkW2r4FtjOMK+3gO5rBRxDzRAkiI55UlFWx
# XjYcDEWUEfHDSxABGEX6FZK1/woW8CgdOQ7HaZWVTQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFLyQGhfoPEUw
# I/lxey6B2aWx2o1wMA0GCSqGSIb3DQEBCwUAA4IBAQAAQQ4xu+xqsttHx7CirXVf
# 5P63tZNVxHc3sgm9hay3eiMirpnzL0/iv4Cqe460eNVig7W86B/8W5cw0kL9uuae
# /vpv9zJCu7K5DDPsSaL5vAbGCTlyt5VjKtmK1VVePYCoh+m4MYPahkGRoBqRZrA2
# 5I9QHn5RrF68gIwm8KCPChPdrZTnDCpBN9NMlEYgJX6Lc0uoDOPQl09qlo4vky4U
# /0vodiO6MnFxp/EQdpFSdk/MutBn549f86cXJYiEx0grp61YcBxwin+yae39qwNb
# WyriXoFrwbmTk0/acc3prYmPg+JHRaVxihfpJ6KywbZ18pGozGlcoMSSwVlX/4Su
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAQBh94RrM0pkG29b582wzNMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPGNlwZgDGGO
# 4eoZqf6qFtcbYyZe5LvdTuTwGIaPVsX8MA0GCSqGSIb3DQEBAQUABIIBAHFr9vDD
# 6iKYl+BfuC+wFdWGdxcI1b/iCd9tI+L5wCR3fCTzdgGbSxYSY0wwHmw8Weoi1moc
# VHLl0kKRRceBJbFK7Cij5Pzyn0B/67i9bE841SzoF25B6JJoNe++qiPBeIyVd+9m
# n04xmYgnEvG14d2FEch0yHaTtIYi+UALAlDQoCbcEfYQADY1c4hPyFfNOkrkzW+9
# ZKyLqwqobNuoJlEmbRu6U/gtg8TzO/dXL0BRUIQ/aRcVUVbW2kQ+wrQRRxENVfUI
# 26qmjsWwHdc4PUSkIHb4q3dRh6C1nHtZwP12zpncxqgThziMGkcnq8NXw7cbqFzl
# xx6CQLbQczCdKqE=
# SIG # End signature block
