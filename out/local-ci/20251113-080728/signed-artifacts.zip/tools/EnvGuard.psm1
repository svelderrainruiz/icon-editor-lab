# EnvGuard.psm1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Get-EnvSnapshot {
    [CmdletBinding()]
    param([string[]]$AllowList = @('PATH','TEMP','TMP','HOME','USERPROFILE'))
    $snap = @{}
    foreach ($name in [Environment]::GetEnvironmentVariables().Keys) {
        if ($AllowList -contains $name) { $snap[$name] = [Environment]::GetEnvironmentVariable($name,'Process') }
    }
    return $snap
}

function Set-EnvFromSnapshot {
    [CmdletBinding()]
    param([Parameter(Mandatory)][hashtable]$Snapshot)
    foreach ($k in $Snapshot.Keys) {
        [Environment]::SetEnvironmentVariable($k, [string]$Snapshot[$k], 'Process')
    }
}

Export-ModuleMember -Function Get-EnvSnapshot, Set-EnvFromSnapshot

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAzwwfWBljXiDkz
# 9AHE9bg618B2oMEor3Mbt2BkcXsxKKCCAxYwggMSMIIB+qADAgECAhAQBh94RrM0
# pkG29b582wzNMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTU1ODMyWhcNMjUxMTI3MTYwODMyWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAu0OCpGJsxZMNwAqH36MTeB8Qbtt5jqW43/vNfBunYydi
# xhr16Kpr0laUaOkOVdiaxnVt+rzddKz9T4fzQ+vSjTWFPx2TQBA1f/QO9ssZONw/
# l29KRq9fbgnbsd7ziy9LvoPGkMzdEZTL9HThyULD5CZvauJNbRiXYLa6vfDiNAYP
# 2pGh62ERQ9lLbcNlrSPvCrlccf77+Ixu5e5I5GegKguvIKmADgRTIBSW8rXWFxT6
# 0JU59WljIxDyMoGJBMWTdPTLYcTcrgkW2r4FtjOMK+3gO5rBRxDzRAkiI55UlFWx
# XjYcDEWUEfHDSxABGEX6FZK1/woW8CgdOQ7HaZWVTQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFLyQGhfoPEUw
# I/lxey6B2aWx2o1wMA0GCSqGSIb3DQEBCwUAA4IBAQAAQQ4xu+xqsttHx7CirXVf
# 5P63tZNVxHc3sgm9hay3eiMirpnzL0/iv4Cqe460eNVig7W86B/8W5cw0kL9uuae
# /vpv9zJCu7K5DDPsSaL5vAbGCTlyt5VjKtmK1VVePYCoh+m4MYPahkGRoBqRZrA2
# 5I9QHn5RrF68gIwm8KCPChPdrZTnDCpBN9NMlEYgJX6Lc0uoDOPQl09qlo4vky4U
# /0vodiO6MnFxp/EQdpFSdk/MutBn549f86cXJYiEx0grp61YcBxwin+yae39qwNb
# WyriXoFrwbmTk0/acc3prYmPg+JHRaVxihfpJ6KywbZ18pGozGlcoMSSwVlX/4Su
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAQBh94RrM0pkG29b582wzNMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIJlQaYHytxsd
# hJ21/Xd1OOTWhUd4iNiRCRC/DDWxp9vgMA0GCSqGSIb3DQEBAQUABIIBAE7uxfLv
# rSUTM5AXS7hpzgURNB6P0RsjyFPmTvSEXLBYej4zB6q90shD1ZKkUIdnlFTJEGTK
# zZE0F5nDcG6t5yvUMhOc/02QDvylwp9duVS3lMFkHRzRH+BRvA1WgA33ovPnVjgn
# zBKEv9HnI6JpxfHCsLuMTtfKJT81Lr6lnpdNFm3aZL2nSLYJyQ3bZzwA4PdaF69k
# e6loZDRCw/yrh4imGOzTMfAnBW0zWcXeAcYZk+I64AaOZaH+jENMDxMBCRLkzpvW
# JFxzXyqMXFu2WRP1k11vXaOLaWbISmHcDl1MyJS9MkI3eXbTWlqpGTIxByDbU3lp
# kj7EL1k57Lirp6w=
# SIG # End signature block
