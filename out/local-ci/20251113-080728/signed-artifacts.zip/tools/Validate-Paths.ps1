# Validate-Paths.ps1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Test-PathSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter()][switch]$RequireAbsolute
    )
    if ($Path -match '[;&|`]' -or $Path -match '\.\.') { return $false }
    try {
        $rp = Resolve-Path -LiteralPath $Path -ErrorAction Stop
        if ($RequireAbsolute -and -not ($rp.Path -match '^(?:[A-Za-z]:[\\/]|/)')) { return $false }
        return $true
    } catch { return $false }
}

function Validate-PathSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter()][switch]$RequireAbsolute
    )
    if (-not (Test-PathSafe -Path $Path -RequireAbsolute:$RequireAbsolute)) {
        throw "Unsafe or invalid path: $Path"
    }
    return (Resolve-Path -LiteralPath $Path).Path
}

Export-ModuleMember -Function Test-PathSafe, Validate-PathSafe

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBRKRGFgRiwJrUW
# ser+RbKUtmM3v2Ar6IG3lNNJMXHBxaCCAxYwggMSMIIB+qADAgECAhAQBh94RrM0
# pkG29b582wzNMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTU1ODMyWhcNMjUxMTI3MTYwODMyWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAu0OCpGJsxZMNwAqH36MTeB8Qbtt5jqW43/vNfBunYydi
# xhr16Kpr0laUaOkOVdiaxnVt+rzddKz9T4fzQ+vSjTWFPx2TQBA1f/QO9ssZONw/
# l29KRq9fbgnbsd7ziy9LvoPGkMzdEZTL9HThyULD5CZvauJNbRiXYLa6vfDiNAYP
# 2pGh62ERQ9lLbcNlrSPvCrlccf77+Ixu5e5I5GegKguvIKmADgRTIBSW8rXWFxT6
# 0JU59WljIxDyMoGJBMWTdPTLYcTcrgkW2r4FtjOMK+3gO5rBRxDzRAkiI55UlFWx
# XjYcDEWUEfHDSxABGEX6FZK1/woW8CgdOQ7HaZWVTQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFLyQGhfoPEUw
# I/lxey6B2aWx2o1wMA0GCSqGSIb3DQEBCwUAA4IBAQAAQQ4xu+xqsttHx7CirXVf
# 5P63tZNVxHc3sgm9hay3eiMirpnzL0/iv4Cqe460eNVig7W86B/8W5cw0kL9uuae
# /vpv9zJCu7K5DDPsSaL5vAbGCTlyt5VjKtmK1VVePYCoh+m4MYPahkGRoBqRZrA2
# 5I9QHn5RrF68gIwm8KCPChPdrZTnDCpBN9NMlEYgJX6Lc0uoDOPQl09qlo4vky4U
# /0vodiO6MnFxp/EQdpFSdk/MutBn549f86cXJYiEx0grp61YcBxwin+yae39qwNb
# WyriXoFrwbmTk0/acc3prYmPg+JHRaVxihfpJ6KywbZ18pGozGlcoMSSwVlX/4Su
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAQBh94RrM0pkG29b582wzNMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEINpvsU+HHb6K
# gYnFC+DOD7Pi21ghNNfHTvYHF7x5UIBMMA0GCSqGSIb3DQEBAQUABIIBAJmXDAnw
# fFRvKJ2QMj7Xksd76Ks8+teo9a840EX09kT+yAprFMA/kEDeRcpP8WlMU2Un43Xr
# EM0V/IMyTbpgK3+vd7tSHPKvniHBBujY/nxFhGqMqM/HfZCQCqsYjFeO8YOVPIJr
# j+wxFuyAyUNaV9fqQjtVJ631/zsxZh5B9SF0slIjQWpCC7/QXTCK2uc0kwofRJ6b
# OV2bm6JxlVvJSPoKm+uAt9gbVFLLL6Q/WjfVL92GL2CdDXbHpKG3wVjQ5ZQCoizx
# WbDOyjaTKfRpQTZcQAitl9qIunz+MOiTxd/FZMC/zCE6oV6fOynbZL1iqgvTa3ux
# oW4bMHFVyKnZl+0=
# SIG # End signature block
