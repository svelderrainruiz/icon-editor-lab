[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$ConfigPath,
  [Parameter()][string]$SchemaPath = (Join-Path $PSScriptRoot '..' 'configs' 'schema' 'vi-diff-heuristics.schema.json')
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'
. (Join-Path $PSScriptRoot 'Redaction.ps1')
$cfgContent = Get-Content -LiteralPath $ConfigPath -Raw
# Basic JSON validity check
$null = $cfgContent | ConvertFrom-Json -ErrorAction Stop
# Schema validation (if schema exists)
if (Test-Path -LiteralPath $SchemaPath -PathType Leaf) {
  $cfgContent | Test-Json -SchemaFile $SchemaPath -ErrorAction Stop | Out-Null
}
Write-Output "Config validated successfully:" (Resolve-Path -LiteralPath $ConfigPath).Path

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAtM1F8YzQ4xa9F
# 7QuDGJd4jTwMhZsuR+3nhXLiXLTUlKCCAxYwggMSMIIB+qADAgECAhBRIFsUaKkg
# oEOd1WsmpZ62MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMDk0ODAxWhcNMjUxMTI3MDk1ODAyWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA1fA1+c0y037SoQ0DuW2pdU31TQAyr/+HU2vy3y0kZNCy
# LQTJgW9Nnd9fyfVq4304vF3H803qaizXPlXhj7W8gkqm1wl5r7W45LWW+Ata8FMV
# PvpNneRX0lOlIBz3WPIUb6NmHZ5n7jaIoS6D7QZn0NuOpK9Xn8iS0MvTBnCee0/4
# eRTx3xbxtaBqKiAHUAQpswXEXAQSHdouGQmNDehkhyzkjrnb0d5k4+/cZC+QbmSY
# HjyNDGboJBc/hXLVppuKtORlFtmY/AzRImPyK8I4FIeVjoG3IXaLVSBDoKelTNYW
# ej4Tv/Q0/itqNQJFUvbCHvpq9YUvOy0LET58PTJ3tQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFLuGZAKGGqkE
# opKKfLOHvbLrzQahMA0GCSqGSIb3DQEBCwUAA4IBAQCem4OEcEznbj1lZTGHR+Fh
# t82xO1Mr5EvIlUyzPSIt49SKdVIMtlNY8GYSKiCIrjS3Qv0Df++kFh0NzAix/eTs
# bk72Jjf/5JYJxT969ULkz/bcvdgtRGpEzHHXL1oTdYzLDR42wKQ/dofuqjJcoyeD
# V+f3S09VrzBV9EBB/WZ5YJsmVJyEEXLnit81QqLth8iv7NG6tv0SSKxx6miReKQC
# YmfuRwV7qjSc13o6MrrElM4UiY7MA1qLPG9vUdF9k2AHrvqQg9KjbzVP0/+BjDlx
# t4nGlbyhveJZXY3av4UW1rKsC6CWU251S8H2lJnGw35mHE7bptIDbjqdzgcsReIQ
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBRIFsUaKkgoEOd1WsmpZ62MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPGNlwZgDGGO
# 4eoZqf6qFtcbYyZe5LvdTuTwGIaPVsX8MA0GCSqGSIb3DQEBAQUABIIBAGX2Xz/p
# yBxKnNWonN6LqBQAiKkWa8F0QbYJ5mlymt0WraUX1k79X+zSp3mdaVLE7pJiU4lf
# PuxNc2cbyuX0i2lGlITXb0JhU/vLHXH5keSkTWfh/D4OTpYT4l73GbQh7+2tpCmp
# gaeCHND5pVl7Nj2Odj5tWKJLUwpcIiNiOxX9rVnCsfkS5xR2Maa14z/uAlbvtkcw
# BpUcODbNeKDWpHSeiIbmwalK/Dfdc3myfKsUcLoi5ukyrF7qkJIi3oMCCIdX2Wvf
# Aaf40wA4viuiD8XMfm4Hi69xzxiQ2B3cmyBMim/RD73E0OfNtZwKuLpdRPT5yELI
# HGe/dbMbooJ57Is=
# SIG # End signature block
