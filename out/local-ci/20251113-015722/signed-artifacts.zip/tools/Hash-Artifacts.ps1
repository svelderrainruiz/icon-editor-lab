# Hash-Artifacts.ps1
[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$Root,
  [Parameter()][string]$Output = 'checksums.sha256'
)

Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'

$rootAbs = Resolve-Path -LiteralPath $Root -ErrorAction Stop
$rootPath = $rootAbs.ProviderPath
$items = Get-ChildItem -LiteralPath $rootPath -Recurse -File -ErrorAction Stop
$lines = New-Object System.Collections.Generic.List[string]
foreach ($i in $items) {
  $h = Get-FileHash -LiteralPath $i.FullName -Algorithm SHA256
  $relativePath = [System.IO.Path]::GetRelativePath($rootPath, $i.FullName)
  try {
    $lines.Add(("{0}  {1}" -f $h.Hash.ToLower(), $relativePath))
  } catch {
    throw "Failed to format hash entry for '$($i.FullName)' relative '$relativePath': $($_.Exception.Message)"
  }
}
$pathOut = Join-Path $rootPath $Output
$lines | Set-Content -LiteralPath $pathOut -Encoding UTF8 -NoNewline:$false
Write-Output "Wrote checksums to $pathOut"

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCASG2cZB9SxQNBP
# DwVC9asjKlcJItPjhuWB1EHHmj/2laCCAxYwggMSMIIB+qADAgECAhBRIFsUaKkg
# oEOd1WsmpZ62MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMDk0ODAxWhcNMjUxMTI3MDk1ODAyWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA1fA1+c0y037SoQ0DuW2pdU31TQAyr/+HU2vy3y0kZNCy
# LQTJgW9Nnd9fyfVq4304vF3H803qaizXPlXhj7W8gkqm1wl5r7W45LWW+Ata8FMV
# PvpNneRX0lOlIBz3WPIUb6NmHZ5n7jaIoS6D7QZn0NuOpK9Xn8iS0MvTBnCee0/4
# eRTx3xbxtaBqKiAHUAQpswXEXAQSHdouGQmNDehkhyzkjrnb0d5k4+/cZC+QbmSY
# HjyNDGboJBc/hXLVppuKtORlFtmY/AzRImPyK8I4FIeVjoG3IXaLVSBDoKelTNYW
# ej4Tv/Q0/itqNQJFUvbCHvpq9YUvOy0LET58PTJ3tQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFLuGZAKGGqkE
# opKKfLOHvbLrzQahMA0GCSqGSIb3DQEBCwUAA4IBAQCem4OEcEznbj1lZTGHR+Fh
# t82xO1Mr5EvIlUyzPSIt49SKdVIMtlNY8GYSKiCIrjS3Qv0Df++kFh0NzAix/eTs
# bk72Jjf/5JYJxT969ULkz/bcvdgtRGpEzHHXL1oTdYzLDR42wKQ/dofuqjJcoyeD
# V+f3S09VrzBV9EBB/WZ5YJsmVJyEEXLnit81QqLth8iv7NG6tv0SSKxx6miReKQC
# YmfuRwV7qjSc13o6MrrElM4UiY7MA1qLPG9vUdF9k2AHrvqQg9KjbzVP0/+BjDlx
# t4nGlbyhveJZXY3av4UW1rKsC6CWU251S8H2lJnGw35mHE7bptIDbjqdzgcsReIQ
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBRIFsUaKkgoEOd1WsmpZ62MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIFwh7Ia6nNVg
# FzrXU1zSmX6Kq7zfAQC5vDsMmiqye02wMA0GCSqGSIb3DQEBAQUABIIBAKLkIONp
# u8fm1tAh27HFowtbNACf9cvqQ9X/ViZM55dKypfXfDQNfkMOVBSW4IyV3d4+gDPu
# owR5xkBWGb+5Oajkc7xWTt3OebZDtYWbd1mrWsbudSRNrOy797WwmQ453zBxv2nb
# 0kki4qk9J/j0jffB2vuA6fqSFjKnAfvufC2dt+Ko4QLIf/WfQgVJq+Z4ikguvzQ5
# XNTG3m+TZD0UT5ajqIMT1A7gyVmaMGgJeyy8h7Bkgp+m7wTTi2GDNuv4c8+A2t36
# SpxaAHRvnrkkp4L+Ubo5Ew9Zf14zlmNNJizXsV1ly1roPVoyh7Xe2E8MjAKBfh4V
# y/5gvwcrBVUOyGE=
# SIG # End signature block
