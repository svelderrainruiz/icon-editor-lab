# Validate-Paths.ps1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Test-PathSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter()][switch]$RequireAbsolute
    )
    if ($Path -match '[;&|`]' -or $Path -match '\.\.') { return $false }
    try {
        $rp = Resolve-Path -LiteralPath $Path -ErrorAction Stop
        if ($RequireAbsolute -and -not ($rp.Path -match '^(?:[A-Za-z]:[\\/]|/)')) { return $false }
        return $true
    } catch { return $false }
}

function Validate-PathSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter()][switch]$RequireAbsolute
    )
    if (-not (Test-PathSafe -Path $Path -RequireAbsolute:$RequireAbsolute)) {
        throw "Unsafe or invalid path: $Path"
    }
    return (Resolve-Path -LiteralPath $Path).Path
}

Export-ModuleMember -Function Test-PathSafe, Validate-PathSafe

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBRKRGFgRiwJrUW
# ser+RbKUtmM3v2Ar6IG3lNNJMXHBxaCCAxYwggMSMIIB+qADAgECAhBRIFsUaKkg
# oEOd1WsmpZ62MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMDk0ODAxWhcNMjUxMTI3MDk1ODAyWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA1fA1+c0y037SoQ0DuW2pdU31TQAyr/+HU2vy3y0kZNCy
# LQTJgW9Nnd9fyfVq4304vF3H803qaizXPlXhj7W8gkqm1wl5r7W45LWW+Ata8FMV
# PvpNneRX0lOlIBz3WPIUb6NmHZ5n7jaIoS6D7QZn0NuOpK9Xn8iS0MvTBnCee0/4
# eRTx3xbxtaBqKiAHUAQpswXEXAQSHdouGQmNDehkhyzkjrnb0d5k4+/cZC+QbmSY
# HjyNDGboJBc/hXLVppuKtORlFtmY/AzRImPyK8I4FIeVjoG3IXaLVSBDoKelTNYW
# ej4Tv/Q0/itqNQJFUvbCHvpq9YUvOy0LET58PTJ3tQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFLuGZAKGGqkE
# opKKfLOHvbLrzQahMA0GCSqGSIb3DQEBCwUAA4IBAQCem4OEcEznbj1lZTGHR+Fh
# t82xO1Mr5EvIlUyzPSIt49SKdVIMtlNY8GYSKiCIrjS3Qv0Df++kFh0NzAix/eTs
# bk72Jjf/5JYJxT969ULkz/bcvdgtRGpEzHHXL1oTdYzLDR42wKQ/dofuqjJcoyeD
# V+f3S09VrzBV9EBB/WZ5YJsmVJyEEXLnit81QqLth8iv7NG6tv0SSKxx6miReKQC
# YmfuRwV7qjSc13o6MrrElM4UiY7MA1qLPG9vUdF9k2AHrvqQg9KjbzVP0/+BjDlx
# t4nGlbyhveJZXY3av4UW1rKsC6CWU251S8H2lJnGw35mHE7bptIDbjqdzgcsReIQ
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBRIFsUaKkgoEOd1WsmpZ62MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEINpvsU+HHb6K
# gYnFC+DOD7Pi21ghNNfHTvYHF7x5UIBMMA0GCSqGSIb3DQEBAQUABIIBAAZoB/vJ
# TQHpyJvteTbRMLL0MfaY/2PWrs9W/yWs87Pdbvk+QNxZnfxgpePS4Q2ssqqUu8pf
# 7bpmzsm/EXzwHgX5zmw2rw75N0Wu7VHonCcBNfd5Vy0Gdug8m21sHL0hEnK4ySpF
# bKTC3ZZfav35v66FsyXsSIBZpCFJp024CishoNJ+yH6+HmjbUT7yd9bDPZ7WtTr1
# 1D/GEx/gFPtaGuxd7yK+4CeNDu1Aw0TFHK2WA44PrKzBFTxb/EgnVBLgWOKV9M3j
# EnVw6b4htMbFRd5XTnG42aWx8cGWzqgkZ8hV7ikIDlYJQGmTqkUYI6DYI02o49VQ
# nAit+fYKjBnl9bk=
# SIG # End signature block
