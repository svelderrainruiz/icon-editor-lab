# Verify-Signatures.ps1
[CmdletBinding()]
param(
  [Parameter()][string]$SearchRoot = (Get-Location).Path,
  [Parameter()][string[]]$Include = @("*.ps1","*.psm1"),
  [Parameter()][string[]]$ExcludeDirs = @(".git",".github",".venv","node_modules")
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'
$files = Get-ChildItem -LiteralPath $SearchRoot -Recurse -File -Include $Include | Where-Object {
  $rel = $_.FullName.Substring($SearchRoot.Length).TrimStart('\','/')
  -not ($ExcludeDirs | ForEach-Object { $rel -like ("{0}\*" -f $_) })
}
$bad = @()
foreach ($f in $files) {
  $sig = Get-AuthenticodeSignature -LiteralPath $f.FullName
  if ($sig.Status -ne 'Valid') { $bad += [pscustomobject]@{ Path = $f.FullName; Status = $sig.Status } }
}
if ($bad.Count -gt 0) {
  $bad | Format-Table -AutoSize | Out-String | Write-Output
  throw "Signature check failed for $($bad.Count) file(s)."
}
Write-Output "All script signatures are VALID."

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDA5chJevy6MGSV
# tHJMuyIwbEkqLQdD7aRYKil20DYfiaCCAxYwggMSMIIB+qADAgECAhBRIFsUaKkg
# oEOd1WsmpZ62MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMDk0ODAxWhcNMjUxMTI3MDk1ODAyWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA1fA1+c0y037SoQ0DuW2pdU31TQAyr/+HU2vy3y0kZNCy
# LQTJgW9Nnd9fyfVq4304vF3H803qaizXPlXhj7W8gkqm1wl5r7W45LWW+Ata8FMV
# PvpNneRX0lOlIBz3WPIUb6NmHZ5n7jaIoS6D7QZn0NuOpK9Xn8iS0MvTBnCee0/4
# eRTx3xbxtaBqKiAHUAQpswXEXAQSHdouGQmNDehkhyzkjrnb0d5k4+/cZC+QbmSY
# HjyNDGboJBc/hXLVppuKtORlFtmY/AzRImPyK8I4FIeVjoG3IXaLVSBDoKelTNYW
# ej4Tv/Q0/itqNQJFUvbCHvpq9YUvOy0LET58PTJ3tQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFLuGZAKGGqkE
# opKKfLOHvbLrzQahMA0GCSqGSIb3DQEBCwUAA4IBAQCem4OEcEznbj1lZTGHR+Fh
# t82xO1Mr5EvIlUyzPSIt49SKdVIMtlNY8GYSKiCIrjS3Qv0Df++kFh0NzAix/eTs
# bk72Jjf/5JYJxT969ULkz/bcvdgtRGpEzHHXL1oTdYzLDR42wKQ/dofuqjJcoyeD
# V+f3S09VrzBV9EBB/WZ5YJsmVJyEEXLnit81QqLth8iv7NG6tv0SSKxx6miReKQC
# YmfuRwV7qjSc13o6MrrElM4UiY7MA1qLPG9vUdF9k2AHrvqQg9KjbzVP0/+BjDlx
# t4nGlbyhveJZXY3av4UW1rKsC6CWU251S8H2lJnGw35mHE7bptIDbjqdzgcsReIQ
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBRIFsUaKkgoEOd1WsmpZ62MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIIEZpCeYMGc2
# kHxmC59rnv7kFfu0+1EDOsevLQv84+74MA0GCSqGSIb3DQEBAQUABIIBACe/L+yk
# cxqMD9iY0x3PB8hSwgNM+axVV1QzwU82oz34AgmZcNe6cjmghDDHAB0TI+ELrahb
# 1SjDzA/G5F3lIj1tKlWhSGKxEwyGGaMd7b1FTkD6/yKLL604LCQmNNV+M1eAlGt1
# 5fMPoyrCcwv6S+mZsaEdKLwSLpUh1PpDZ0Lcbzxd9NPaGmHU6z4QogVfCioJBOVg
# UtUUfJStxbp0sSXJUFG/HJBuVZWUCu2XBKYQzqsr0p0pwBDnMFPDdiDjxZlwSJ3j
# W4qCtLCK7CJajg6bWP6V0jbrCtm5Q6d6xP5dG144sXueKSkdOFVWE8NXLMKl0MT9
# CnrcEGMtIRibZfo=
# SIG # End signature block
