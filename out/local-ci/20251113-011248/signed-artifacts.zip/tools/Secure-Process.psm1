# Secure-Process.psm1
Set-StrictMode -Version Latest
. (Join-Path $PSScriptRoot 'Validate-Paths.ps1')
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Invoke-ProcessSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$FilePath,
        [Parameter()][string[]]$ArgumentList = @(),
        [Parameter()][int]$TimeoutSec = 600,
        [Parameter()][string]$WorkingDirectory = (Get-Location).Path
    )
    if (-not (Test-Path -LiteralPath $FilePath -PathType Leaf)) { throw "FilePath not found: $FilePath" }
    $psi = [System.Diagnostics.ProcessStartInfo]::new()
    $psi.FileName = $FilePath
    $psi.WorkingDirectory = (Validate-PathSafe -Path $WorkingDirectory)
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.UseShellExecute = $false
    foreach ($a in $ArgumentList) { $null = $psi.ArgumentList.Add($a) }

    $p = [System.Diagnostics.Process]::new()
    $p.StartInfo = $psi
    if (-not $p.Start()) { throw "Failed to start process: $FilePath" }
    try {
        if (-not $p.WaitForExit($TimeoutSec * 1000)) {
            try { $p.Kill($true) } catch {}
            throw "Process timed out after $TimeoutSec s: $FilePath"
        }
        $stdout = $p.StandardOutput.ReadToEnd()
        $stderr = $p.StandardError.ReadToEnd()
        return [pscustomobject]@{
            ExitCode = $p.ExitCode
            StdOut = $stdout
            StdErr = $stderr
        }
    } finally {
        if (-not $p.HasExited) { try { $p.Kill($true) } catch {} }
        $p.Dispose()
    }
}
Export-ModuleMember -Function Invoke-ProcessSafe

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDLM/hZ77J6ko3k
# J1T1SnSI3Zjg9T8EF5sOyyHIvgXLgqCCAxYwggMSMIIB+qADAgECAhAcFJ14gOOl
# okeE3KFfsmzRMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMDkwMzI4WhcNMjUxMTI3MDkxMzI4WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAuiQ+QPZOecNDApSSKpj5zEgcjhDeTL0QDMV4Q4lVqzBM
# oTPecyvpakD/yKVgfhCgeFH2MIdB0+15gN/Sn9FCTj4aBVP8EMvmfHMeA2R/1r5C
# eN2rIBay+Um/U4DnErTfmW4mSNcy6DjKRO5LELjx9h+cdx+qi0lzUZHsVn6nRsgM
# EHoam63rW/vo96gQaFH4PHBZ94Jx1nzQusnaMYR0PLdyIsNXkRXHHFg0zKOQXMET
# F5TH4cY3okZCrx/sBqJW5Z6C8JOmg2B341UGNNTw/RAAQ3kEeG8lDSILFfyogxgk
# 9Me37X6d2iwCbZwCH7zhw0Fbe0EHLgelBwe0P64cXQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFFV9ipqey6kK
# sRSxK/9csek7aFFYMA0GCSqGSIb3DQEBCwUAA4IBAQAUKdL+AqD43eXLacUKYwFM
# F2StkuHhT0pbZAo4RtwzdWBZFC1Y2nKW0k8ZdyZFGJsYjGq4BMQpWXCMwokEfRTz
# kfqavooU1WPU/wp4q7omBYNhSU5kNUDpNsbMA5/VKTLx7ABO2uRaf5W2RkBFXJEj
# O2MdShgobF+pV4TGrFbBbyNMdu8JNYA/4SY4hqE183mzsdk4TSnS+JIY0ZEttc1u
# JDzpb2Qz5B0j4/LamVWK83R7M3WLRlcpNZHvxPYtKfI41+6n0yCtMqo7IGwKuW4X
# NH3Fe93HTF4CJ6/LD7gzN7uBVkx5+3jQATuJME/omyunz3ihZkI5x51vOUgbhwsc
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAcFJ14gOOlokeE3KFfsmzRMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPEK5pYr/oiP
# 6zXDh72ZtLHO5VLyj1aDMXhTjDbbSs4wMA0GCSqGSIb3DQEBAQUABIIBABBUvT+l
# Ixfc1hhhV7ERZQ4ARtgCOJov25PKPrAPlyS0RyrRz+8fxf1d0npfsqKZXlWzgS+3
# 0oI2SAEcyHvE3OFpn17wNN86Do4EXp5zgJ3fmd3a9rj4GIvy3ij6KsgSuqeuogq2
# BP98cSkpofSB8/rnrn2dqbIzHKSqwgo12EINzVqeE4EA65BXMZDNLFqAqqhLhK/2
# PcYO19SP4WydExFCeXKOJHnKo8JAdYMuCrxLqIwLh41enAi05ZY1ofBZC8LQ+JKd
# YHEVth7pGOohQ+OCcY3Dy29cS2Tl4wtPmXRXitn33uQOmbz9UY6ULbAZTqU6Qmv7
# ttSyKj79XI8+cDg=
# SIG # End signature block
