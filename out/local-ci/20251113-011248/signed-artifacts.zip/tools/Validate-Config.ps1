[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$ConfigPath,
  [Parameter()][string]$SchemaPath = (Join-Path $PSScriptRoot '..' 'configs' 'schema' 'vi-diff-heuristics.schema.json')
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'
. (Join-Path $PSScriptRoot 'Redaction.ps1')
$cfgContent = Get-Content -LiteralPath $ConfigPath -Raw
# Basic JSON validity check
$null = $cfgContent | ConvertFrom-Json -ErrorAction Stop
# Schema validation (if schema exists)
if (Test-Path -LiteralPath $SchemaPath -PathType Leaf) {
  $cfgContent | Test-Json -SchemaFile $SchemaPath -ErrorAction Stop | Out-Null
}
Write-Output "Config validated successfully:" (Resolve-Path -LiteralPath $ConfigPath).Path

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAtM1F8YzQ4xa9F
# 7QuDGJd4jTwMhZsuR+3nhXLiXLTUlKCCAxYwggMSMIIB+qADAgECAhAcFJ14gOOl
# okeE3KFfsmzRMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMDkwMzI4WhcNMjUxMTI3MDkxMzI4WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAuiQ+QPZOecNDApSSKpj5zEgcjhDeTL0QDMV4Q4lVqzBM
# oTPecyvpakD/yKVgfhCgeFH2MIdB0+15gN/Sn9FCTj4aBVP8EMvmfHMeA2R/1r5C
# eN2rIBay+Um/U4DnErTfmW4mSNcy6DjKRO5LELjx9h+cdx+qi0lzUZHsVn6nRsgM
# EHoam63rW/vo96gQaFH4PHBZ94Jx1nzQusnaMYR0PLdyIsNXkRXHHFg0zKOQXMET
# F5TH4cY3okZCrx/sBqJW5Z6C8JOmg2B341UGNNTw/RAAQ3kEeG8lDSILFfyogxgk
# 9Me37X6d2iwCbZwCH7zhw0Fbe0EHLgelBwe0P64cXQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFFV9ipqey6kK
# sRSxK/9csek7aFFYMA0GCSqGSIb3DQEBCwUAA4IBAQAUKdL+AqD43eXLacUKYwFM
# F2StkuHhT0pbZAo4RtwzdWBZFC1Y2nKW0k8ZdyZFGJsYjGq4BMQpWXCMwokEfRTz
# kfqavooU1WPU/wp4q7omBYNhSU5kNUDpNsbMA5/VKTLx7ABO2uRaf5W2RkBFXJEj
# O2MdShgobF+pV4TGrFbBbyNMdu8JNYA/4SY4hqE183mzsdk4TSnS+JIY0ZEttc1u
# JDzpb2Qz5B0j4/LamVWK83R7M3WLRlcpNZHvxPYtKfI41+6n0yCtMqo7IGwKuW4X
# NH3Fe93HTF4CJ6/LD7gzN7uBVkx5+3jQATuJME/omyunz3ihZkI5x51vOUgbhwsc
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAcFJ14gOOlokeE3KFfsmzRMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPGNlwZgDGGO
# 4eoZqf6qFtcbYyZe5LvdTuTwGIaPVsX8MA0GCSqGSIb3DQEBAQUABIIBAAJDTchN
# r387856hRwczRaRGzD01ttEKPvf73c3KFq6mw+Xakbp8MM6yjAnIdhUOewRvFgyj
# C3T0eRSHh5idOfmK1svMaE+FgEnCcwxpCT6NqRYhCAPX4tpZbqVnaxLzOYSaNM/Q
# fyoIte5PGINNiFpKCZ0ugS4/rZyN3BTWiAFnyn1CN6UImrCn6lZI6VzjPBgK2oog
# BkA0Mx3ph3oH9Srw7ra/mNhUJVJHBzLPUrsry0h33jLx0zrLlqhCceH1ohEEEDie
# PdB/Dz5UcwIUkn0UqwdNw0hxV5KkARIa1e7OkgP7HJAzhOqvciGfYdUvBrl2dmvq
# /zm+xcdOaHD2I2Q=
# SIG # End signature block
