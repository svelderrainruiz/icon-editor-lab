# EnvGuard.psm1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Get-EnvSnapshot {
    [CmdletBinding()]
    param([string[]]$AllowList = @('PATH','TEMP','TMP','HOME','USERPROFILE'))
    $snap = @{}
    foreach ($name in [Environment]::GetEnvironmentVariables().Keys) {
        if ($AllowList -contains $name) { $snap[$name] = [Environment]::GetEnvironmentVariable($name,'Process') }
    }
    return $snap
}

function Set-EnvFromSnapshot {
    [CmdletBinding()]
    param([Parameter(Mandatory)][hashtable]$Snapshot)
    foreach ($k in $Snapshot.Keys) {
        [Environment]::SetEnvironmentVariable($k, [string]$Snapshot[$k], 'Process')
    }
}

Export-ModuleMember -Function Get-EnvSnapshot, Set-EnvFromSnapshot

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAzwwfWBljXiDkz
# 9AHE9bg618B2oMEor3Mbt2BkcXsxKKCCAxYwggMSMIIB+qADAgECAhAcFJ14gOOl
# okeE3KFfsmzRMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMDkwMzI4WhcNMjUxMTI3MDkxMzI4WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAuiQ+QPZOecNDApSSKpj5zEgcjhDeTL0QDMV4Q4lVqzBM
# oTPecyvpakD/yKVgfhCgeFH2MIdB0+15gN/Sn9FCTj4aBVP8EMvmfHMeA2R/1r5C
# eN2rIBay+Um/U4DnErTfmW4mSNcy6DjKRO5LELjx9h+cdx+qi0lzUZHsVn6nRsgM
# EHoam63rW/vo96gQaFH4PHBZ94Jx1nzQusnaMYR0PLdyIsNXkRXHHFg0zKOQXMET
# F5TH4cY3okZCrx/sBqJW5Z6C8JOmg2B341UGNNTw/RAAQ3kEeG8lDSILFfyogxgk
# 9Me37X6d2iwCbZwCH7zhw0Fbe0EHLgelBwe0P64cXQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFFV9ipqey6kK
# sRSxK/9csek7aFFYMA0GCSqGSIb3DQEBCwUAA4IBAQAUKdL+AqD43eXLacUKYwFM
# F2StkuHhT0pbZAo4RtwzdWBZFC1Y2nKW0k8ZdyZFGJsYjGq4BMQpWXCMwokEfRTz
# kfqavooU1WPU/wp4q7omBYNhSU5kNUDpNsbMA5/VKTLx7ABO2uRaf5W2RkBFXJEj
# O2MdShgobF+pV4TGrFbBbyNMdu8JNYA/4SY4hqE183mzsdk4TSnS+JIY0ZEttc1u
# JDzpb2Qz5B0j4/LamVWK83R7M3WLRlcpNZHvxPYtKfI41+6n0yCtMqo7IGwKuW4X
# NH3Fe93HTF4CJ6/LD7gzN7uBVkx5+3jQATuJME/omyunz3ihZkI5x51vOUgbhwsc
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAcFJ14gOOlokeE3KFfsmzRMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIJlQaYHytxsd
# hJ21/Xd1OOTWhUd4iNiRCRC/DDWxp9vgMA0GCSqGSIb3DQEBAQUABIIBAA8iiXyI
# aQFjCQC1GYZKATxjYbVofw+Xx+OKvPrhPIsf1YXmO4tIibwvtnt6TzXrlMcnxPSn
# F/uxSKWWAkOnHZ2ds0Hh8boP7xwfH9KFRBPz5DZoNYU2ZgS/2+o+pzN8abPxM0nv
# DttWLBWqAEWyAr4DNcnVBOgr/wbn1LPm9Xczl+OIyNNjgbxFJ0/LXTWaDNTKEQC3
# mQVw/z13XS40q6gYftNgUp9feVaRq7I6r2cpcIum6bXKi3CzuEXSfYRZNM6iCOoZ
# 9UbAXPTgBRnPTKUqK44PirWmcHVr52+i6DCX8YhcFEdiuBGOEEJCvDe08DDxmJlb
# Kr9XzIwgEYgeskQ=
# SIG # End signature block
