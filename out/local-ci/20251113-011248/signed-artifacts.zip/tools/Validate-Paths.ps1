# Validate-Paths.ps1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Test-PathSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter()][switch]$RequireAbsolute
    )
    if ($Path -match '[;&|`]' -or $Path -match '\.\.') { return $false }
    try {
        $rp = Resolve-Path -LiteralPath $Path -ErrorAction Stop
        if ($RequireAbsolute -and -not ($rp.Path -match '^(?:[A-Za-z]:[\\/]|/)')) { return $false }
        return $true
    } catch { return $false }
}

function Validate-PathSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter()][switch]$RequireAbsolute
    )
    if (-not (Test-PathSafe -Path $Path -RequireAbsolute:$RequireAbsolute)) {
        throw "Unsafe or invalid path: $Path"
    }
    return (Resolve-Path -LiteralPath $Path).Path
}

Export-ModuleMember -Function Test-PathSafe, Validate-PathSafe

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBRKRGFgRiwJrUW
# ser+RbKUtmM3v2Ar6IG3lNNJMXHBxaCCAxYwggMSMIIB+qADAgECAhAcFJ14gOOl
# okeE3KFfsmzRMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMDkwMzI4WhcNMjUxMTI3MDkxMzI4WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAuiQ+QPZOecNDApSSKpj5zEgcjhDeTL0QDMV4Q4lVqzBM
# oTPecyvpakD/yKVgfhCgeFH2MIdB0+15gN/Sn9FCTj4aBVP8EMvmfHMeA2R/1r5C
# eN2rIBay+Um/U4DnErTfmW4mSNcy6DjKRO5LELjx9h+cdx+qi0lzUZHsVn6nRsgM
# EHoam63rW/vo96gQaFH4PHBZ94Jx1nzQusnaMYR0PLdyIsNXkRXHHFg0zKOQXMET
# F5TH4cY3okZCrx/sBqJW5Z6C8JOmg2B341UGNNTw/RAAQ3kEeG8lDSILFfyogxgk
# 9Me37X6d2iwCbZwCH7zhw0Fbe0EHLgelBwe0P64cXQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFFV9ipqey6kK
# sRSxK/9csek7aFFYMA0GCSqGSIb3DQEBCwUAA4IBAQAUKdL+AqD43eXLacUKYwFM
# F2StkuHhT0pbZAo4RtwzdWBZFC1Y2nKW0k8ZdyZFGJsYjGq4BMQpWXCMwokEfRTz
# kfqavooU1WPU/wp4q7omBYNhSU5kNUDpNsbMA5/VKTLx7ABO2uRaf5W2RkBFXJEj
# O2MdShgobF+pV4TGrFbBbyNMdu8JNYA/4SY4hqE183mzsdk4TSnS+JIY0ZEttc1u
# JDzpb2Qz5B0j4/LamVWK83R7M3WLRlcpNZHvxPYtKfI41+6n0yCtMqo7IGwKuW4X
# NH3Fe93HTF4CJ6/LD7gzN7uBVkx5+3jQATuJME/omyunz3ihZkI5x51vOUgbhwsc
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAcFJ14gOOlokeE3KFfsmzRMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEINpvsU+HHb6K
# gYnFC+DOD7Pi21ghNNfHTvYHF7x5UIBMMA0GCSqGSIb3DQEBAQUABIIBAIn61vtj
# uKKicM1XNiAUFfaWqzRsaJpsGdjp55UAeymVwXcI5cuGJWfU3jZFnVIGiJ20ueYk
# AoNPpO1KPFwx5ptKLPdGjQkeUaOgM5B23eiVQHJizWh3MuzobyclIQp+Eo0mM9rC
# JvW67Q0b4ZIt5ftKZD7jfI1V4qpABEVsMODbjoJ0yIFbuecCGwCPWvQ64GLb2lJZ
# lJt5QFyRVVdfeplsXr6is5hDK7d/6NDRb2/nifAvvvoKtUAWfpOzD8QBj4FeVB4N
# eOC8PpIB/hNOZS+fyl2BYbgD2nuoc/8KfJDGQhNCdQXGqsw2sySm1DtPH/0WPK73
# V0zt8bkfauZ0nro=
# SIG # End signature block
