#Requires -Version 7.0
<#
.SYNOPSIS
  Consistent entry point for running the repository's Pester suite.

.DESCRIPTION
  Loads tests/Pester.runsettings.psd1, applies optional tag/exclude filters,
  and runs Invoke-Pester. When -CI is specified, writes JUnit output under
  out/test-results/pester.xml (creating the folder if needed).

.PARAMETER Tag
  Only run tests tagged with any of the specified values.

.PARAMETER ExcludeTag
  Skip tests tagged with any of the specified values.

.PARAMETER CI
  Enables JUnit output to out/test-results/pester.xml.
#>

[CmdletBinding()]
param(
  [string[]]$Tag,
  [string[]]$ExcludeTag,
  [switch]$CI
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repoRoot = Resolve-Path (Join-Path $PSScriptRoot '..')
$configPath = Join-Path $repoRoot 'tests' 'Pester.runsettings.psd1'
if (-not (Test-Path $configPath)) {
  throw "Pester configuration not found: $configPath"
}

$config = Import-PowerShellDataFile -LiteralPath $configPath

# Normalize relative paths based on repo root
$config.Run.Path = @(
  $config.Run.Path | ForEach-Object {
    (Resolve-Path (Join-Path $repoRoot $_)).ProviderPath
  }
)
$resolvedResultPath = Resolve-Path (Join-Path $repoRoot $config.TestResult.OutputPath) -ErrorAction SilentlyContinue
if ($resolvedResultPath) {
  $config.TestResult.OutputPath = $resolvedResultPath.ProviderPath
} else {
  $config.TestResult.OutputPath = Join-Path $repoRoot 'out/test-results/pester.xml'
}
if (-not $config.TestResult.OutputPath) {
  $config.TestResult.OutputPath = Join-Path $repoRoot 'out/test-results/pester.xml'
}

if ($Tag) {
  $config.Filter.Tag = @($Tag)
}
if ($ExcludeTag) {
  $config.Filter.ExcludeTag = @($ExcludeTag)
}

if ($CI) {
  $resultsPath = $config.TestResult.OutputPath
  $resultsDir = Split-Path $resultsPath -Parent
  if (-not (Test-Path $resultsDir)) { New-Item -ItemType Directory -Path $resultsDir -Force | Out-Null }
  $config.TestResult.Enabled = $true
  Write-Host "CI mode: writing Pester results to $resultsPath"
} else {
  $config.TestResult.Enabled = $false
}

Write-Host "Invoking Pester with tags: $($config.Filter.Tag -join ', ')" -ForegroundColor Cyan
Invoke-Pester -Configuration $config

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDYd2uoPAkTXPJb
# bn+j5BoktSlFrWLc2tx3vJ8l5hj/eaCCAxYwggMSMIIB+qADAgECAhAcFJ14gOOl
# okeE3KFfsmzRMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMDkwMzI4WhcNMjUxMTI3MDkxMzI4WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAuiQ+QPZOecNDApSSKpj5zEgcjhDeTL0QDMV4Q4lVqzBM
# oTPecyvpakD/yKVgfhCgeFH2MIdB0+15gN/Sn9FCTj4aBVP8EMvmfHMeA2R/1r5C
# eN2rIBay+Um/U4DnErTfmW4mSNcy6DjKRO5LELjx9h+cdx+qi0lzUZHsVn6nRsgM
# EHoam63rW/vo96gQaFH4PHBZ94Jx1nzQusnaMYR0PLdyIsNXkRXHHFg0zKOQXMET
# F5TH4cY3okZCrx/sBqJW5Z6C8JOmg2B341UGNNTw/RAAQ3kEeG8lDSILFfyogxgk
# 9Me37X6d2iwCbZwCH7zhw0Fbe0EHLgelBwe0P64cXQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFFV9ipqey6kK
# sRSxK/9csek7aFFYMA0GCSqGSIb3DQEBCwUAA4IBAQAUKdL+AqD43eXLacUKYwFM
# F2StkuHhT0pbZAo4RtwzdWBZFC1Y2nKW0k8ZdyZFGJsYjGq4BMQpWXCMwokEfRTz
# kfqavooU1WPU/wp4q7omBYNhSU5kNUDpNsbMA5/VKTLx7ABO2uRaf5W2RkBFXJEj
# O2MdShgobF+pV4TGrFbBbyNMdu8JNYA/4SY4hqE183mzsdk4TSnS+JIY0ZEttc1u
# JDzpb2Qz5B0j4/LamVWK83R7M3WLRlcpNZHvxPYtKfI41+6n0yCtMqo7IGwKuW4X
# NH3Fe93HTF4CJ6/LD7gzN7uBVkx5+3jQATuJME/omyunz3ihZkI5x51vOUgbhwsc
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAcFJ14gOOlokeE3KFfsmzRMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEII11SC6wt7Xz
# Nju6w2mLIcqzI70/iCgkEho6gi7yzw2NMA0GCSqGSIb3DQEBAQUABIIBAFHAASsK
# bEAeYzaCUODLQU6S3RsJd1fQ1p8E/QqyFIHtp6c9rHEYv2nSGU1c1ImWS+kqMm50
# fHQ3VzIGboC/x2pIKl6C7fcXe0NQK/n2FNIF7nBfvWuNksZqyuMDdpRbY6N73LJ2
# ktE9CYGLozZs0ury0Z/qEG1+dr56FUtB5RS4TkaQaw8sN+xlonBz7Phs1JljrVdE
# /wZlTW5QGbMf5PTs06a7hLDNMwTXX7oXBkXIN77tbb28EjT9O4Hb6MF7kf/1Gutc
# e7t8XmaJrPi6OIHaxfDqDEevY1jlIuttNBYqfNgeCFLq7ea0vN49CjHP6LMXzWtd
# 2ArzMmiw9YYJI60=
# SIG # End signature block
