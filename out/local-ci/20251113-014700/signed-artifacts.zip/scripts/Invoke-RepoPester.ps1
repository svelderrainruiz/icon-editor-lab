#Requires -Version 7.0
<#
.SYNOPSIS
  Consistent entry point for running the repository's Pester suite.

.DESCRIPTION
  Loads tests/Pester.runsettings.psd1, applies optional tag/exclude filters,
  and runs Invoke-Pester. When -CI is specified, writes JUnit output under
  out/test-results/pester.xml (creating the folder if needed).

.PARAMETER Tag
  Only run tests tagged with any of the specified values.

.PARAMETER ExcludeTag
  Skip tests tagged with any of the specified values.

.PARAMETER CI
  Enables JUnit output to out/test-results/pester.xml.
#>

[CmdletBinding()]
param(
  [string[]]$Tag,
  [string[]]$ExcludeTag,
  [switch]$CI
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repoRoot = Resolve-Path (Join-Path $PSScriptRoot '..')
$configPath = Join-Path $repoRoot 'tests' 'Pester.runsettings.psd1'
if (-not (Test-Path $configPath)) {
  throw "Pester configuration not found: $configPath"
}

$config = Import-PowerShellDataFile -LiteralPath $configPath

# Normalize relative paths based on repo root
$config.Run.Path = @(
  $config.Run.Path | ForEach-Object {
    (Resolve-Path (Join-Path $repoRoot $_)).ProviderPath
  }
)
$resolvedResultPath = Resolve-Path (Join-Path $repoRoot $config.TestResult.OutputPath) -ErrorAction SilentlyContinue
if ($resolvedResultPath) {
  $config.TestResult.OutputPath = $resolvedResultPath.ProviderPath
} else {
  $config.TestResult.OutputPath = Join-Path $repoRoot 'out/test-results/pester.xml'
}
if (-not $config.TestResult.OutputPath) {
  $config.TestResult.OutputPath = Join-Path $repoRoot 'out/test-results/pester.xml'
}

if ($Tag) {
  $config.Filter.Tag = @($Tag)
}
if ($ExcludeTag) {
  $config.Filter.ExcludeTag = @($ExcludeTag)
}

if ($CI) {
  $resultsPath = $config.TestResult.OutputPath
  $resultsDir = Split-Path $resultsPath -Parent
  if (-not (Test-Path $resultsDir)) { New-Item -ItemType Directory -Path $resultsDir -Force | Out-Null }
  $config.TestResult.Enabled = $true
  Write-Host "CI mode: writing Pester results to $resultsPath"
} else {
  $config.TestResult.Enabled = $false
}

Write-Host "Invoking Pester with tags: $($config.Filter.Tag -join ', ')" -ForegroundColor Cyan
Invoke-Pester -Configuration $config

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDYd2uoPAkTXPJb
# bn+j5BoktSlFrWLc2tx3vJ8l5hj/eaCCAxYwggMSMIIB+qADAgECAhBY5+CvfxyN
# oUPv27PfU9CaMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMDkzNzQxWhcNMjUxMTI3MDk0NzQxWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAzfPpZDrKEp2awZUuM4BzVIt57Lfa7SDDtd1sFyIc0Mwo
# Px+/dCetj72Q2jlzQFkAwShLJmbatKvPeRCpnEgncba5KF7/xxdfSckpIqX0G6oL
# 5QlGWdPbdzp0n+WbtvqfYI4dMhOM1b0POxpLq2wWIwoDALdXYfncAmVWq0j3Rp25
# dPp+NLuJRDakzz3kIbhYd3ReAlhPY6gmV1gMifWuLY1LpaLv+bOtnVsY/smHPb2M
# 3ngIXWYtwVeNfKQXJdGY8L9kAOekfUsAvr2RgHahOg92SVIMXsV1cicJDXcXWMTk
# AkSYYv15xwIWAOkzfyZzJt7VQ/1/mlo9NDkvEUU8lQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFA4SVlP60GMX
# ojoVfynQh9rir0HPMA0GCSqGSIb3DQEBCwUAA4IBAQB5m8H+BkYztZD/EviDfqcj
# CuLUHntyp83I73bn23k19ekZdnB7qoqSwi6f0KVczBvXE2qJxsdQC0cTSXm1f1Ii
# j9Z/iBiT5vbyuu771/8IhjG0GqcIGHG+ALA1pOONK1EFxEIF8p9opi61I1UnnVK5
# Ra9RY+iI1aIQivophZcJ/GACGkr6n3wPntJAtyoNVpv9QaapxDsqlYZ6lbImO8pg
# JnwJtEV7411V7BI+SRR1vZ9MP79CgzyRn4Siree8zTvYuAc8bo/za6QEGJm/Z8F8
# X48xkGzxZ1NfXyH46vCPW8IzfFETPJZXeZ0EH38UfDRN9GOCdIDbvIEW/rMgTBVm
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBY5+CvfxyNoUPv27PfU9CaMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEII11SC6wt7Xz
# Nju6w2mLIcqzI70/iCgkEho6gi7yzw2NMA0GCSqGSIb3DQEBAQUABIIBAEGFRd6J
# 73GlueNhOuwOtz/KuG7x9z+3lJmwaE7xO2c4dooN685My/6jAJNetMh3qzJZ//Aq
# ORne1oJmELJPWy2oXJ7s17EgFjxs6L7j5jIzBesnISNhoDeP5KKzYCz3pk2nVZRG
# GrNUkxzlKEZP4jFDl70YsHgQyFDZP8z9CVG4AtQbVxabmLYlOuE11REPhNhNRUgX
# Ns0kXGoA0XLvUpj0aIblxxFOHmBKOVXYTzJr0c7RJtc1pNs3RemdjNF9biIumw7i
# DnMmYajCIGsWpyA4kPvKA3114VWg2iPPJaNtuTc58lj+owKv/9B+2R/qeyth49KA
# GyLTfRzMPAT7iGs=
# SIG # End signature block
