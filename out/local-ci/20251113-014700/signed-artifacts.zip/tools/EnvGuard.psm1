# EnvGuard.psm1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Get-EnvSnapshot {
    [CmdletBinding()]
    param([string[]]$AllowList = @('PATH','TEMP','TMP','HOME','USERPROFILE'))
    $snap = @{}
    foreach ($name in [Environment]::GetEnvironmentVariables().Keys) {
        if ($AllowList -contains $name) { $snap[$name] = [Environment]::GetEnvironmentVariable($name,'Process') }
    }
    return $snap
}

function Set-EnvFromSnapshot {
    [CmdletBinding()]
    param([Parameter(Mandatory)][hashtable]$Snapshot)
    foreach ($k in $Snapshot.Keys) {
        [Environment]::SetEnvironmentVariable($k, [string]$Snapshot[$k], 'Process')
    }
}

Export-ModuleMember -Function Get-EnvSnapshot, Set-EnvFromSnapshot

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAzwwfWBljXiDkz
# 9AHE9bg618B2oMEor3Mbt2BkcXsxKKCCAxYwggMSMIIB+qADAgECAhBY5+CvfxyN
# oUPv27PfU9CaMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMDkzNzQxWhcNMjUxMTI3MDk0NzQxWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAzfPpZDrKEp2awZUuM4BzVIt57Lfa7SDDtd1sFyIc0Mwo
# Px+/dCetj72Q2jlzQFkAwShLJmbatKvPeRCpnEgncba5KF7/xxdfSckpIqX0G6oL
# 5QlGWdPbdzp0n+WbtvqfYI4dMhOM1b0POxpLq2wWIwoDALdXYfncAmVWq0j3Rp25
# dPp+NLuJRDakzz3kIbhYd3ReAlhPY6gmV1gMifWuLY1LpaLv+bOtnVsY/smHPb2M
# 3ngIXWYtwVeNfKQXJdGY8L9kAOekfUsAvr2RgHahOg92SVIMXsV1cicJDXcXWMTk
# AkSYYv15xwIWAOkzfyZzJt7VQ/1/mlo9NDkvEUU8lQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFA4SVlP60GMX
# ojoVfynQh9rir0HPMA0GCSqGSIb3DQEBCwUAA4IBAQB5m8H+BkYztZD/EviDfqcj
# CuLUHntyp83I73bn23k19ekZdnB7qoqSwi6f0KVczBvXE2qJxsdQC0cTSXm1f1Ii
# j9Z/iBiT5vbyuu771/8IhjG0GqcIGHG+ALA1pOONK1EFxEIF8p9opi61I1UnnVK5
# Ra9RY+iI1aIQivophZcJ/GACGkr6n3wPntJAtyoNVpv9QaapxDsqlYZ6lbImO8pg
# JnwJtEV7411V7BI+SRR1vZ9MP79CgzyRn4Siree8zTvYuAc8bo/za6QEGJm/Z8F8
# X48xkGzxZ1NfXyH46vCPW8IzfFETPJZXeZ0EH38UfDRN9GOCdIDbvIEW/rMgTBVm
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBY5+CvfxyNoUPv27PfU9CaMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIJlQaYHytxsd
# hJ21/Xd1OOTWhUd4iNiRCRC/DDWxp9vgMA0GCSqGSIb3DQEBAQUABIIBAGOQ8Tu6
# wjZMcAG4ibi/aV31s9+/SKTfwdU8mMFERxVusgMeWqbiW0y/21iYDJ7bhJ+RRpjE
# KIAakPfB5JG+I/HWgFykZpuUTJMYm5F65wB4V/of0+IIOOEGXyrQJpwvGz9hcCkI
# OnhL6Avp5vfumgatRDpxb9JbLIir9nT2YxJj2+gZmm/SasczhxrMlP4bUnTVaScQ
# nf3Jt1toRUEjYOaE75ASXI5+rJ7/tPkYg/74N1Nmx99eaik0b2mut+QfmDXZ9/Xl
# 6Afh38vtXH6N2wgCa9ADPv6hFofvaYt60bOMxe+qRqk4VLwYO52iNcnGKaEXLf6o
# FbR+P2Nz/QVkde4=
# SIG # End signature block
