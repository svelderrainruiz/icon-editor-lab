# Hash-Artifacts.ps1
[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$Root,
  [Parameter()][string]$Output = 'checksums.sha256'
)

Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'

$rootAbs = Resolve-Path -LiteralPath $Root -ErrorAction Stop
$rootPath = $rootAbs.ProviderPath
$items = Get-ChildItem -LiteralPath $rootPath -Recurse -File -ErrorAction Stop
$lines = New-Object System.Collections.Generic.List[string]
foreach ($i in $items) {
  $h = Get-FileHash -LiteralPath $i.FullName -Algorithm SHA256
  $relativePath = [System.IO.Path]::GetRelativePath($rootPath, $i.FullName)
  try {
    $lines.Add(("{0}  {1}" -f $h.Hash.ToLower(), $relativePath))
  } catch {
    throw "Failed to format hash entry for '$($i.FullName)' relative '$relativePath': $($_.Exception.Message)"
  }
}
$pathOut = Join-Path $rootPath $Output
$lines | Set-Content -LiteralPath $pathOut -Encoding UTF8 -NoNewline:$false
Write-Output "Wrote checksums to $pathOut"

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCASG2cZB9SxQNBP
# DwVC9asjKlcJItPjhuWB1EHHmj/2laCCAxYwggMSMIIB+qADAgECAhBY5+CvfxyN
# oUPv27PfU9CaMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMDkzNzQxWhcNMjUxMTI3MDk0NzQxWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAzfPpZDrKEp2awZUuM4BzVIt57Lfa7SDDtd1sFyIc0Mwo
# Px+/dCetj72Q2jlzQFkAwShLJmbatKvPeRCpnEgncba5KF7/xxdfSckpIqX0G6oL
# 5QlGWdPbdzp0n+WbtvqfYI4dMhOM1b0POxpLq2wWIwoDALdXYfncAmVWq0j3Rp25
# dPp+NLuJRDakzz3kIbhYd3ReAlhPY6gmV1gMifWuLY1LpaLv+bOtnVsY/smHPb2M
# 3ngIXWYtwVeNfKQXJdGY8L9kAOekfUsAvr2RgHahOg92SVIMXsV1cicJDXcXWMTk
# AkSYYv15xwIWAOkzfyZzJt7VQ/1/mlo9NDkvEUU8lQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFA4SVlP60GMX
# ojoVfynQh9rir0HPMA0GCSqGSIb3DQEBCwUAA4IBAQB5m8H+BkYztZD/EviDfqcj
# CuLUHntyp83I73bn23k19ekZdnB7qoqSwi6f0KVczBvXE2qJxsdQC0cTSXm1f1Ii
# j9Z/iBiT5vbyuu771/8IhjG0GqcIGHG+ALA1pOONK1EFxEIF8p9opi61I1UnnVK5
# Ra9RY+iI1aIQivophZcJ/GACGkr6n3wPntJAtyoNVpv9QaapxDsqlYZ6lbImO8pg
# JnwJtEV7411V7BI+SRR1vZ9MP79CgzyRn4Siree8zTvYuAc8bo/za6QEGJm/Z8F8
# X48xkGzxZ1NfXyH46vCPW8IzfFETPJZXeZ0EH38UfDRN9GOCdIDbvIEW/rMgTBVm
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBY5+CvfxyNoUPv27PfU9CaMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIFwh7Ia6nNVg
# FzrXU1zSmX6Kq7zfAQC5vDsMmiqye02wMA0GCSqGSIb3DQEBAQUABIIBAHp+SajM
# bagOONU4iOmhIpO9MIq3l+Xc1x+l3srhfssKRXXaA+hfb+3pWWyoxcoUF2tKZvg6
# ij79aJVr7vpuwXBjwXXp7SSV6bOiXClVmYNluL4ltshduzGb0+Yk6VJURQvfSAIS
# kfSKFsAwfgJsdD3otbo9chLfsoVur644ctGVZk8JlKx78mzAGhJ2fOVXf5oRpGAG
# 74ow1PdTG5bOrMMLSkuGRWo+UJ+xaXMxV+k6m7ljD6LCRD3E1flGPBNzVg8NI4YS
# 6dw67GDH7wZd/XZ63nLnEqfNYIJBvHCMKDRdMvDx6TUOFeeF0aOQmtJFcVxSwwXR
# Fz34SAA15gpCKj8=
# SIG # End signature block
