[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$ConfigPath,
  [Parameter()][string]$SchemaPath = (Join-Path $PSScriptRoot '..' 'configs' 'schema' 'vi-diff-heuristics.schema.json')
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'
. (Join-Path $PSScriptRoot 'Redaction.ps1')
$cfgContent = Get-Content -LiteralPath $ConfigPath -Raw
# Basic JSON validity check
$null = $cfgContent | ConvertFrom-Json -ErrorAction Stop
# Schema validation (if schema exists)
if (Test-Path -LiteralPath $SchemaPath -PathType Leaf) {
  $cfgContent | Test-Json -SchemaFile $SchemaPath -ErrorAction Stop | Out-Null
}
Write-Output "Config validated successfully:" (Resolve-Path -LiteralPath $ConfigPath).Path

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAtM1F8YzQ4xa9F
# 7QuDGJd4jTwMhZsuR+3nhXLiXLTUlKCCAxYwggMSMIIB+qADAgECAhBY5+CvfxyN
# oUPv27PfU9CaMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMDkzNzQxWhcNMjUxMTI3MDk0NzQxWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAzfPpZDrKEp2awZUuM4BzVIt57Lfa7SDDtd1sFyIc0Mwo
# Px+/dCetj72Q2jlzQFkAwShLJmbatKvPeRCpnEgncba5KF7/xxdfSckpIqX0G6oL
# 5QlGWdPbdzp0n+WbtvqfYI4dMhOM1b0POxpLq2wWIwoDALdXYfncAmVWq0j3Rp25
# dPp+NLuJRDakzz3kIbhYd3ReAlhPY6gmV1gMifWuLY1LpaLv+bOtnVsY/smHPb2M
# 3ngIXWYtwVeNfKQXJdGY8L9kAOekfUsAvr2RgHahOg92SVIMXsV1cicJDXcXWMTk
# AkSYYv15xwIWAOkzfyZzJt7VQ/1/mlo9NDkvEUU8lQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFA4SVlP60GMX
# ojoVfynQh9rir0HPMA0GCSqGSIb3DQEBCwUAA4IBAQB5m8H+BkYztZD/EviDfqcj
# CuLUHntyp83I73bn23k19ekZdnB7qoqSwi6f0KVczBvXE2qJxsdQC0cTSXm1f1Ii
# j9Z/iBiT5vbyuu771/8IhjG0GqcIGHG+ALA1pOONK1EFxEIF8p9opi61I1UnnVK5
# Ra9RY+iI1aIQivophZcJ/GACGkr6n3wPntJAtyoNVpv9QaapxDsqlYZ6lbImO8pg
# JnwJtEV7411V7BI+SRR1vZ9MP79CgzyRn4Siree8zTvYuAc8bo/za6QEGJm/Z8F8
# X48xkGzxZ1NfXyH46vCPW8IzfFETPJZXeZ0EH38UfDRN9GOCdIDbvIEW/rMgTBVm
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBY5+CvfxyNoUPv27PfU9CaMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPGNlwZgDGGO
# 4eoZqf6qFtcbYyZe5LvdTuTwGIaPVsX8MA0GCSqGSIb3DQEBAQUABIIBABjIfYiG
# 85Z3S/wTQOZCXvcVYsEPbY2Z45Lzms7QOwoyGUFf2Tdj0pYtG8mcHiJHxZEyFzxY
# kLwrpbJHu+xNnR1ntZo0oodsQJz/WtCw38VWbz2OMcfNwHRx3s6xQs7fXiohUTYe
# zbJkXk/OJfC3d2LyJbkWQ98XbKXC3wdnKD8Vb2JbT9K8iwm2Bj6TJWRVWOEj4e3k
# Z4ez0vD9L/SW31Cyo/NrovzaOnLPUxagQCSjQeoylkklJI/AqJaaujpO/GgHXzp/
# t03g4xFmiqhpBqprBMF1t81emxndjEgO8fi5OXV5DZHRHWOfIlLVaWy5xzMKYcUr
# CDTwv5eDiNlzPRE=
# SIG # End signature block
