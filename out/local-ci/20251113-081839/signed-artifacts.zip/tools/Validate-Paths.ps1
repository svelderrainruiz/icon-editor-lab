# Validate-Paths.ps1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Test-PathSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter()][switch]$RequireAbsolute
    )
    if ($Path -match '[;&|`]' -or $Path -match '\.\.') { return $false }
    try {
        $rp = Resolve-Path -LiteralPath $Path -ErrorAction Stop
        if ($RequireAbsolute -and -not ($rp.Path -match '^(?:[A-Za-z]:[\\/]|/)')) { return $false }
        return $true
    } catch { return $false }
}

function Validate-PathSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter()][switch]$RequireAbsolute
    )
    if (-not (Test-PathSafe -Path $Path -RequireAbsolute:$RequireAbsolute)) {
        throw "Unsafe or invalid path: $Path"
    }
    return (Resolve-Path -LiteralPath $Path).Path
}

Export-ModuleMember -Function Test-PathSafe, Validate-PathSafe

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBRKRGFgRiwJrUW
# ser+RbKUtmM3v2Ar6IG3lNNJMXHBxaCCAxYwggMSMIIB+qADAgECAhAWxW6npWic
# vkss74jDNG6/MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTYwOTU0WhcNMjUxMTI3MTYxOTU0WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA0y5m0hNMbpdBsBLRIa7tJ5ytVbfCwqXz0eHwOLmIl/0t
# y7T2XMav7sQ7AKf9DM+45ltmk06eFhBcfc0CBjGZ5n9kif1+9CEjmIb/mLbtIHn3
# s1vxFOcSt58qvppzzf2wpNfuCMV5s80SR1QoGjGjEoKTE6GsQYqBOPzerkgt6z8x
# l+yRyVitedtQDSfHLJSPUvUBuvgwwDuGEAfqQQMKjamxcCr3khqgjd9JkZa0dMRb
# RfZ0NuIIujI2F8FTtT9TNi0H4dFQtFwHBaVjNXr7MXb9758qJFjIKibZyEkt+SG/
# G7MkKB08HVQI37XY+NnUlet+lzCUn3rx3NQ8rIrYoQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFHF0qrrX4yrl
# 1LPVc4C694M9lNtlMA0GCSqGSIb3DQEBCwUAA4IBAQA2nFtjU9DXU7FmBzcWkx8J
# icUDqGCjcqY6cH95gyBzMCpnVemR/ga46spxB36ugaQQB3GAajXyv5Bs7dTM2chp
# lqdsPZawswkYE6y/ED9JSjCwch97TQclmo394SS0ExW9DwuPnbH2DURgigXOh2dC
# UuJauD8fNIDW6OX/MEq8YtD5YPh8vs0JooZETgiDLei7DIqhHBW4i1yFctcfABRU
# pdSGIUAHy5fxYXX1kOYJoY9k/HG/h+fO3LQVgrdJOu4oNagUmNVrZVdp2UQHzf3m
# 4rulzxtN1J2CLAZWoNHjebBa2tjX/F86GzYTArLPQ4IUuLq3xn/fyXnEd0Dh3GVq
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAWxW6npWicvkss74jDNG6/MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEINpvsU+HHb6K
# gYnFC+DOD7Pi21ghNNfHTvYHF7x5UIBMMA0GCSqGSIb3DQEBAQUABIIBAIupl6Sf
# YG57GhxZyYCftlQereng/iqZEJKc88KjSQL2avzM0Syc1Y1PjfNG+XXO3RlFdWBc
# mny4BBXDmomLI0w7pNZqXcGdSR34Y6UpX8v3OWF9UfqccmebXH91UFZ1n+3pOmhx
# JuoX1RsSgulhJ2IKj3vMD8EndQSQIAS977eRvqbnefg8ejFCXan0xrm+LCXmRKRd
# I7fmrZHxABuaG62BuJeb6BNFkJC1bn7Ds7YH8xmn9OQTv6SCG4f4n1pj9STROy2f
# tTjHBoiKuQocNEhn3EJNKCcXdI9fLsQTVN/PCDEXWTFSpI1anPBoCzl1mSj2C93n
# avebKlUs9AJbWJ8=
# SIG # End signature block
