# Hash-Artifacts.ps1
[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$Root,
  [Parameter()][string]$Output = 'checksums.sha256'
)

Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'

$rootAbs = Resolve-Path -LiteralPath $Root -ErrorAction Stop
$rootPath = $rootAbs.ProviderPath
$items = Get-ChildItem -LiteralPath $rootPath -Recurse -File -ErrorAction Stop
$lines = New-Object System.Collections.Generic.List[string]
foreach ($i in $items) {
  $h = Get-FileHash -LiteralPath $i.FullName -Algorithm SHA256
  $relativePath = [System.IO.Path]::GetRelativePath($rootPath, $i.FullName)
  try {
    $lines.Add(("{0}  {1}" -f $h.Hash.ToLower(), $relativePath))
  } catch {
    throw "Failed to format hash entry for '$($i.FullName)' relative '$relativePath': $($_.Exception.Message)"
  }
}
$pathOut = Join-Path $rootPath $Output
$lines | Set-Content -LiteralPath $pathOut -Encoding UTF8 -NoNewline:$false
Write-Output "Wrote checksums to $pathOut"

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCASG2cZB9SxQNBP
# DwVC9asjKlcJItPjhuWB1EHHmj/2laCCAxYwggMSMIIB+qADAgECAhAWxW6npWic
# vkss74jDNG6/MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTYwOTU0WhcNMjUxMTI3MTYxOTU0WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA0y5m0hNMbpdBsBLRIa7tJ5ytVbfCwqXz0eHwOLmIl/0t
# y7T2XMav7sQ7AKf9DM+45ltmk06eFhBcfc0CBjGZ5n9kif1+9CEjmIb/mLbtIHn3
# s1vxFOcSt58qvppzzf2wpNfuCMV5s80SR1QoGjGjEoKTE6GsQYqBOPzerkgt6z8x
# l+yRyVitedtQDSfHLJSPUvUBuvgwwDuGEAfqQQMKjamxcCr3khqgjd9JkZa0dMRb
# RfZ0NuIIujI2F8FTtT9TNi0H4dFQtFwHBaVjNXr7MXb9758qJFjIKibZyEkt+SG/
# G7MkKB08HVQI37XY+NnUlet+lzCUn3rx3NQ8rIrYoQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFHF0qrrX4yrl
# 1LPVc4C694M9lNtlMA0GCSqGSIb3DQEBCwUAA4IBAQA2nFtjU9DXU7FmBzcWkx8J
# icUDqGCjcqY6cH95gyBzMCpnVemR/ga46spxB36ugaQQB3GAajXyv5Bs7dTM2chp
# lqdsPZawswkYE6y/ED9JSjCwch97TQclmo394SS0ExW9DwuPnbH2DURgigXOh2dC
# UuJauD8fNIDW6OX/MEq8YtD5YPh8vs0JooZETgiDLei7DIqhHBW4i1yFctcfABRU
# pdSGIUAHy5fxYXX1kOYJoY9k/HG/h+fO3LQVgrdJOu4oNagUmNVrZVdp2UQHzf3m
# 4rulzxtN1J2CLAZWoNHjebBa2tjX/F86GzYTArLPQ4IUuLq3xn/fyXnEd0Dh3GVq
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAWxW6npWicvkss74jDNG6/MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIFwh7Ia6nNVg
# FzrXU1zSmX6Kq7zfAQC5vDsMmiqye02wMA0GCSqGSIb3DQEBAQUABIIBAK2kO49F
# hfbnakBGPAIhyhF7kTN7yajCUOC/jvq08c7VHjKviwwC7UM+/Elr8gJmM26W0WFB
# y5Kl/8DzLwwXeFsqt/9UssVjeODsuRsgCzpjzPhsHZT2jEuCZZ1SCT8Ch2FILuTF
# MEp39tU6mV+PxatAvBNX+uM5YGfo7i/M2IeMxmbp0nHUFSmt9ccy5C/zN6CiGoWo
# hI8elnzlXI7Q3EpoOLaEQ1mNtffUKfOuFEldLD82ceAVL+0vaHRiFNw/y4rl2oHo
# TRAymQPLfwM5l3eotW2n8wM7ENtyRzzaPNJp3yEDZQyJDmnB4mgd+VzQsI8u/Moc
# EpApvBo2myb/vUA=
# SIG # End signature block
