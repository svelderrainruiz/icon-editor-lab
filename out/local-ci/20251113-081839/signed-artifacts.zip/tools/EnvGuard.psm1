# EnvGuard.psm1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Get-EnvSnapshot {
    [CmdletBinding()]
    param([string[]]$AllowList = @('PATH','TEMP','TMP','HOME','USERPROFILE'))
    $snap = @{}
    foreach ($name in [Environment]::GetEnvironmentVariables().Keys) {
        if ($AllowList -contains $name) { $snap[$name] = [Environment]::GetEnvironmentVariable($name,'Process') }
    }
    return $snap
}

function Set-EnvFromSnapshot {
    [CmdletBinding()]
    param([Parameter(Mandatory)][hashtable]$Snapshot)
    foreach ($k in $Snapshot.Keys) {
        [Environment]::SetEnvironmentVariable($k, [string]$Snapshot[$k], 'Process')
    }
}

Export-ModuleMember -Function Get-EnvSnapshot, Set-EnvFromSnapshot

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAzwwfWBljXiDkz
# 9AHE9bg618B2oMEor3Mbt2BkcXsxKKCCAxYwggMSMIIB+qADAgECAhAWxW6npWic
# vkss74jDNG6/MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTYwOTU0WhcNMjUxMTI3MTYxOTU0WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA0y5m0hNMbpdBsBLRIa7tJ5ytVbfCwqXz0eHwOLmIl/0t
# y7T2XMav7sQ7AKf9DM+45ltmk06eFhBcfc0CBjGZ5n9kif1+9CEjmIb/mLbtIHn3
# s1vxFOcSt58qvppzzf2wpNfuCMV5s80SR1QoGjGjEoKTE6GsQYqBOPzerkgt6z8x
# l+yRyVitedtQDSfHLJSPUvUBuvgwwDuGEAfqQQMKjamxcCr3khqgjd9JkZa0dMRb
# RfZ0NuIIujI2F8FTtT9TNi0H4dFQtFwHBaVjNXr7MXb9758qJFjIKibZyEkt+SG/
# G7MkKB08HVQI37XY+NnUlet+lzCUn3rx3NQ8rIrYoQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFHF0qrrX4yrl
# 1LPVc4C694M9lNtlMA0GCSqGSIb3DQEBCwUAA4IBAQA2nFtjU9DXU7FmBzcWkx8J
# icUDqGCjcqY6cH95gyBzMCpnVemR/ga46spxB36ugaQQB3GAajXyv5Bs7dTM2chp
# lqdsPZawswkYE6y/ED9JSjCwch97TQclmo394SS0ExW9DwuPnbH2DURgigXOh2dC
# UuJauD8fNIDW6OX/MEq8YtD5YPh8vs0JooZETgiDLei7DIqhHBW4i1yFctcfABRU
# pdSGIUAHy5fxYXX1kOYJoY9k/HG/h+fO3LQVgrdJOu4oNagUmNVrZVdp2UQHzf3m
# 4rulzxtN1J2CLAZWoNHjebBa2tjX/F86GzYTArLPQ4IUuLq3xn/fyXnEd0Dh3GVq
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAWxW6npWicvkss74jDNG6/MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIJlQaYHytxsd
# hJ21/Xd1OOTWhUd4iNiRCRC/DDWxp9vgMA0GCSqGSIb3DQEBAQUABIIBAFhCLKyA
# Wip/6iDc7PKDjpblZs3RZlpn+PftIc1FK1LSZxGDUsJpQU/uthwdeWQiUXEvNaJL
# pm18RDLxgx5Pldg8YWqdSScd2fSpQsCA6G50mivuvx/VGI/+xxwYHOldbYc2aqz6
# TcbHdDrnZIbzbq7ruGKqkBfVIpHWEYJLV0j7xfEAHVS/d2HjxFlp7nlus2fTIOKJ
# u0OQsDwEu9yRqzHx9iMaO0Kw8pKsce8deLmuWtBzZprLpqvtz2C2oLPK4TBbBCi0
# QT70A4q/fSSRJH6IzqA4/mBSzoc7CiZy/DUtKVTW97enAUFl/+A3T7Y1WwroTutw
# irBqM9EEnO5Zlug=
# SIG # End signature block
