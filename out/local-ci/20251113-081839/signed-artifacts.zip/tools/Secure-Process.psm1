# Secure-Process.psm1
Set-StrictMode -Version Latest
. (Join-Path $PSScriptRoot 'Validate-Paths.ps1')
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Invoke-ProcessSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$FilePath,
        [Parameter()][string[]]$ArgumentList = @(),
        [Parameter()][int]$TimeoutSec = 600,
        [Parameter()][string]$WorkingDirectory = (Get-Location).Path
    )
    if (-not (Test-Path -LiteralPath $FilePath -PathType Leaf)) { throw "FilePath not found: $FilePath" }
    $psi = [System.Diagnostics.ProcessStartInfo]::new()
    $psi.FileName = $FilePath
    $psi.WorkingDirectory = (Validate-PathSafe -Path $WorkingDirectory)
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.UseShellExecute = $false
    foreach ($a in $ArgumentList) { $null = $psi.ArgumentList.Add($a) }

    $p = [System.Diagnostics.Process]::new()
    $p.StartInfo = $psi
    if (-not $p.Start()) { throw "Failed to start process: $FilePath" }
    try {
        if (-not $p.WaitForExit($TimeoutSec * 1000)) {
            try { $p.Kill($true) } catch {}
            throw "Process timed out after $TimeoutSec s: $FilePath"
        }
        $stdout = $p.StandardOutput.ReadToEnd()
        $stderr = $p.StandardError.ReadToEnd()
        return [pscustomobject]@{
            ExitCode = $p.ExitCode
            StdOut = $stdout
            StdErr = $stderr
        }
    } finally {
        if (-not $p.HasExited) { try { $p.Kill($true) } catch {} }
        $p.Dispose()
    }
}
Export-ModuleMember -Function Invoke-ProcessSafe

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDLM/hZ77J6ko3k
# J1T1SnSI3Zjg9T8EF5sOyyHIvgXLgqCCAxYwggMSMIIB+qADAgECAhAWxW6npWic
# vkss74jDNG6/MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTYwOTU0WhcNMjUxMTI3MTYxOTU0WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA0y5m0hNMbpdBsBLRIa7tJ5ytVbfCwqXz0eHwOLmIl/0t
# y7T2XMav7sQ7AKf9DM+45ltmk06eFhBcfc0CBjGZ5n9kif1+9CEjmIb/mLbtIHn3
# s1vxFOcSt58qvppzzf2wpNfuCMV5s80SR1QoGjGjEoKTE6GsQYqBOPzerkgt6z8x
# l+yRyVitedtQDSfHLJSPUvUBuvgwwDuGEAfqQQMKjamxcCr3khqgjd9JkZa0dMRb
# RfZ0NuIIujI2F8FTtT9TNi0H4dFQtFwHBaVjNXr7MXb9758qJFjIKibZyEkt+SG/
# G7MkKB08HVQI37XY+NnUlet+lzCUn3rx3NQ8rIrYoQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFHF0qrrX4yrl
# 1LPVc4C694M9lNtlMA0GCSqGSIb3DQEBCwUAA4IBAQA2nFtjU9DXU7FmBzcWkx8J
# icUDqGCjcqY6cH95gyBzMCpnVemR/ga46spxB36ugaQQB3GAajXyv5Bs7dTM2chp
# lqdsPZawswkYE6y/ED9JSjCwch97TQclmo394SS0ExW9DwuPnbH2DURgigXOh2dC
# UuJauD8fNIDW6OX/MEq8YtD5YPh8vs0JooZETgiDLei7DIqhHBW4i1yFctcfABRU
# pdSGIUAHy5fxYXX1kOYJoY9k/HG/h+fO3LQVgrdJOu4oNagUmNVrZVdp2UQHzf3m
# 4rulzxtN1J2CLAZWoNHjebBa2tjX/F86GzYTArLPQ4IUuLq3xn/fyXnEd0Dh3GVq
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAWxW6npWicvkss74jDNG6/MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPEK5pYr/oiP
# 6zXDh72ZtLHO5VLyj1aDMXhTjDbbSs4wMA0GCSqGSIb3DQEBAQUABIIBAHdAHbiC
# cnxkTLaJrdzAa+inYL0jpZxXtihszpcJoWVxlAvscnLwRC/hO4o4jLPLF6WHi8kh
# 6QKBkUDpJ1eYaySI1YM6hn6ls/5GHulVrctz6VGAoNA2iXsdAeRCTOvwpBa9xSVI
# 5ShlK2uUWuwkT3hRwqeDAbKIvad/rjcUyQBEYtM7kHGUzSPSb70gdt8SQsfHAP5B
# BM08yfGey6po4QEZrcb3UwjJB6rGlkHCXypgKkyrvzJ1jliZPZQLu7F+7g6r/rUz
# eEYJ871UApC4zRlzyA6qhvOlfxO/z83zxrfdhueJEeH8aCsdz6+/dx0drXFWXOnE
# DzEblOvlMIfGjZU=
# SIG # End signature block
