#Requires -Version 7.0
<#
.SYNOPSIS
  Consistent entry point for running the repository's Pester suite.

.DESCRIPTION
  Loads tests/Pester.runsettings.psd1, applies optional tag/exclude filters,
  and runs Invoke-Pester. When -CI is specified, writes JUnit output under
  out/test-results/pester.xml (creating the folder if needed).

.PARAMETER Tag
  Only run tests tagged with any of the specified values.

.PARAMETER ExcludeTag
  Skip tests tagged with any of the specified values.

.PARAMETER CI
  Enables JUnit output to out/test-results/pester.xml.
#>

[CmdletBinding()]
param(
  [string[]]$Tag,
  [string[]]$ExcludeTag,
  [switch]$CI
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repoRoot = Resolve-Path (Join-Path $PSScriptRoot '..')
$configPath = Join-Path $repoRoot 'tests' 'Pester.runsettings.psd1'
if (-not (Test-Path $configPath)) {
  throw "Pester configuration not found: $configPath"
}

$config = Import-PowerShellDataFile -LiteralPath $configPath

# Normalize relative paths based on repo root
$config.Run.Path = @(
  $config.Run.Path | ForEach-Object {
    (Resolve-Path (Join-Path $repoRoot $_)).ProviderPath
  }
)
$resolvedResultPath = Resolve-Path (Join-Path $repoRoot $config.TestResult.OutputPath) -ErrorAction SilentlyContinue
if ($resolvedResultPath) {
  $config.TestResult.OutputPath = $resolvedResultPath.ProviderPath
} else {
  $config.TestResult.OutputPath = Join-Path $repoRoot 'out/test-results/pester.xml'
}
if (-not $config.TestResult.OutputPath) {
  $config.TestResult.OutputPath = Join-Path $repoRoot 'out/test-results/pester.xml'
}

if ($Tag) {
  $config.Filter.Tag = @($Tag)
}
if ($ExcludeTag) {
  $config.Filter.ExcludeTag = @($ExcludeTag)
}

if ($CI) {
  $resultsPath = $config.TestResult.OutputPath
  $resultsDir = Split-Path $resultsPath -Parent
  if (-not (Test-Path $resultsDir)) { New-Item -ItemType Directory -Path $resultsDir -Force | Out-Null }
  $config.TestResult.Enabled = $true
  Write-Host "CI mode: writing Pester results to $resultsPath"
} else {
  $config.TestResult.Enabled = $false
}

Write-Host "Invoking Pester with tags: $($config.Filter.Tag -join ', ')" -ForegroundColor Cyan
Invoke-Pester -Configuration $config

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDYd2uoPAkTXPJb
# bn+j5BoktSlFrWLc2tx3vJ8l5hj/eaCCAxYwggMSMIIB+qADAgECAhAWxW6npWic
# vkss74jDNG6/MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTYwOTU0WhcNMjUxMTI3MTYxOTU0WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA0y5m0hNMbpdBsBLRIa7tJ5ytVbfCwqXz0eHwOLmIl/0t
# y7T2XMav7sQ7AKf9DM+45ltmk06eFhBcfc0CBjGZ5n9kif1+9CEjmIb/mLbtIHn3
# s1vxFOcSt58qvppzzf2wpNfuCMV5s80SR1QoGjGjEoKTE6GsQYqBOPzerkgt6z8x
# l+yRyVitedtQDSfHLJSPUvUBuvgwwDuGEAfqQQMKjamxcCr3khqgjd9JkZa0dMRb
# RfZ0NuIIujI2F8FTtT9TNi0H4dFQtFwHBaVjNXr7MXb9758qJFjIKibZyEkt+SG/
# G7MkKB08HVQI37XY+NnUlet+lzCUn3rx3NQ8rIrYoQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFHF0qrrX4yrl
# 1LPVc4C694M9lNtlMA0GCSqGSIb3DQEBCwUAA4IBAQA2nFtjU9DXU7FmBzcWkx8J
# icUDqGCjcqY6cH95gyBzMCpnVemR/ga46spxB36ugaQQB3GAajXyv5Bs7dTM2chp
# lqdsPZawswkYE6y/ED9JSjCwch97TQclmo394SS0ExW9DwuPnbH2DURgigXOh2dC
# UuJauD8fNIDW6OX/MEq8YtD5YPh8vs0JooZETgiDLei7DIqhHBW4i1yFctcfABRU
# pdSGIUAHy5fxYXX1kOYJoY9k/HG/h+fO3LQVgrdJOu4oNagUmNVrZVdp2UQHzf3m
# 4rulzxtN1J2CLAZWoNHjebBa2tjX/F86GzYTArLPQ4IUuLq3xn/fyXnEd0Dh3GVq
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAWxW6npWicvkss74jDNG6/MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEII11SC6wt7Xz
# Nju6w2mLIcqzI70/iCgkEho6gi7yzw2NMA0GCSqGSIb3DQEBAQUABIIBAIqpoz4A
# mfAvs1dgvPNqxGF5dFIWHI7VHlAfCon2APHqswMqSNuGTETF6F+Lx/hxvpNrjjNA
# ce3srrwgnVbVdW1a5INVHnq9K70uqRjh5EStNyl/k7/htteEXXXAlAepdLBW+ShW
# 6YAdiy2ADR7RhHYla7JDozGYo+a3UvPXrRf7qFHZAzORYWCt3oX++m3VnyD3Sf6M
# RSEJV+7NAJRjq5rpTfWcAOa7/qhlQ11qRXc5vkucqnNRLdfnKjjoJsPqtGxVCEHu
# iPL8bwEl4GCpVDHQR+J80kvjYu/0rllM9aM6D9qoultQPym5WCfAFOemnZgzrW3D
# U62qUvX4aSWPK58=
# SIG # End signature block
