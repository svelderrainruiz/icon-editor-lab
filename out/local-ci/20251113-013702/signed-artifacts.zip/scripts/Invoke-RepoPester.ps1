#Requires -Version 7.0
<#
.SYNOPSIS
  Consistent entry point for running the repository's Pester suite.

.DESCRIPTION
  Loads tests/Pester.runsettings.psd1, applies optional tag/exclude filters,
  and runs Invoke-Pester. When -CI is specified, writes JUnit output under
  out/test-results/pester.xml (creating the folder if needed).

.PARAMETER Tag
  Only run tests tagged with any of the specified values.

.PARAMETER ExcludeTag
  Skip tests tagged with any of the specified values.

.PARAMETER CI
  Enables JUnit output to out/test-results/pester.xml.
#>

[CmdletBinding()]
param(
  [string[]]$Tag,
  [string[]]$ExcludeTag,
  [switch]$CI
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repoRoot = Resolve-Path (Join-Path $PSScriptRoot '..')
$configPath = Join-Path $repoRoot 'tests' 'Pester.runsettings.psd1'
if (-not (Test-Path $configPath)) {
  throw "Pester configuration not found: $configPath"
}

$config = Import-PowerShellDataFile -LiteralPath $configPath

# Normalize relative paths based on repo root
$config.Run.Path = @(
  $config.Run.Path | ForEach-Object {
    (Resolve-Path (Join-Path $repoRoot $_)).ProviderPath
  }
)
$resolvedResultPath = Resolve-Path (Join-Path $repoRoot $config.TestResult.OutputPath) -ErrorAction SilentlyContinue
if ($resolvedResultPath) {
  $config.TestResult.OutputPath = $resolvedResultPath.ProviderPath
} else {
  $config.TestResult.OutputPath = Join-Path $repoRoot 'out/test-results/pester.xml'
}
if (-not $config.TestResult.OutputPath) {
  $config.TestResult.OutputPath = Join-Path $repoRoot 'out/test-results/pester.xml'
}

if ($Tag) {
  $config.Filter.Tag = @($Tag)
}
if ($ExcludeTag) {
  $config.Filter.ExcludeTag = @($ExcludeTag)
}

if ($CI) {
  $resultsPath = $config.TestResult.OutputPath
  $resultsDir = Split-Path $resultsPath -Parent
  if (-not (Test-Path $resultsDir)) { New-Item -ItemType Directory -Path $resultsDir -Force | Out-Null }
  $config.TestResult.Enabled = $true
  Write-Host "CI mode: writing Pester results to $resultsPath"
} else {
  $config.TestResult.Enabled = $false
}

Write-Host "Invoking Pester with tags: $($config.Filter.Tag -join ', ')" -ForegroundColor Cyan
Invoke-Pester -Configuration $config

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDYd2uoPAkTXPJb
# bn+j5BoktSlFrWLc2tx3vJ8l5hj/eaCCAxYwggMSMIIB+qADAgECAhBqfU+dwCXk
# hkaMEaHx6GbkMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMDkyNzQyWhcNMjUxMTI3MDkzNzQyWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAqLamdO/qDJdZ9/S38+KcF40FylWHqKDWM6fN5uxMeIGl
# aITTJGYjNcTNFAAa8nkZN3ULQJ73JH846x401OVc7osoprVM4mR+/sBJTkad+DIv
# tQ0sYBbN6QcwOJ68Y8loGkuCgjgOXjEhQuUm0tN6toDA9mHVX8/IG6UAY1GRYVSl
# h0mXp3Gcv8PH8pNcrLrybtNhbREf3oELS6rZLYy/puCCS8jtvtX/XZ/U1vDiRwIl
# P1YLyldLCb8TiAGIiqF8X0OKkJmJPVCNgjL38CQ8cDH+pDEjRNvpn8JOLzscKg5g
# CivWVrK7Ncrfa2TRIaOovmmj+oJjrLMuMGnOu41y9QIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFOCJNH2PQQDb
# /JQJmSl8ojhrYmivMA0GCSqGSIb3DQEBCwUAA4IBAQCMknU/c6tqODAfnuRZ0bsg
# k2J18NFn9JC1Q9ZWKqQaQvGIqy7+b3VP/6Ch9qZkhPfsLj5y3vNKAe8Oe+0jdiuT
# TiQ7GIkRWxSlX9LsYZWCMXpkPrXWiRSDZ3QfXNGIdNoWbOSvwkUYljdDBMgg2/oV
# 72gPtKOh89+pjSxOv738m7LRIvlAtszKlFp5JpJ7uAk4+1seT48sl9zzDXDWGS84
# aq3FdeL/TOCdls4v/RfG27cnYkSy6CFri8z6aMay3f1we93uvG81SSNurUTUiGVH
# mf/QhUt8vo6rH12WtwajBFc/+vhoJ/tWEFRWUU3hMUlMFQURmntmeuT16/XNEPnn
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBqfU+dwCXkhkaMEaHx6GbkMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEII11SC6wt7Xz
# Nju6w2mLIcqzI70/iCgkEho6gi7yzw2NMA0GCSqGSIb3DQEBAQUABIIBAAiI4NIt
# 7DKCG9QHwIAkkh/7UabW6BndExqbLm3yZYDJBAmr2MGgZEU2n/dCQFYKQoWfGZ0o
# 9PQoowEeHCknzzKnbIjSj6Kaa2iDXSrHcYoq+U+jCRqBc1ihmtnszNChz04kjNa9
# dX9XYuEg8tcaVswr+6acliAfgOnaKkzCmikeuKGSiMx4nOLv72z2LCqsxCi32kk8
# qD53NBeUv6QkNxQppDMCEjberg7Z0ClRoR0GW5uuivkATkCf8j+yYQBE15RIv+qU
# DQ3MwYEG3sKqQnpdCZhzt4kPkCaYVY2UyooRchWYgVbWALCUPDTXru0eQ8sPsmX4
# E8GaY/ivCufHBkc=
# SIG # End signature block
