# Secure-Process.psm1
Set-StrictMode -Version Latest
. (Join-Path $PSScriptRoot 'Validate-Paths.ps1')
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Invoke-ProcessSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$FilePath,
        [Parameter()][string[]]$ArgumentList = @(),
        [Parameter()][int]$TimeoutSec = 600,
        [Parameter()][string]$WorkingDirectory = (Get-Location).Path
    )
    if (-not (Test-Path -LiteralPath $FilePath -PathType Leaf)) { throw "FilePath not found: $FilePath" }
    $psi = [System.Diagnostics.ProcessStartInfo]::new()
    $psi.FileName = $FilePath
    $psi.WorkingDirectory = (Validate-PathSafe -Path $WorkingDirectory)
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.UseShellExecute = $false
    foreach ($a in $ArgumentList) { $null = $psi.ArgumentList.Add($a) }

    $p = [System.Diagnostics.Process]::new()
    $p.StartInfo = $psi
    if (-not $p.Start()) { throw "Failed to start process: $FilePath" }
    try {
        if (-not $p.WaitForExit($TimeoutSec * 1000)) {
            try { $p.Kill($true) } catch {}
            throw "Process timed out after $TimeoutSec s: $FilePath"
        }
        $stdout = $p.StandardOutput.ReadToEnd()
        $stderr = $p.StandardError.ReadToEnd()
        return [pscustomobject]@{
            ExitCode = $p.ExitCode
            StdOut = $stdout
            StdErr = $stderr
        }
    } finally {
        if (-not $p.HasExited) { try { $p.Kill($true) } catch {} }
        $p.Dispose()
    }
}
Export-ModuleMember -Function Invoke-ProcessSafe

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDLM/hZ77J6ko3k
# J1T1SnSI3Zjg9T8EF5sOyyHIvgXLgqCCAxYwggMSMIIB+qADAgECAhBqfU+dwCXk
# hkaMEaHx6GbkMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMDkyNzQyWhcNMjUxMTI3MDkzNzQyWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAqLamdO/qDJdZ9/S38+KcF40FylWHqKDWM6fN5uxMeIGl
# aITTJGYjNcTNFAAa8nkZN3ULQJ73JH846x401OVc7osoprVM4mR+/sBJTkad+DIv
# tQ0sYBbN6QcwOJ68Y8loGkuCgjgOXjEhQuUm0tN6toDA9mHVX8/IG6UAY1GRYVSl
# h0mXp3Gcv8PH8pNcrLrybtNhbREf3oELS6rZLYy/puCCS8jtvtX/XZ/U1vDiRwIl
# P1YLyldLCb8TiAGIiqF8X0OKkJmJPVCNgjL38CQ8cDH+pDEjRNvpn8JOLzscKg5g
# CivWVrK7Ncrfa2TRIaOovmmj+oJjrLMuMGnOu41y9QIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFOCJNH2PQQDb
# /JQJmSl8ojhrYmivMA0GCSqGSIb3DQEBCwUAA4IBAQCMknU/c6tqODAfnuRZ0bsg
# k2J18NFn9JC1Q9ZWKqQaQvGIqy7+b3VP/6Ch9qZkhPfsLj5y3vNKAe8Oe+0jdiuT
# TiQ7GIkRWxSlX9LsYZWCMXpkPrXWiRSDZ3QfXNGIdNoWbOSvwkUYljdDBMgg2/oV
# 72gPtKOh89+pjSxOv738m7LRIvlAtszKlFp5JpJ7uAk4+1seT48sl9zzDXDWGS84
# aq3FdeL/TOCdls4v/RfG27cnYkSy6CFri8z6aMay3f1we93uvG81SSNurUTUiGVH
# mf/QhUt8vo6rH12WtwajBFc/+vhoJ/tWEFRWUU3hMUlMFQURmntmeuT16/XNEPnn
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBqfU+dwCXkhkaMEaHx6GbkMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPEK5pYr/oiP
# 6zXDh72ZtLHO5VLyj1aDMXhTjDbbSs4wMA0GCSqGSIb3DQEBAQUABIIBAHgv2LFQ
# ixH4cqcgpFyNdP1zgyikcVO0pAVqjG+o4UylIk/lQynLIq2YxQ3Ljwct3rFPopeT
# bgivsJKtsf/mPVFaxWKokXRDyJdLetPuutLiVjTCWIdyo9dEjJVVT5CDQg+VsJuK
# ILqjvUbP+dosRp35wUUuzvT+SChJs+OZ8tjWqsH3tUd5FiR5++kFejJ75eVpM8Dw
# cN98rM8tl4DkI9AY+YStXYMDWvE5t1X1A0/VzUqeti5DIM8Um9mHoip5qCtZGonj
# R5UHFyHp3aBo9w8iUmyblNAuIlMAjgaF5WrZkd5Rdhcu2rR9vIidvmlsSLb+flut
# XzGm+tp11lk4xKU=
# SIG # End signature block
