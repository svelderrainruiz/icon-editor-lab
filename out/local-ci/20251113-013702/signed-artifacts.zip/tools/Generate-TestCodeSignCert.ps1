#Requires -Version 7.0
<#
.SYNOPSIS
  Generate a temporary, self-signed code-signing certificate for local/fork testing.

.DESCRIPTION
  - Creates a self-signed "Code Signing" cert in the current user's store
  - Exports a PFX with a strong random password
  - Emits a Base64 blob for use as an environment secret
  - Optionally writes secrets to secrets.json and/or .env
  - Prints cleanup commands to remove the cert and files

.NOTES
  For TESTING ONLY. Do not use for production/release signing.
#>

[CmdletBinding()]
param(
  [string]$Subject = 'CN=CI Test Signing',
  [int]$DaysValid = 14,
  [string]$OutDir = (Join-Path -Path $PWD -ChildPath 'out\test-codesign'),
  [switch]$EmitJson,
  [switch]$EmitEnv,
  [switch]$Quiet
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

if (-not $IsWindows) {
  throw "This script requires Windows (uses New-SelfSignedCertificate)."
}

# Ensure output folder
$null = New-Item -ItemType Directory -Force -Path $OutDir

# Create self-signed code-signing cert (exportable key)
$notAfter = (Get-Date).AddDays([Math]::Max(1, $DaysValid))
$cert = New-SelfSignedCertificate `
  -Subject $Subject `
  -Type CodeSigningCert `
  -CertStoreLocation 'Cert:\CurrentUser\My' `
  -NotAfter $notAfter `
  -KeyExportPolicy Exportable `
  -KeyAlgorithm RSA -KeyLength 3072 `
  -HashAlgorithm SHA256

if (-not $cert) { throw "Failed to create self-signed code-signing certificate." }

# Generate a strong random password (Base64 of 48 random bytes)
$pwdPlain = [Convert]::ToBase64String([System.Security.Cryptography.RandomNumberGenerator]::GetBytes(48))
$pwdSecure = ConvertTo-SecureString -String $pwdPlain -AsPlainText -Force

# Export to PFX
$pfxName = "test-codesign-$($cert.Thumbprint.Substring(0,8)).pfx"
$pfxPath = Join-Path $OutDir $pfxName
Export-PfxCertificate -Cert $cert -FilePath $pfxPath -Password $pwdSecure | Out-Null

# Base64-encode the PFX for easy use as a secret
$b64Path = Join-Path $OutDir "test-codesign.pfx.b64"
[IO.File]::WriteAllBytes($b64Path, [Convert]::FromBase64String(([Convert]::ToBase64String([IO.File]::ReadAllBytes($pfxPath)))))
# Re-read as trimmed string (ensures newline at end when written below)
$pfxB64 = Get-Content -LiteralPath $b64Path -Raw

# Write convenient plain-text files for quick 'gh secret set' usage
$pwdPath = Join-Path $OutDir "WIN_CODESIGN_PFX_PASSWORD.txt"
$b64TxtPath = Join-Path $OutDir "WIN_CODESIGN_PFX_B64.txt"
Set-Content -LiteralPath $pwdPath -Value $pwdPlain -Encoding UTF8 -NoNewline:$false
Set-Content -LiteralPath $b64TxtPath -Value $pfxB64 -Encoding UTF8 -NoNewline:$false

# Optional secret bundles
if ($EmitJson) {
  $jsonPath = Join-Path $OutDir "secrets.json"
  @{ WIN_CODESIGN_PFX_B64 = $pfxB64; WIN_CODESIGN_PFX_PASSWORD = $pwdPlain } |
    ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $jsonPath -Encoding UTF8
}

if ($EmitEnv) {
  $envPath = Join-Path $OutDir "secrets.env"
  @(
    "WIN_CODESIGN_PFX_B64=$pfxB64"
    "WIN_CODESIGN_PFX_PASSWORD=$pwdPlain"
  ) | Set-Content -LiteralPath $envPath -Encoding UTF8
}

if (-not $Quiet) {
  Write-Host ""
  Write-Host "✅ Generated TEST code-signing certificate" -ForegroundColor Green
  Write-Host "  Subject        : $($cert.Subject)"
  Write-Host "  Thumbprint     : $($cert.Thumbprint)"
  Write-Host "  Valid Until    : $($cert.NotAfter.ToString('u'))"
  Write-Host "  PFX            : $pfxPath"
  Write-Host "  B64 (file)     : $b64TxtPath"
  Write-Host "  Password (file): $pwdPath"
  if ($EmitJson) { Write-Host "  JSON           : $jsonPath" }
  if ($EmitEnv)  { Write-Host "  .env           : $envPath" }

  Write-Host ""
  Write-Host "🔐 Secret names to use (match the hardened CI):"
  Write-Host "  - WIN_CODESIGN_PFX_B64"
  Write-Host "  - WIN_CODESIGN_PFX_PASSWORD"

  Write-Host ""
  Write-Host "📦 Examples (run from repo root) — set environment secrets in your fork:"
  Write-Host "  # codesign-dev environment"
  Write-Host "  gh secret set -e codesign-dev WIN_CODESIGN_PFX_B64       -b \"$(Get-Content '$b64TxtPath' -Raw)\""
  Write-Host "  gh secret set -e codesign-dev WIN_CODESIGN_PFX_PASSWORD  -b \"$(Get-Content '$pwdPath'  -Raw)\""
  Write-Host ""
  Write-Host "  # codesign-prod environment (in your fork only, for end-to-end testing)"
  Write-Host "  gh secret set -e codesign-prod WIN_CODESIGN_PFX_B64      -b \"$(Get-Content '$b64TxtPath' -Raw)\""
  Write-Host "  gh secret set -e codesign-prod WIN_CODESIGN_PFX_PASSWORD -b \"$(Get-Content '$pwdPath'  -Raw)\""

  Write-Host ""
  Write-Host "🧹 Cleanup (remove the TEST cert and files when done):"
  Write-Host "  # Remove cert from CurrentUser store"
  Write-Host "  certutil -user -delstore My $($cert.Thumbprint)"
  Write-Host "  # Or (PowerShell): Remove-Item -LiteralPath Cert:\\CurrentUser\\My\\$($cert.Thumbprint) -Force"
  Write-Host "  # Remove files"
  Write-Host "  Remove-Item -LiteralPath '$pfxPath','${b64TxtPath}','${pwdPath}' -Force"
  if ($EmitJson) { Write-Host "  Remove-Item -LiteralPath '$jsonPath' -Force" }
  if ($EmitEnv)  { Write-Host "  Remove-Item -LiteralPath '$envPath'  -Force" }
  Write-Host ""
  Write-Warning "This certificate is for local/test signing ONLY. Do not use it for releases."
}

# Return a small object for programmatic use
[pscustomobject]@{
  Subject   = $cert.Subject
  Thumbprint= $cert.Thumbprint
  PfxPath   = $pfxPath
  PfxBase64 = $pfxB64
  Password  = $pwdPlain
  OutDir    = $OutDir
}


# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBnPlLEdh9CurFz
# Kde54+NXx4R3j31bMpNV4kK0lo5xrqCCAxYwggMSMIIB+qADAgECAhBqfU+dwCXk
# hkaMEaHx6GbkMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMDkyNzQyWhcNMjUxMTI3MDkzNzQyWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAqLamdO/qDJdZ9/S38+KcF40FylWHqKDWM6fN5uxMeIGl
# aITTJGYjNcTNFAAa8nkZN3ULQJ73JH846x401OVc7osoprVM4mR+/sBJTkad+DIv
# tQ0sYBbN6QcwOJ68Y8loGkuCgjgOXjEhQuUm0tN6toDA9mHVX8/IG6UAY1GRYVSl
# h0mXp3Gcv8PH8pNcrLrybtNhbREf3oELS6rZLYy/puCCS8jtvtX/XZ/U1vDiRwIl
# P1YLyldLCb8TiAGIiqF8X0OKkJmJPVCNgjL38CQ8cDH+pDEjRNvpn8JOLzscKg5g
# CivWVrK7Ncrfa2TRIaOovmmj+oJjrLMuMGnOu41y9QIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFOCJNH2PQQDb
# /JQJmSl8ojhrYmivMA0GCSqGSIb3DQEBCwUAA4IBAQCMknU/c6tqODAfnuRZ0bsg
# k2J18NFn9JC1Q9ZWKqQaQvGIqy7+b3VP/6Ch9qZkhPfsLj5y3vNKAe8Oe+0jdiuT
# TiQ7GIkRWxSlX9LsYZWCMXpkPrXWiRSDZ3QfXNGIdNoWbOSvwkUYljdDBMgg2/oV
# 72gPtKOh89+pjSxOv738m7LRIvlAtszKlFp5JpJ7uAk4+1seT48sl9zzDXDWGS84
# aq3FdeL/TOCdls4v/RfG27cnYkSy6CFri8z6aMay3f1we93uvG81SSNurUTUiGVH
# mf/QhUt8vo6rH12WtwajBFc/+vhoJ/tWEFRWUU3hMUlMFQURmntmeuT16/XNEPnn
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBqfU+dwCXkhkaMEaHx6GbkMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIC+gJntA56/z
# FhLepV+JpKj7iU29+njbZ1vV8ZkWyxCDMA0GCSqGSIb3DQEBAQUABIIBAHINKH9b
# ILAg8+pMZg5mk6Lhb8horORF2TjKT7AoqJ09uqmjgrbBV4cmN/rgl08+29zkYHOY
# BtCQ2GKoYLVWTRlaSlpmgl2CM8bh3FqFmU8w9MzmbAqAkMbPLurQ9piQ7Kji7ln3
# /lAeSSHZw+q+mqQcXk/BgKQc3UAv7oaq4aoSVNYlbHTyNsMB9bCeofn4xQn30L2A
# 3A/K1cryIHyqEpus59KiviiGWs7n2VYv6aG1zhB2oiIi4mgWqRxef71bsCbJTL3M
# 7QQWmrXXte9amW5xGBSXQfYHn4WsJZ85cn1gLpMYi9khAf20nevge81Ux28DSXUL
# 8Iy3D+z/h1oLPdQ=
# SIG # End signature block
