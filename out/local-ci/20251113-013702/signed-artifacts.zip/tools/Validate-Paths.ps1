# Validate-Paths.ps1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Test-PathSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter()][switch]$RequireAbsolute
    )
    if ($Path -match '[;&|`]' -or $Path -match '\.\.') { return $false }
    try {
        $rp = Resolve-Path -LiteralPath $Path -ErrorAction Stop
        if ($RequireAbsolute -and -not ($rp.Path -match '^(?:[A-Za-z]:[\\/]|/)')) { return $false }
        return $true
    } catch { return $false }
}

function Validate-PathSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter()][switch]$RequireAbsolute
    )
    if (-not (Test-PathSafe -Path $Path -RequireAbsolute:$RequireAbsolute)) {
        throw "Unsafe or invalid path: $Path"
    }
    return (Resolve-Path -LiteralPath $Path).Path
}

Export-ModuleMember -Function Test-PathSafe, Validate-PathSafe

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBRKRGFgRiwJrUW
# ser+RbKUtmM3v2Ar6IG3lNNJMXHBxaCCAxYwggMSMIIB+qADAgECAhBqfU+dwCXk
# hkaMEaHx6GbkMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMDkyNzQyWhcNMjUxMTI3MDkzNzQyWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAqLamdO/qDJdZ9/S38+KcF40FylWHqKDWM6fN5uxMeIGl
# aITTJGYjNcTNFAAa8nkZN3ULQJ73JH846x401OVc7osoprVM4mR+/sBJTkad+DIv
# tQ0sYBbN6QcwOJ68Y8loGkuCgjgOXjEhQuUm0tN6toDA9mHVX8/IG6UAY1GRYVSl
# h0mXp3Gcv8PH8pNcrLrybtNhbREf3oELS6rZLYy/puCCS8jtvtX/XZ/U1vDiRwIl
# P1YLyldLCb8TiAGIiqF8X0OKkJmJPVCNgjL38CQ8cDH+pDEjRNvpn8JOLzscKg5g
# CivWVrK7Ncrfa2TRIaOovmmj+oJjrLMuMGnOu41y9QIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFOCJNH2PQQDb
# /JQJmSl8ojhrYmivMA0GCSqGSIb3DQEBCwUAA4IBAQCMknU/c6tqODAfnuRZ0bsg
# k2J18NFn9JC1Q9ZWKqQaQvGIqy7+b3VP/6Ch9qZkhPfsLj5y3vNKAe8Oe+0jdiuT
# TiQ7GIkRWxSlX9LsYZWCMXpkPrXWiRSDZ3QfXNGIdNoWbOSvwkUYljdDBMgg2/oV
# 72gPtKOh89+pjSxOv738m7LRIvlAtszKlFp5JpJ7uAk4+1seT48sl9zzDXDWGS84
# aq3FdeL/TOCdls4v/RfG27cnYkSy6CFri8z6aMay3f1we93uvG81SSNurUTUiGVH
# mf/QhUt8vo6rH12WtwajBFc/+vhoJ/tWEFRWUU3hMUlMFQURmntmeuT16/XNEPnn
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBqfU+dwCXkhkaMEaHx6GbkMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEINpvsU+HHb6K
# gYnFC+DOD7Pi21ghNNfHTvYHF7x5UIBMMA0GCSqGSIb3DQEBAQUABIIBAGJlwFaB
# V+wXHyvLteFB9brFRyIGypQ1HBHimn41nb8mFdFUknzOOsvEDRrnBwfyVqzfn4pD
# hmQoicePltszWlmKoe/DrUnMJ8ZdRRbYqZGB740QhDgYiWP9O0D5sh2NQW6y1ufh
# hSn21Eu5WW689DLh3nQKBVEw4myORzYg3yJWl/yAp2URaEMkTUAgXCwxxX+9vPl0
# C+CeaJAbyiFtyA3bYfnzkHlih51lp3wMslUBshBYNSX6nGFX5EWy9gUQtHhSpe7l
# fbG5EZWUBBJKsIEzm8baOILutyDYP4aGW/Nx2eXhRqVa2Qu5cAyEkqMjEbBKtO9E
# Eb07YTH6jQeI2rk=
# SIG # End signature block
