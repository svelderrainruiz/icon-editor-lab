#Requires -Version 7.0
<#
.SYNOPSIS
  Consistent entry point for running the repository's Pester suite.

.DESCRIPTION
  Loads tests/Pester.runsettings.psd1, applies optional tag/exclude filters,
  and runs Invoke-Pester. When -CI is specified, writes JUnit output under
  out/test-results/pester.xml (creating the folder if needed).

.PARAMETER Tag
  Only run tests tagged with any of the specified values.

.PARAMETER ExcludeTag
  Skip tests tagged with any of the specified values.

.PARAMETER CI
  Enables JUnit output to out/test-results/pester.xml.
#>

[CmdletBinding()]
param(
  [string[]]$Tag,
  [string[]]$ExcludeTag,
  [switch]$CI
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repoRoot = Resolve-Path (Join-Path $PSScriptRoot '..')
$configPath = Join-Path $repoRoot 'tests' 'Pester.runsettings.psd1'
if (-not (Test-Path $configPath)) {
  throw "Pester configuration not found: $configPath"
}

$config = Import-PowerShellDataFile -LiteralPath $configPath

# Normalize relative paths based on repo root
$config.Run.Path = @(
  $config.Run.Path | ForEach-Object {
    (Resolve-Path (Join-Path $repoRoot $_)).ProviderPath
  }
)
$resolvedResultPath = Resolve-Path (Join-Path $repoRoot $config.TestResult.OutputPath) -ErrorAction SilentlyContinue
if ($resolvedResultPath) {
  $config.TestResult.OutputPath = $resolvedResultPath.ProviderPath
} else {
  $config.TestResult.OutputPath = Join-Path $repoRoot 'out/test-results/pester.xml'
}
if (-not $config.TestResult.OutputPath) {
  $config.TestResult.OutputPath = Join-Path $repoRoot 'out/test-results/pester.xml'
}

if ($Tag) {
  $config.Filter.Tag = @($Tag)
}
if ($ExcludeTag) {
  $config.Filter.ExcludeTag = @($ExcludeTag)
}

if ($CI) {
  $resultsPath = $config.TestResult.OutputPath
  $resultsDir = Split-Path $resultsPath -Parent
  if (-not (Test-Path $resultsDir)) { New-Item -ItemType Directory -Path $resultsDir -Force | Out-Null }
  $config.TestResult.Enabled = $true
  Write-Host "CI mode: writing Pester results to $resultsPath"
} else {
  $config.TestResult.Enabled = $false
}

Write-Host "Invoking Pester with tags: $($config.Filter.Tag -join ', ')" -ForegroundColor Cyan
Invoke-Pester -Configuration $config

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDYd2uoPAkTXPJb
# bn+j5BoktSlFrWLc2tx3vJ8l5hj/eaCCAxYwggMSMIIB+qADAgECAhAqj8OqfNDA
# pkfPYtDNBMzOMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTcxOTIyWhcNMjUxMTI3MTcyOTIyWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAyi8OcOIK6/hl4qmBxN3sVyAuYyuIgy6+QPTo4wpDIdDS
# 7LvJt2oZ4EUEGnWpmTB80qOKvXSStnXCEnr/x7R0LIcdC6qwn8mzGqyWWbDdCRq2
# Isn08Jks8I9L38qJktofKYIH5k2pWFvVINQXUwVAEWyfAZnsvHOy/Gaxmhoy21lC
# Gvnc2FNqG7ufdBiEn6WIJgTybV5htpWRYtNb0R0eYjZd7Vx0nXI9T6lDPPWt0avf
# PUD5moeHjE3xd+mBbEPX0/DINxpHizCtsZk9z3ABN8/DzslMBR7+w+G0ZBrdOoq6
# i5M5Ig1ro02cUg+/UQwLsT6dBs5sDdl0wcjQjI6xzQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFPltSk9cj8z6
# ZWUWMRbaGiqmcsjDMA0GCSqGSIb3DQEBCwUAA4IBAQBtxnLHRemKSMTzcfhH648q
# OU9rAOZN1rQmM1fW40UDANx49kzWwWz5J/jKgwIioc7Byg7X6D+HuMMkCN8TFmw8
# rK3+iaS8zcVtOPG4881pGEKaB/JeUNZAnbUrO0yfVVc2gOQErxmkNPrpepy8tVJk
# BM4TilWTSyLW++/17Jory9cYo/BDr5u8QpVuBtydlEJmCB5SZEfuNfAVinHPjhzu
# FcIS3Q24MZ0ztuvUdpxRtm2tlii+l66RDvniTRqK5ZDn3hGuy4+DfjjbOsofhwJN
# uwQQcGoV4C0GOom+28COrGVk7kcVm0FLvT64MF6SCpvVzICQxax9eDNClegs/qpq
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAqj8OqfNDApkfPYtDNBMzOMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEII11SC6wt7Xz
# Nju6w2mLIcqzI70/iCgkEho6gi7yzw2NMA0GCSqGSIb3DQEBAQUABIIBAHN0jSLj
# z8z37OjTTUo97RRTInrznIjb99ucpSQiWQBRobfz4XKpo1pMUIZCw1Yxi/uuMrGT
# aoqq+Dw4UW8yiReh5enhZSI1ooPojHb6arlrfEVuFawGfSMrxIFOOGVDGDzsQJFl
# BhekOO0do4Nf6Gvt5D5jd5ECyjL9Hmm+edb/qAqMLBhZw7FfWOB5X3zNZMJ5ne+G
# qXmKd2yXkza2n2bLPKYkIPQrhH+ZYqm/CCMedsmDu9UojyF556PTVHAnREnXuiKH
# HwqKWIv7YC90ADh9Jvn5ORVbyf9HRYXilyn3aIRjkzoWmnpKTEyT+mwQSrLjuPFx
# e9JhBLDdkHN+trc=
# SIG # End signature block
