#Requires -Version 7.0
<#
.SYNOPSIS
  Runs fork-mode and trusted-mode signing batches locally to mirror CI behavior.

.DESCRIPTION
  - Prepares SIGN_ROOT by copying repo scripts (tools/, scripts/) plus sample payloads.
  - Generates an ephemeral certificate for each mode and runs Invoke-ScriptSigningBatch.ps1.
  - Prints the summary output so we can compare with GitHub runners.

.PARAMETER SignRoot
  Directory to stage unsigned artifacts. Defaults to 'out'.

.PARAMETER MaxFiles
  Max script count to process (passed through to the batch helper).

.PARAMETER TimeoutSeconds
  Timeout for timestamping; batch helper uses it for per-file waits.

.PARAMETER ToolsOnly
  Limit the test payload to scripts under tools/.

.PARAMETER ScriptsOnly
  Limit the test payload to scripts under scripts/.

.PARAMETER SkipToolTests
  Skip running the harness Pester suite (tools and scripts tags). By default the suite runs.

.NOTES
  Every run captures a transcript under out/local-signing-logs for traceability.
#>

[CmdletBinding()]
param(
  [string]$SignRoot = 'out',
  [int]$MaxFiles = 200,
  [int]$TimeoutSeconds = 20,
  [string]$TimestampServer = 'https://timestamp.digicert.com',
  [switch]$ToolsOnly,
  [switch]$ScriptsOnly,
  [switch]$IncludeSamples = $true,
  [switch]$SimulateTimestampFailure,
  [switch]$SkipToolTests,
  [string[]]$ExcludePaths = @('local-signing-logs','local-ci')
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

if ($ToolsOnly -and $ScriptsOnly) {
  throw "Use either -ToolsOnly or -ScriptsOnly, not both."
}

function Test-IsExcludedPath {
  param(
    [string]$RelativePath,
    [string[]]$Excludes
  )
  if (-not $RelativePath) { return $false }
  $segments = $RelativePath -split '[\\/]' | Where-Object { $_ }
  foreach ($segment in $segments) {
    if ($Excludes -contains $segment) { return $true }
  }
  return $false
}

function Get-RootsToCopy {
  if ($ToolsOnly)   { return @('tools') }
  if ($ScriptsOnly) { return @('scripts') }
  return @('tools','scripts')
}

function Prepare-SignRoot {
  param(
    [string]$Root,
    [string[]]$SourceRoots,
    [string[]]$ExcludeFolders
  )
  if (-not (Test-Path $Root)) {
    New-Item -ItemType Directory -Path $Root | Out-Null
  } else {
    Get-ChildItem -Path $Root -Force | Where-Object { $ExcludeFolders -notcontains $_.Name } | Remove-Item -Recurse -Force
    foreach ($folder in $ExcludeFolders) {
      $path = Join-Path $Root $folder
      if (-not (Test-Path $path)) {
        New-Item -ItemType Directory -Path $path | Out-Null
      }
    }
  }

  $rootsToCopy = $SourceRoots

  foreach ($rr in $rootsToCopy) {
    $src = Join-Path $PWD $rr
    if (-not (Test-Path $src)) { continue }
    Get-ChildItem -Path $src -Include *.ps1,*.psm1 -Recurse -File |
      ForEach-Object {
        $relative = $_.FullName.Substring($PWD.ToString().Length + 1)
        $dest = Join-Path $Root $relative
        $destDir = Split-Path $dest -Parent
        if (-not (Test-Path $destDir)) { New-Item -ItemType Directory -Path $destDir -Force | Out-Null }
        Copy-Item -Path $_.FullName -Destination $dest -Force
      }
  }

  if ($IncludeSamples) {
    "Write-Output 'Sample payload for signing test.'" | Set-Content -Path (Join-Path $Root 'Sample-Signed.ps1') -Encoding UTF8
    [IO.File]::WriteAllBytes((Join-Path $Root 'sample.exe'), [byte[]](1..16))
  }
}

function Invoke-SigningMode {
  param(
    [string]$ModeLabel,
    [switch]$UseTimestamp,
    [int]$MaxFiles,
    [int]$TimeoutSeconds,
    [string]$TimestampServer,
    [string[]]$ExcludeFolders
  )
  $cert = New-SelfSignedCertificate -Subject "CN=CI Local $ModeLabel" -Type CodeSigningCert -CertStoreLocation Cert:\CurrentUser\My -NotAfter (Get-Date).AddDays(14)
  $thumb = $cert.Thumbprint
  $args = @(
    '-NoLogo','-NoProfile','-File','tools/Invoke-ScriptSigningBatch.ps1',
    '-Root', $SignRoot,
    '-CertificateThumbprint', $thumb,
    '-MaxFiles', $MaxFiles,
    '-TimeoutSeconds', $TimeoutSeconds,
    '-Mode', $ModeLabel
  )
  if ($ExcludeFolders -and $ExcludeFolders.Count -gt 0) {
    Write-Verbose ("[{0}] Excluding folders from signing: {1}" -f $ModeLabel, ($ExcludeFolders -join ', '))
    $args += '-ExcludePaths'
    $args += ($ExcludeFolders -join ',')
  }
  if ($UseTimestamp) {
    $tsa = if ([string]::IsNullOrWhiteSpace($TimestampServer)) { 'https://timestamp.digicert.com' } else { $TimestampServer }
    $args += @('-UseTimestamp','-TimestampServer', $tsa)
    if ($SimulateTimestampFailure -and $ModeLabel -like 'trusted*') {
      $args += '-SimulateTimestampFailure'
    }
  }
  Write-Host "`n== Running mode: $ModeLabel ==" -ForegroundColor Cyan
  $cmdInfo = Get-Command pwsh -ErrorAction SilentlyContinue
  $pwshCmd = $null
  if ($cmdInfo) {
    if ($cmdInfo.PSObject.Properties['Path']) { $pwshCmd = $cmdInfo.Path }
    elseif ($cmdInfo.PSObject.Properties['Source']) { $pwshCmd = $cmdInfo.Source }
  }
  if (-not $pwshCmd -and $IsWindows) {
    $candidate = Join-Path $PSHOME 'pwsh.exe'
    if (Test-Path -LiteralPath $candidate -PathType Leaf) { $pwshCmd = $candidate }
  }
  if (-not $pwshCmd) { $pwshCmd = 'pwsh' }
  & $pwshCmd @args
}

function Invoke-HarnessTests {
  param([string[]]$Tags)
  $effectiveTags = @($Tags | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
  if ($effectiveTags.Count -eq 0) {
    Write-Host "No harness tags selected; skipping Pester harness run." -ForegroundColor Yellow
    return
  }

  $runner = Join-Path $PSScriptRoot 'Invoke-RepoPester.ps1'
  if (-not (Test-Path $runner)) {
    throw "Cannot locate Invoke-RepoPester.ps1 at $runner"
  }

  Write-Host "`n== Running harness Pester suite (tags: $($effectiveTags -join ', ')) ==" -ForegroundColor Cyan
  & $runner -Tag $effectiveTags
}

$transcriptDir = Join-Path $PWD 'out/local-signing-logs'
if (-not (Test-Path $transcriptDir)) { New-Item -ItemType Directory -Path $transcriptDir -Force | Out-Null }
$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$logPath = Join-Path $transcriptDir "signing-$timestamp.log"
Start-Transcript -Path $logPath | Out-Null

try {
  $selectedRoots = Get-RootsToCopy
  Prepare-SignRoot -Root $SignRoot -SourceRoots $selectedRoots -ExcludeFolders $ExcludePaths
  Invoke-SigningMode -ModeLabel 'fork-local' -MaxFiles $MaxFiles -TimeoutSeconds $TimeoutSeconds -TimestampServer $TimestampServer -ExcludeFolders $ExcludePaths
  Invoke-SigningMode -ModeLabel 'trusted-local' -UseTimestamp -MaxFiles $MaxFiles -TimeoutSeconds $TimeoutSeconds -TimestampServer $TimestampServer -ExcludeFolders $ExcludePaths
  if (-not $SkipToolTests) {
    $harnessTags = @()
    if ($ToolsOnly) {
      $harnessTags = @('tools')
    } elseif ($ScriptsOnly) {
      $harnessTags = @('scripts')
    } else {
      $harnessTags = @('tools','scripts')
    }
    Invoke-HarnessTests -Tags $harnessTags
  } else {
    Write-Host "Skipping harness Pester suite (-SkipToolTests set)." -ForegroundColor Yellow
  }
} finally {
  Stop-Transcript | Out-Null
  Write-Host "Transcript written to $logPath" -ForegroundColor Yellow
}

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDO+zFXaWj3+laO
# hnO4RfAEKWl8MCj9PA4MztsChK6t/aCCAxYwggMSMIIB+qADAgECAhAqj8OqfNDA
# pkfPYtDNBMzOMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTcxOTIyWhcNMjUxMTI3MTcyOTIyWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAyi8OcOIK6/hl4qmBxN3sVyAuYyuIgy6+QPTo4wpDIdDS
# 7LvJt2oZ4EUEGnWpmTB80qOKvXSStnXCEnr/x7R0LIcdC6qwn8mzGqyWWbDdCRq2
# Isn08Jks8I9L38qJktofKYIH5k2pWFvVINQXUwVAEWyfAZnsvHOy/Gaxmhoy21lC
# Gvnc2FNqG7ufdBiEn6WIJgTybV5htpWRYtNb0R0eYjZd7Vx0nXI9T6lDPPWt0avf
# PUD5moeHjE3xd+mBbEPX0/DINxpHizCtsZk9z3ABN8/DzslMBR7+w+G0ZBrdOoq6
# i5M5Ig1ro02cUg+/UQwLsT6dBs5sDdl0wcjQjI6xzQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFPltSk9cj8z6
# ZWUWMRbaGiqmcsjDMA0GCSqGSIb3DQEBCwUAA4IBAQBtxnLHRemKSMTzcfhH648q
# OU9rAOZN1rQmM1fW40UDANx49kzWwWz5J/jKgwIioc7Byg7X6D+HuMMkCN8TFmw8
# rK3+iaS8zcVtOPG4881pGEKaB/JeUNZAnbUrO0yfVVc2gOQErxmkNPrpepy8tVJk
# BM4TilWTSyLW++/17Jory9cYo/BDr5u8QpVuBtydlEJmCB5SZEfuNfAVinHPjhzu
# FcIS3Q24MZ0ztuvUdpxRtm2tlii+l66RDvniTRqK5ZDn3hGuy4+DfjjbOsofhwJN
# uwQQcGoV4C0GOom+28COrGVk7kcVm0FLvT64MF6SCpvVzICQxax9eDNClegs/qpq
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAqj8OqfNDApkfPYtDNBMzOMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPoI+ZjLcgkx
# hAxXRw0BvaXK5KDJya48uWOrTX/uioWFMA0GCSqGSIb3DQEBAQUABIIBAMLkxfpd
# 5+7IwnTAEPxPeceyALjIWk2CG5Db5g8Wx0zQwWumRKT6ov3XoXHFdYZMjP1B9ZFy
# yVQTWYNR66ZaAqgiBd4/TdUjJ9DVEs3t0GC7iHhGA18bT0gLypbhZ69Cd44mzqTf
# /GGfnecMsQJDeKOn4Ts+JFMMfEgEj4+gnCyLBg3TPdW5Sjzp3wkaWJ0MHI2Q6rrj
# tB18d8doxekjoaNhdlhL3+r7b61dBYOHv4xBKgSlfoB/lNqhEit1XLlihnGXBZMn
# NhU1j8pYp3A7Fza9NsjGx7RSLcHZqptsp+C35HHT5dO4vScVxN85rdLbxM0WvFDI
# 33ryqN67ZDfuWGk=
# SIG # End signature block
