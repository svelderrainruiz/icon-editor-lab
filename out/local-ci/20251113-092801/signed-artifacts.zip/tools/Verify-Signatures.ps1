# Verify-Signatures.ps1
[CmdletBinding()]
param(
  [Parameter()][string]$SearchRoot = (Get-Location).Path,
  [Parameter()][string[]]$Include = @("*.ps1","*.psm1"),
  [Parameter()][string[]]$ExcludeDirs = @(".git",".github",".venv","node_modules")
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'
$files = Get-ChildItem -LiteralPath $SearchRoot -Recurse -File -Include $Include | Where-Object {
  $rel = $_.FullName.Substring($SearchRoot.Length).TrimStart('\','/')
  -not ($ExcludeDirs | ForEach-Object { $rel -like ("{0}\*" -f $_) })
}
$bad = @()
foreach ($f in $files) {
  $sig = Get-AuthenticodeSignature -LiteralPath $f.FullName
  if ($sig.Status -ne 'Valid') { $bad += [pscustomobject]@{ Path = $f.FullName; Status = $sig.Status } }
}
if ($bad.Count -gt 0) {
  $bad | Format-Table -AutoSize | Out-String | Write-Output
  throw "Signature check failed for $($bad.Count) file(s)."
}
Write-Output "All script signatures are VALID."

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDA5chJevy6MGSV
# tHJMuyIwbEkqLQdD7aRYKil20DYfiaCCAxYwggMSMIIB+qADAgECAhAqj8OqfNDA
# pkfPYtDNBMzOMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTcxOTIyWhcNMjUxMTI3MTcyOTIyWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAyi8OcOIK6/hl4qmBxN3sVyAuYyuIgy6+QPTo4wpDIdDS
# 7LvJt2oZ4EUEGnWpmTB80qOKvXSStnXCEnr/x7R0LIcdC6qwn8mzGqyWWbDdCRq2
# Isn08Jks8I9L38qJktofKYIH5k2pWFvVINQXUwVAEWyfAZnsvHOy/Gaxmhoy21lC
# Gvnc2FNqG7ufdBiEn6WIJgTybV5htpWRYtNb0R0eYjZd7Vx0nXI9T6lDPPWt0avf
# PUD5moeHjE3xd+mBbEPX0/DINxpHizCtsZk9z3ABN8/DzslMBR7+w+G0ZBrdOoq6
# i5M5Ig1ro02cUg+/UQwLsT6dBs5sDdl0wcjQjI6xzQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFPltSk9cj8z6
# ZWUWMRbaGiqmcsjDMA0GCSqGSIb3DQEBCwUAA4IBAQBtxnLHRemKSMTzcfhH648q
# OU9rAOZN1rQmM1fW40UDANx49kzWwWz5J/jKgwIioc7Byg7X6D+HuMMkCN8TFmw8
# rK3+iaS8zcVtOPG4881pGEKaB/JeUNZAnbUrO0yfVVc2gOQErxmkNPrpepy8tVJk
# BM4TilWTSyLW++/17Jory9cYo/BDr5u8QpVuBtydlEJmCB5SZEfuNfAVinHPjhzu
# FcIS3Q24MZ0ztuvUdpxRtm2tlii+l66RDvniTRqK5ZDn3hGuy4+DfjjbOsofhwJN
# uwQQcGoV4C0GOom+28COrGVk7kcVm0FLvT64MF6SCpvVzICQxax9eDNClegs/qpq
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAqj8OqfNDApkfPYtDNBMzOMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIIEZpCeYMGc2
# kHxmC59rnv7kFfu0+1EDOsevLQv84+74MA0GCSqGSIb3DQEBAQUABIIBALZa+c9G
# b+rxBYWl+morkukFALIjcq+lu6SUIvt4F4pxhLVN6/HCb700UVMGAJGsYgpHAVq5
# v9xXAmqRF3uyxnVwn4RqmnQf6HLNzSVLl3izAxoYj9KE/NYL/lQCsGc/hT/Mdm2w
# YnkgWaPJlEb7/hjuX2Vppldf175VPx78+cjlIulNuaE2RKsRDpRsnuM+wo9rH8Nl
# lyLfw3Lx9oKJTppr/zE+R6r/bSYvbEKjaKz9tXsBViaN97S2X2aAwSBrMcxkOxlj
# udE8qTzTiOisdL6lehfGIHZ58VBfAhaIP8XdzPyRrxmdYU0zJimaqRAmEELFrZau
# DKAYoF9ZPLWu5eA=
# SIG # End signature block
