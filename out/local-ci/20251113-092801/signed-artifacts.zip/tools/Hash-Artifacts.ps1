# Hash-Artifacts.ps1
[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$Root,
  [Parameter()][string]$Output = 'checksums.sha256'
)

Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'

$rootAbs = Resolve-Path -LiteralPath $Root -ErrorAction Stop
$rootPath = $rootAbs.ProviderPath
$items = Get-ChildItem -LiteralPath $rootPath -Recurse -File -ErrorAction Stop
$lines = New-Object System.Collections.Generic.List[string]
foreach ($i in $items) {
  $h = Get-FileHash -LiteralPath $i.FullName -Algorithm SHA256
  $relativePath = [System.IO.Path]::GetRelativePath($rootPath, $i.FullName)
  try {
    $lines.Add(("{0}  {1}" -f $h.Hash.ToLower(), $relativePath))
  } catch {
    throw "Failed to format hash entry for '$($i.FullName)' relative '$relativePath': $($_.Exception.Message)"
  }
}
$pathOut = Join-Path $rootPath $Output
$lines | Set-Content -LiteralPath $pathOut -Encoding UTF8 -NoNewline:$false
Write-Output "Wrote checksums to $pathOut"

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCASG2cZB9SxQNBP
# DwVC9asjKlcJItPjhuWB1EHHmj/2laCCAxYwggMSMIIB+qADAgECAhAqj8OqfNDA
# pkfPYtDNBMzOMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTcxOTIyWhcNMjUxMTI3MTcyOTIyWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAyi8OcOIK6/hl4qmBxN3sVyAuYyuIgy6+QPTo4wpDIdDS
# 7LvJt2oZ4EUEGnWpmTB80qOKvXSStnXCEnr/x7R0LIcdC6qwn8mzGqyWWbDdCRq2
# Isn08Jks8I9L38qJktofKYIH5k2pWFvVINQXUwVAEWyfAZnsvHOy/Gaxmhoy21lC
# Gvnc2FNqG7ufdBiEn6WIJgTybV5htpWRYtNb0R0eYjZd7Vx0nXI9T6lDPPWt0avf
# PUD5moeHjE3xd+mBbEPX0/DINxpHizCtsZk9z3ABN8/DzslMBR7+w+G0ZBrdOoq6
# i5M5Ig1ro02cUg+/UQwLsT6dBs5sDdl0wcjQjI6xzQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFPltSk9cj8z6
# ZWUWMRbaGiqmcsjDMA0GCSqGSIb3DQEBCwUAA4IBAQBtxnLHRemKSMTzcfhH648q
# OU9rAOZN1rQmM1fW40UDANx49kzWwWz5J/jKgwIioc7Byg7X6D+HuMMkCN8TFmw8
# rK3+iaS8zcVtOPG4881pGEKaB/JeUNZAnbUrO0yfVVc2gOQErxmkNPrpepy8tVJk
# BM4TilWTSyLW++/17Jory9cYo/BDr5u8QpVuBtydlEJmCB5SZEfuNfAVinHPjhzu
# FcIS3Q24MZ0ztuvUdpxRtm2tlii+l66RDvniTRqK5ZDn3hGuy4+DfjjbOsofhwJN
# uwQQcGoV4C0GOom+28COrGVk7kcVm0FLvT64MF6SCpvVzICQxax9eDNClegs/qpq
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAqj8OqfNDApkfPYtDNBMzOMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIFwh7Ia6nNVg
# FzrXU1zSmX6Kq7zfAQC5vDsMmiqye02wMA0GCSqGSIb3DQEBAQUABIIBADYW6DfG
# WTyWZdILgZcCGuxppEPmRwozYRNQrjBSAza4zCe9IBPWcyVgh/0xNw1GiTfkbH5P
# 9ohKMu45uxJMHxlmqkqM51XchyTRwhjxqXsv8PpNLCk5nw0Z5ZiOmlyASIv0GQf6
# ZbflkptWHvldvhqw701a8QsOuzONxeJCzdLGgrpaI9Ty5hSOgQnByTgn4S6pqpdX
# fiKxCYN+kJEmYjxhmVURg1yaFfNaEPd0OoLtKq+E6lvc7PaWFaUpINJjTnZz0MRG
# nDyfJYZaPWWASZB3iZkwRUQwXHH9ETsTzN7vE6xKgB0froNAE+HJeQ5VpHQg+Myb
# iMqtyCNCAmwBv/Y=
# SIG # End signature block
