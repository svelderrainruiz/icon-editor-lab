# Secure-Process.psm1
Set-StrictMode -Version Latest
. (Join-Path $PSScriptRoot 'Validate-Paths.ps1')
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Invoke-ProcessSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$FilePath,
        [Parameter()][string[]]$ArgumentList = @(),
        [Parameter()][int]$TimeoutSec = 600,
        [Parameter()][string]$WorkingDirectory = (Get-Location).Path
    )
    if (-not (Test-Path -LiteralPath $FilePath -PathType Leaf)) { throw "FilePath not found: $FilePath" }
    $psi = [System.Diagnostics.ProcessStartInfo]::new()
    $psi.FileName = $FilePath
    $psi.WorkingDirectory = (Validate-PathSafe -Path $WorkingDirectory)
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.UseShellExecute = $false
    foreach ($a in $ArgumentList) { $null = $psi.ArgumentList.Add($a) }

    $p = [System.Diagnostics.Process]::new()
    $p.StartInfo = $psi
    if (-not $p.Start()) { throw "Failed to start process: $FilePath" }
    try {
        if (-not $p.WaitForExit($TimeoutSec * 1000)) {
            try { $p.Kill($true) } catch {}
            throw "Process timed out after $TimeoutSec s: $FilePath"
        }
        $stdout = $p.StandardOutput.ReadToEnd()
        $stderr = $p.StandardError.ReadToEnd()
        return [pscustomobject]@{
            ExitCode = $p.ExitCode
            StdOut = $stdout
            StdErr = $stderr
        }
    } finally {
        if (-not $p.HasExited) { try { $p.Kill($true) } catch {} }
        $p.Dispose()
    }
}
Export-ModuleMember -Function Invoke-ProcessSafe

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDLM/hZ77J6ko3k
# J1T1SnSI3Zjg9T8EF5sOyyHIvgXLgqCCAxYwggMSMIIB+qADAgECAhAqj8OqfNDA
# pkfPYtDNBMzOMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTcxOTIyWhcNMjUxMTI3MTcyOTIyWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAyi8OcOIK6/hl4qmBxN3sVyAuYyuIgy6+QPTo4wpDIdDS
# 7LvJt2oZ4EUEGnWpmTB80qOKvXSStnXCEnr/x7R0LIcdC6qwn8mzGqyWWbDdCRq2
# Isn08Jks8I9L38qJktofKYIH5k2pWFvVINQXUwVAEWyfAZnsvHOy/Gaxmhoy21lC
# Gvnc2FNqG7ufdBiEn6WIJgTybV5htpWRYtNb0R0eYjZd7Vx0nXI9T6lDPPWt0avf
# PUD5moeHjE3xd+mBbEPX0/DINxpHizCtsZk9z3ABN8/DzslMBR7+w+G0ZBrdOoq6
# i5M5Ig1ro02cUg+/UQwLsT6dBs5sDdl0wcjQjI6xzQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFPltSk9cj8z6
# ZWUWMRbaGiqmcsjDMA0GCSqGSIb3DQEBCwUAA4IBAQBtxnLHRemKSMTzcfhH648q
# OU9rAOZN1rQmM1fW40UDANx49kzWwWz5J/jKgwIioc7Byg7X6D+HuMMkCN8TFmw8
# rK3+iaS8zcVtOPG4881pGEKaB/JeUNZAnbUrO0yfVVc2gOQErxmkNPrpepy8tVJk
# BM4TilWTSyLW++/17Jory9cYo/BDr5u8QpVuBtydlEJmCB5SZEfuNfAVinHPjhzu
# FcIS3Q24MZ0ztuvUdpxRtm2tlii+l66RDvniTRqK5ZDn3hGuy4+DfjjbOsofhwJN
# uwQQcGoV4C0GOom+28COrGVk7kcVm0FLvT64MF6SCpvVzICQxax9eDNClegs/qpq
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAqj8OqfNDApkfPYtDNBMzOMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPEK5pYr/oiP
# 6zXDh72ZtLHO5VLyj1aDMXhTjDbbSs4wMA0GCSqGSIb3DQEBAQUABIIBADIWq6Sa
# psmhrxFW2IX5NsWRxNis3QwnkLTfUBQv9W8b99BsiCMtABxfSjlR8iF/Kyju/bu/
# XD7M4W4aI5eHPCfwFynaIh1ZKrLmk98vhCWr66T/3XxjEizsgMXyvPjNNLOUsfuO
# wiks5O8EScZYu4OATstujfPLPAkrz+oOurPHIixx9ZnnPR5dsKDWwShuEgZ3RrEd
# bTtmepwWFJTYdOPzDvjRPr08qZTYSfs0Pj0d43rXYsxMXGXL1FMxfF/zKzI29Ccp
# kKa+mZwl4X/Vpd68U+Jc2hEFQufoyLEn+TecMcfO3sIGmT3zVX5Det2rQoz92/Ss
# fjxYpll1pR84YGU=
# SIG # End signature block
