# Secure-Process.psm1
Set-StrictMode -Version Latest
. (Join-Path $PSScriptRoot 'Validate-Paths.ps1')
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Invoke-ProcessSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$FilePath,
        [Parameter()][string[]]$ArgumentList = @(),
        [Parameter()][int]$TimeoutSec = 600,
        [Parameter()][string]$WorkingDirectory = (Get-Location).Path
    )
    if (-not (Test-Path -LiteralPath $FilePath -PathType Leaf)) { throw "FilePath not found: $FilePath" }
    $psi = [System.Diagnostics.ProcessStartInfo]::new()
    $psi.FileName = $FilePath
    $psi.WorkingDirectory = (Validate-PathSafe -Path $WorkingDirectory)
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.UseShellExecute = $false
    foreach ($a in $ArgumentList) { $null = $psi.ArgumentList.Add($a) }

    $p = [System.Diagnostics.Process]::new()
    $p.StartInfo = $psi
    if (-not $p.Start()) { throw "Failed to start process: $FilePath" }
    try {
        if (-not $p.WaitForExit($TimeoutSec * 1000)) {
            try { $p.Kill($true) } catch {}
            throw "Process timed out after $TimeoutSec s: $FilePath"
        }
        $stdout = $p.StandardOutput.ReadToEnd()
        $stderr = $p.StandardError.ReadToEnd()
        return [pscustomobject]@{
            ExitCode = $p.ExitCode
            StdOut = $stdout
            StdErr = $stderr
        }
    } finally {
        if (-not $p.HasExited) { try { $p.Kill($true) } catch {} }
        $p.Dispose()
    }
}
Export-ModuleMember -Function Invoke-ProcessSafe

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDLM/hZ77J6ko3k
# J1T1SnSI3Zjg9T8EF5sOyyHIvgXLgqCCAxYwggMSMIIB+qADAgECAhA83WE/rhn2
# l0OcPF3u+QJAMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMjEyMjQyWhcNMjUxMTI3MjEzMjQyWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAnE6vrMg91ZHwZl9qNGROaqxo542ak1N2jZ+73XGq3RxY
# hHygtm8IfF1lo/F8vt/Ittw+J+noCgMDVw/RiOsT5Q+wFMKplBU9bpUplr2wJryv
# S6qYNFoUxqSfHE5mfEpxhK6A+KFlaY/sn6d91v0pV8IP9xYXkkyNmAdq1AQO5SNT
# A72T81wDpNLVhdxlRfAway7g79bwFddBFaR9w3Eeuxap3agdNzTLQQbkQYfQaZtB
# D79CLN9j7Ow9WOH1Q1BIJ2d8dfQRjpQ60ISxmPlzxLixASwvUKnKxweWJzO+0PbU
# s8iguR1YxpAHzzghof01L6s6BVrl8DGTUCbt+I0HAQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFBq1djI/BdCl
# GVHSs6z0dBZLWj6SMA0GCSqGSIb3DQEBCwUAA4IBAQBPIj/upa6yzxgKxeH8Lwl9
# cBnVzbfnzyla2u/w1aQM4w+I3bj2jw0dxbDtrsf7IFK8FMYVQBPMX1h59SNVlUuM
# h1SCfsabxl4Fa9BbDSJRn2VxjLQOoaOx//fM+QmTPkE568jdBXQrCpLMnuA8ydf6
# fTCoIo8257yXtBfdQWxGl3aU/AiHwa1+BE9cQv+YXlGtL8kAX87ntlb62+uzzjnT
# UHWigj+aG9pRZWlBAmPxXHy7ZtxIvHPhu+JFHFPvmNyfby7N7n2LP+8xcPlqYDLR
# /cu6nxeLcJKcCXK3iEM1VWxAVVRULFVzZVVHN4JoCQ+zCTXV6u3rfIMkOHiqLE03
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhA83WE/rhn2l0OcPF3u+QJAMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPEK5pYr/oiP
# 6zXDh72ZtLHO5VLyj1aDMXhTjDbbSs4wMA0GCSqGSIb3DQEBAQUABIIBAIaccvDM
# S+6pVpQAQ2rgBKOaWvHH5Uj1FmsV5/3ia4hQ1XpvaBcss74/w+K12Puninx8DfQS
# VRu57KoVMH4yoeP5wKC059Vv1DDwmodqDx2GOuaZUtfsK2Jt//pSdofXhjfcMMDx
# 1url2vDTwfMrQrxTcUmz9r8E0p5/xM2lKIUyT0ArFNKTMWwrCiL7ldQN3m56A/t4
# RDvVHTf1mB6YMFu+uL+323r2lLetTSJTzxOjE6EkuhC6P7v02oWjNd0ppx/QwOeE
# Mi/fE98lxXGBLpvRS37WvAZAwfxljzyheijeXV4T4SpmrCgyEWxeORBFtxWHB0F9
# i1K44zCZsbhikHc=
# SIG # End signature block
