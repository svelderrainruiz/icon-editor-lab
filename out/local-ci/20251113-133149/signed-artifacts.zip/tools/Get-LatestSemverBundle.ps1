#Requires -Version 7.0
[CmdletBinding()]
param(
    [string]$Root = 'out/semver-bundle'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$rootPath = [System.IO.Path]::GetFullPath($Root)
if (-not (Test-Path -LiteralPath $rootPath -PathType Container)) {
    throw "[SVB300] No SemVer bundles found under $rootPath"
}

$bundle = Get-ChildItem -LiteralPath $rootPath -Directory | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $bundle) {
    throw "[SVB300] No SemVer bundles found under $rootPath"
}

$summaryPath = Join-Path $bundle.FullName 'semver-summary.json'
$summary = $null
if (Test-Path -LiteralPath $summaryPath -PathType Leaf) {
    try {
        $summary = Get-Content -LiteralPath $summaryPath -Raw | ConvertFrom-Json -ErrorAction Stop
    } catch {
        Write-Warning ("[SVB202] Failed to read summary JSON: {0}" -f $_.Exception.Message)
    }
}

[pscustomobject]@{
    BundleRoot = $bundle.FullName
    ZipPath    = "$($bundle.FullName).zip"
    Summary    = $summary
}

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDX1yHpgv4n6QSq
# t5kkJikX+boV/u0FrptEuQebx9o3l6CCAxYwggMSMIIB+qADAgECAhA83WE/rhn2
# l0OcPF3u+QJAMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMjEyMjQyWhcNMjUxMTI3MjEzMjQyWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAnE6vrMg91ZHwZl9qNGROaqxo542ak1N2jZ+73XGq3RxY
# hHygtm8IfF1lo/F8vt/Ittw+J+noCgMDVw/RiOsT5Q+wFMKplBU9bpUplr2wJryv
# S6qYNFoUxqSfHE5mfEpxhK6A+KFlaY/sn6d91v0pV8IP9xYXkkyNmAdq1AQO5SNT
# A72T81wDpNLVhdxlRfAway7g79bwFddBFaR9w3Eeuxap3agdNzTLQQbkQYfQaZtB
# D79CLN9j7Ow9WOH1Q1BIJ2d8dfQRjpQ60ISxmPlzxLixASwvUKnKxweWJzO+0PbU
# s8iguR1YxpAHzzghof01L6s6BVrl8DGTUCbt+I0HAQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFBq1djI/BdCl
# GVHSs6z0dBZLWj6SMA0GCSqGSIb3DQEBCwUAA4IBAQBPIj/upa6yzxgKxeH8Lwl9
# cBnVzbfnzyla2u/w1aQM4w+I3bj2jw0dxbDtrsf7IFK8FMYVQBPMX1h59SNVlUuM
# h1SCfsabxl4Fa9BbDSJRn2VxjLQOoaOx//fM+QmTPkE568jdBXQrCpLMnuA8ydf6
# fTCoIo8257yXtBfdQWxGl3aU/AiHwa1+BE9cQv+YXlGtL8kAX87ntlb62+uzzjnT
# UHWigj+aG9pRZWlBAmPxXHy7ZtxIvHPhu+JFHFPvmNyfby7N7n2LP+8xcPlqYDLR
# /cu6nxeLcJKcCXK3iEM1VWxAVVRULFVzZVVHN4JoCQ+zCTXV6u3rfIMkOHiqLE03
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhA83WE/rhn2l0OcPF3u+QJAMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIEYBD5Y3r8tS
# z19YGGp/FTByrUm5EHI8CkcR3OTA0txvMA0GCSqGSIb3DQEBAQUABIIBAADlCGBj
# IWPR+BHElPstVc/Ip8meEDMEgeLcRPV33anxDUPxsaU/hEbvolRj0u+Cdflxdcl1
# 0vnswAYuTq4XEqXDRJzNuJK8oKQn2IX/lXsWo10+Mc6CvsncdHOjh8G2PrWtuToJ
# LhYf1Y4HLo7KEqucFAaVHb4OJU4OyjDW+TbKE33J++gQohy+rdUP9DVg077djetY
# nF2NcWtejWOb/r1YOzqDKB0snJcCWXIYkIzEJTtO/ePku7JNNOBfwtzH8lxQXUR6
# N0wIRploEDYqbwkK5IpPwsH15bFDXCJsWbe6pW4TDjxRNkIbZAUYKt2EqREGt0vp
# PhusWER868gzUvY=
# SIG # End signature block
