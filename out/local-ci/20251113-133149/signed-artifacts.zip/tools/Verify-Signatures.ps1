# Verify-Signatures.ps1
[CmdletBinding()]
param(
  [Parameter()][string]$SearchRoot = (Get-Location).Path,
  [Parameter()][string[]]$Include = @("*.ps1","*.psm1"),
  [Parameter()][string[]]$ExcludeDirs = @(".git",".github",".venv","node_modules")
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'
$files = Get-ChildItem -LiteralPath $SearchRoot -Recurse -File -Include $Include | Where-Object {
  $rel = $_.FullName.Substring($SearchRoot.Length).TrimStart('\','/')
  -not ($ExcludeDirs | ForEach-Object { $rel -like ("{0}\*" -f $_) })
}
$bad = @()
foreach ($f in $files) {
  $sig = Get-AuthenticodeSignature -LiteralPath $f.FullName
  if ($sig.Status -ne 'Valid') { $bad += [pscustomobject]@{ Path = $f.FullName; Status = $sig.Status } }
}
if ($bad.Count -gt 0) {
  $bad | Format-Table -AutoSize | Out-String | Write-Output
  throw "Signature check failed for $($bad.Count) file(s)."
}
Write-Output "All script signatures are VALID."

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDA5chJevy6MGSV
# tHJMuyIwbEkqLQdD7aRYKil20DYfiaCCAxYwggMSMIIB+qADAgECAhA83WE/rhn2
# l0OcPF3u+QJAMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMjEyMjQyWhcNMjUxMTI3MjEzMjQyWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAnE6vrMg91ZHwZl9qNGROaqxo542ak1N2jZ+73XGq3RxY
# hHygtm8IfF1lo/F8vt/Ittw+J+noCgMDVw/RiOsT5Q+wFMKplBU9bpUplr2wJryv
# S6qYNFoUxqSfHE5mfEpxhK6A+KFlaY/sn6d91v0pV8IP9xYXkkyNmAdq1AQO5SNT
# A72T81wDpNLVhdxlRfAway7g79bwFddBFaR9w3Eeuxap3agdNzTLQQbkQYfQaZtB
# D79CLN9j7Ow9WOH1Q1BIJ2d8dfQRjpQ60ISxmPlzxLixASwvUKnKxweWJzO+0PbU
# s8iguR1YxpAHzzghof01L6s6BVrl8DGTUCbt+I0HAQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFBq1djI/BdCl
# GVHSs6z0dBZLWj6SMA0GCSqGSIb3DQEBCwUAA4IBAQBPIj/upa6yzxgKxeH8Lwl9
# cBnVzbfnzyla2u/w1aQM4w+I3bj2jw0dxbDtrsf7IFK8FMYVQBPMX1h59SNVlUuM
# h1SCfsabxl4Fa9BbDSJRn2VxjLQOoaOx//fM+QmTPkE568jdBXQrCpLMnuA8ydf6
# fTCoIo8257yXtBfdQWxGl3aU/AiHwa1+BE9cQv+YXlGtL8kAX87ntlb62+uzzjnT
# UHWigj+aG9pRZWlBAmPxXHy7ZtxIvHPhu+JFHFPvmNyfby7N7n2LP+8xcPlqYDLR
# /cu6nxeLcJKcCXK3iEM1VWxAVVRULFVzZVVHN4JoCQ+zCTXV6u3rfIMkOHiqLE03
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhA83WE/rhn2l0OcPF3u+QJAMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIIEZpCeYMGc2
# kHxmC59rnv7kFfu0+1EDOsevLQv84+74MA0GCSqGSIb3DQEBAQUABIIBACeDP31p
# fQPrR6W23J/mcAppbcb/KsRvpLP0KKf2FZkm9UW35VQo7agH+0nrcqmhLEzdGGnF
# 5edNTapGEAKbFt9U7aoBZb++zqN5bIn7ugZxRuIUMfyIOEa3aGpZh+payejQFGLJ
# UurbiTOKbVCNWG9iBAQom6sDqq+vpyjSy/gGa5mjBMnH3JA89D1rioblhHcuGnyn
# Nh9/43TuSGth+Ez0fR4nS/GtbXaDnmPICfzhv91dWyeS8i3sg1rTlw437MBmA/mT
# 4+JPDfTGqYaRhz34pw9cTN2VfgJaHXrn9JVYwW64vyKVE3FcWKXhWImin5ludYHe
# EXhWdCZl3jZfg4Y=
# SIG # End signature block
