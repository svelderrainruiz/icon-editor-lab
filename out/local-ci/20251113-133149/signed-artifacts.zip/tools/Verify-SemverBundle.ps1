#Requires -Version 7.0
[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$BundlePath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Resolve-Manifest {
  param([string]$Path)
  if ((Test-Path -LiteralPath $Path -PathType Container)) {
    $candidate = Join-Path $Path 'bundle.json'
    if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) {
      throw "bundle.json not found under $Path"
    }
    return $candidate
  }
  if ((Test-Path -LiteralPath $Path -PathType Leaf) -and $Path.EndsWith('.zip')) {
    $tempDir = New-Item -ItemType Directory -Force -Path (Join-Path $env:TEMP "semver-bundle-$(Get-Random)")
    Expand-Archive -LiteralPath $Path -DestinationPath $tempDir -Force
    $manifest = Join-Path $tempDir 'bundle.json'
    if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) {
      throw "bundle.json missing inside archive $Path"
    }
    return $manifest
  }
  throw "Unsupported bundle path: $Path"
}

$manifestPath = Resolve-Manifest -Path $BundlePath
$bundleRoot = Split-Path -Parent $manifestPath
$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
$failures = @()

foreach ($file in $manifest.files) {
  $fullPath = Join-Path $bundleRoot $file.relativePath
  if (-not (Test-Path -LiteralPath $fullPath -PathType Leaf)) {
    $failures += "Missing file: $($file.relativePath)"
    continue
  }
  $hash = (Get-FileHash -LiteralPath $fullPath -Algorithm SHA256).Hash
  if ($hash -ne $file.sha256) {
    $failures += "Hash mismatch ($($file.relativePath)) expected $($file.sha256) actual $hash"
  }
}

if ($failures.Count -gt 0) {
  Write-Error "Bundle verification failed:" -ErrorAction Stop
}

Write-Host "Bundle verified successfully: $bundleRoot" -ForegroundColor Green

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDjr3yXkH4ndjxr
# 1Y11zhgNRCuKm1tcHCh7s0nCEGFYb6CCAxYwggMSMIIB+qADAgECAhA83WE/rhn2
# l0OcPF3u+QJAMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMjEyMjQyWhcNMjUxMTI3MjEzMjQyWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAnE6vrMg91ZHwZl9qNGROaqxo542ak1N2jZ+73XGq3RxY
# hHygtm8IfF1lo/F8vt/Ittw+J+noCgMDVw/RiOsT5Q+wFMKplBU9bpUplr2wJryv
# S6qYNFoUxqSfHE5mfEpxhK6A+KFlaY/sn6d91v0pV8IP9xYXkkyNmAdq1AQO5SNT
# A72T81wDpNLVhdxlRfAway7g79bwFddBFaR9w3Eeuxap3agdNzTLQQbkQYfQaZtB
# D79CLN9j7Ow9WOH1Q1BIJ2d8dfQRjpQ60ISxmPlzxLixASwvUKnKxweWJzO+0PbU
# s8iguR1YxpAHzzghof01L6s6BVrl8DGTUCbt+I0HAQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFBq1djI/BdCl
# GVHSs6z0dBZLWj6SMA0GCSqGSIb3DQEBCwUAA4IBAQBPIj/upa6yzxgKxeH8Lwl9
# cBnVzbfnzyla2u/w1aQM4w+I3bj2jw0dxbDtrsf7IFK8FMYVQBPMX1h59SNVlUuM
# h1SCfsabxl4Fa9BbDSJRn2VxjLQOoaOx//fM+QmTPkE568jdBXQrCpLMnuA8ydf6
# fTCoIo8257yXtBfdQWxGl3aU/AiHwa1+BE9cQv+YXlGtL8kAX87ntlb62+uzzjnT
# UHWigj+aG9pRZWlBAmPxXHy7ZtxIvHPhu+JFHFPvmNyfby7N7n2LP+8xcPlqYDLR
# /cu6nxeLcJKcCXK3iEM1VWxAVVRULFVzZVVHN4JoCQ+zCTXV6u3rfIMkOHiqLE03
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhA83WE/rhn2l0OcPF3u+QJAMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEILQuIDyMgfaK
# B382xHdCDlgpFW4Gkiy8p3BaoHKMRV6AMA0GCSqGSIb3DQEBAQUABIIBAIdh6h+T
# Rmvoqf6Z89Lm+3pW5gofBC+y9dK3EWeIGNYQ66pUZ+xYXH/3Xdo8GoW7WzHZtyrJ
# GwL3wAC6TKiyArb8bKLsPf4d1Xx7x8ZUAepL/RXnqV9/RhB9DlWEYMGDVCGEd7q8
# qwe0tS9Pd27QN1RYN88tN4HwoFpNWA450q6sqcZgs/KWA5MP4swSrTXPyZCqOMMh
# q9cfhWwyxn7OWWEgtILSULvZFRZLtA9WITLf6kTaNmo+hnAJyXclnmiE/pvEJtZN
# WiPCYAJpHGwDhkaIUip3G+pJdGAMjGMoCSgcjIMe2XqDnRwiX+NJZPQiyMJ2+wwT
# +ZNiKJWSCSV66mk=
# SIG # End signature block
