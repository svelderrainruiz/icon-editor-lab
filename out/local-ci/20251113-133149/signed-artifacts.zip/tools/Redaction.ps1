# Redaction.ps1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Write-LogSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Message,
        [Parameter()][ValidateSet('INFO','WARN','ERROR')][string]$Level = 'INFO'
    )
    # Redact common secret/token patterns (simple heuristic)
    $msg = $Message -replace '([A-Za-z0-9-_]{20,})','****' `
                    -replace '(?i)(secret|token|password)\s*[:=]\s*[^ \t\r\n]+','$1=****'
    $ts = (Get-Date).ToString('s')
    Write-Output "[$ts][$Level] $msg"
}
if ($ExecutionContext.SessionState.Module) {
    Export-ModuleMember -Function Write-LogSafe
}

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCB5QE8/zfwZTTR5
# g9if2C7NwESBApxi1XkQIcw6fBWi3aCCAxYwggMSMIIB+qADAgECAhA83WE/rhn2
# l0OcPF3u+QJAMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMjEyMjQyWhcNMjUxMTI3MjEzMjQyWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAnE6vrMg91ZHwZl9qNGROaqxo542ak1N2jZ+73XGq3RxY
# hHygtm8IfF1lo/F8vt/Ittw+J+noCgMDVw/RiOsT5Q+wFMKplBU9bpUplr2wJryv
# S6qYNFoUxqSfHE5mfEpxhK6A+KFlaY/sn6d91v0pV8IP9xYXkkyNmAdq1AQO5SNT
# A72T81wDpNLVhdxlRfAway7g79bwFddBFaR9w3Eeuxap3agdNzTLQQbkQYfQaZtB
# D79CLN9j7Ow9WOH1Q1BIJ2d8dfQRjpQ60ISxmPlzxLixASwvUKnKxweWJzO+0PbU
# s8iguR1YxpAHzzghof01L6s6BVrl8DGTUCbt+I0HAQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFBq1djI/BdCl
# GVHSs6z0dBZLWj6SMA0GCSqGSIb3DQEBCwUAA4IBAQBPIj/upa6yzxgKxeH8Lwl9
# cBnVzbfnzyla2u/w1aQM4w+I3bj2jw0dxbDtrsf7IFK8FMYVQBPMX1h59SNVlUuM
# h1SCfsabxl4Fa9BbDSJRn2VxjLQOoaOx//fM+QmTPkE568jdBXQrCpLMnuA8ydf6
# fTCoIo8257yXtBfdQWxGl3aU/AiHwa1+BE9cQv+YXlGtL8kAX87ntlb62+uzzjnT
# UHWigj+aG9pRZWlBAmPxXHy7ZtxIvHPhu+JFHFPvmNyfby7N7n2LP+8xcPlqYDLR
# /cu6nxeLcJKcCXK3iEM1VWxAVVRULFVzZVVHN4JoCQ+zCTXV6u3rfIMkOHiqLE03
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhA83WE/rhn2l0OcPF3u+QJAMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIEfHLCIlw9Py
# EI3fUHQlFhw4tq7Q+oRZQIlIetQ/aFBMMA0GCSqGSIb3DQEBAQUABIIBAEV0Ndwt
# YLTt+4NYJleXGwtoYkqVumEtrvCdSc7kItsXh43/sD2I9pnKlbIyeN+uEzk4kfFU
# /sFYz3WrDWEQhTWtAoynbXCCJIsLp5YbBz92+igroU0AMINvDuLd49TOOSq4kPei
# u+lkvZVdp0NWT7TDy+uOqdLBlsZ871Q61DruRA9QS5CWgFn9P9CexruogT01Lu6d
# o0zMBS2rpbVBCw91fPQ1ZRTBvvebM/bNFJm5KwEh8RXR1RaPpS5jMbJHkC+1TfAJ
# XnURFTBXbZcRqiKYObD9iO7mnDMVtOicfgmBPDKZxo4pCpGxeeaDQ2jfRqHoMcKF
# kOh9bc8h2H38/IU=
# SIG # End signature block
