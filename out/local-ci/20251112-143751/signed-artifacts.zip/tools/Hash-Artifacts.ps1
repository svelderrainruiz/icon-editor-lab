# Hash-Artifacts.ps1
[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$Root,
  [Parameter()][string]$Output = 'checksums.sha256'
)

Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'

$rootAbs = Resolve-Path -LiteralPath $Root -ErrorAction Stop
$rootPath = $rootAbs.ProviderPath
$items = Get-ChildItem -LiteralPath $rootPath -Recurse -File -ErrorAction Stop
$lines = New-Object System.Collections.Generic.List[string]
foreach ($i in $items) {
  $h = Get-FileHash -LiteralPath $i.FullName -Algorithm SHA256
  $relativePath = [System.IO.Path]::GetRelativePath($rootPath, $i.FullName)
  try {
    $lines.Add(("{0}  {1}" -f $h.Hash.ToLower(), $relativePath))
  } catch {
    throw "Failed to format hash entry for '$($i.FullName)' relative '$relativePath': $($_.Exception.Message)"
  }
}
$pathOut = Join-Path $rootPath $Output
$lines | Set-Content -LiteralPath $pathOut -Encoding UTF8 -NoNewline:$false
Write-Output "Wrote checksums to $pathOut"

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCASG2cZB9SxQNBP
# DwVC9asjKlcJItPjhuWB1EHHmj/2laCCAxYwggMSMIIB+qADAgECAhBTopZaMnO+
# kU9jH9AEvKuOMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEyMjIyNzU4WhcNMjUxMTI2MjIzNzU4WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAvUoTjvrrbjqgxIUrxox6lQOoecbRPGi9WiW7+jxoSeu+
# RS2VpT76TnkVY1B9r9IWMIEKHxqLBuqj0u1GeUoNYPqp7H/Ae8q0nd6C7e+2E9jo
# J3Ss4A0r/ySDOssVVns0DC7chVMOxm8fQ6lNAng4UXJBEWHVqfA9OGVskdX5qQ5k
# uBUwJijdJCIHI+/D4m3M5eUGv22i7O3kz2jUGR6b9O1SP4vXjI96gb6rMlXQltK2
# jGNmrm/1yV6BpiQ3D1DiEMLigPsLzFHmGpZADcGeDU40wXoMfcsgr5gsR6o3cdur
# siq64FTUJp39Ud+EtyFEYQI5k7cNaiW7iWBNk3M+xQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFD3W3E95+Ve8
# vtLX92iEbiCm3E2TMA0GCSqGSIb3DQEBCwUAA4IBAQCQS42mPlTkt/PnZIYP8+Tb
# 21qVZR5rTHqkar9gsJOY0iSOulb5bdSCbJxi13rvC9M1CrtE2Yf42vTp0Cz+Yc2+
# yFWL0nq9vZ+qp/7iHWhVXSDz6O5/M1zkYrHl2CYOxN/SLy4ECygC5jfKPIzP0PDf
# Wo+sWGzsHfix4oNhgOY2DCaoLnd22wqJgkP9T8OjbpVs6DWpBYK8AEuQYac/bKnd
# v2GABePvXPCF87CURahiN3GLYB8TMHbrXrnzNTlPNo6SEXF3Fk3776xOjMr6EaHF
# 71gCWtdHWpaA/b4hkH+jRuynDIO1IwxuxL+wuE1il+sgoESJlKvF2Hun1vfoFr8b
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBTopZaMnO+kU9jH9AEvKuOMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIFwh7Ia6nNVg
# FzrXU1zSmX6Kq7zfAQC5vDsMmiqye02wMA0GCSqGSIb3DQEBAQUABIIBAIxZ5AH3
# 2FXKeVsoANxsLgbTgp0NvU1Wd/rM8QjyeMelJlnFvVKaHEAtbRxT/TABJOY5ZNBe
# 5u2KS8gHZKOW7kBSNVVkA6EmdowrH9ok0Gs7pq2d94vT/6/ydljF8O7XqOftHP3i
# hgoaF8M605MwbMnvzhFuRZVmSfqyt3RCknU2a4vlevvpOYOfkEWDTo5jqnWo5WUp
# X+kkB2ckdgaiZ70JvA5Srsb5FD8rbc7/rVF8oWaL667kpJlsr9MQpHYcEdXWOnAH
# hiiDXiYqtF3LRFMF0EipuSYV0p2vfnZSKXtO1beSwaGYkHE16TFwMLMx9Io7VE4G
# LfHLde04QUptJ/U=
# SIG # End signature block
