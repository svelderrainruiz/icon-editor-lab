# Sign-Scripts.ps1
[CmdletBinding()]
param(
  [Parameter()][string]$Thumbprint,
  [Parameter()][string]$SearchRoot = (Get-Location).Path,
  [Parameter()][string[]]$Include = @("*.ps1","*.psm1"),
  [Parameter()][string[]]$ExcludeDirs = @(".git",".github",".venv","node_modules"),
  [switch]$SkipTimestamp,
  [Parameter()][ValidateRange(1,1000)][int]$ProgressInterval = 25,
  [Parameter()][ValidateRange(0,1000)][int]$ThrottleMilliseconds = 0
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'
if (-not (Test-Path -LiteralPath $SearchRoot -PathType Container)) {
  throw "Search root not found: $SearchRoot"
}
Write-Host "Signing scripts under: $SearchRoot"
$includeMatchers = @(
  $Include | ForEach-Object {
    if ($_ -and $_.Trim()) {
      [System.Management.Automation.WildcardPattern]::new($_.Trim(),'IgnoreCase')
    }
  }
)
if ($includeMatchers.Count -eq 0) {
  $includeMatchers = @([System.Management.Automation.WildcardPattern]::new('*','IgnoreCase'))
}
function Get-GitTrackedFiles {
  param()
  $gitDir = Join-Path $SearchRoot '.git'
  if (-not (Test-Path -LiteralPath $gitDir -PathType Container)) {
    return @()
  }
  Push-Location $SearchRoot
  try {
    $arguments = @('ls-files','-z','--','*.ps1','*.psm1')
    $output = & git @arguments 2>$null
    if ($LASTEXITCODE -ne 0 -or -not $output) {
      return @()
    }
    return $output -split "`0" | Where-Object { $_ }
  }
  finally {
    Pop-Location
  }
}
function Get-CodeSigningCert {
  param([string]$Thumbprint)
  if ($Thumbprint) {
    $c = Get-ChildItem Cert:\CurrentUser\My\$Thumbprint -ErrorAction SilentlyContinue
    if ($c) { return $c }
  }
  $c = Get-ChildItem Cert:\CurrentUser\My | Where-Object { $_.HasPrivateKey -and $_.EnhancedKeyUsageList.FriendlyName -contains 'Code Signing' } | Select-Object -First 1
  if (-not $c) { throw 'No suitable code-signing certificate found.' }
  return $c
}
$cert = Get-CodeSigningCert -Thumbprint $Thumbprint
$gitCandidates = Get-GitTrackedFiles
if ($gitCandidates.Count -gt 0) {
  Write-Host ("Discovered {0} git-tracked candidate(s) via ls-files." -f $gitCandidates.Count)
  $candidates = @(
    $gitCandidates | ForEach-Object {
      $path = Join-Path $SearchRoot $_
      if (Test-Path -LiteralPath $path -PathType Leaf) { Get-Item -LiteralPath $path }
    } | Where-Object { $_ }
  )
}
else {
  Write-Host 'git ls-files returned no matches; falling back to filesystem enumeration.'
  $candidates = @(Get-ChildItem -LiteralPath $SearchRoot -Recurse -File)
}
Write-Host ("Discovered {0} candidate file(s) before filtering." -f $candidates.Count)
$files = @($candidates | Where-Object {
  $rel = $_.FullName.Substring($SearchRoot.Length).TrimStart('\','/')
  if ($ExcludeDirs | Where-Object { $rel -like ("{0}\*" -f $_) }) {
    return $false
  }
  foreach ($matcher in $includeMatchers) {
    if ($matcher.IsMatch($_.Name)) { return $true }
  }
  return $false
})
$total = $files.Count
if ($total -eq 0) {
  Write-Warning 'No files matched the signing criteria; nothing to do.'
  return
}
$stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
$processed = 0
foreach ($f in $files) {
  $sig = Get-AuthenticodeSignature -LiteralPath $f.FullName
  if ($sig.Status -ne 'Valid') {
    if ($SkipTimestamp) {
      Write-Verbose ("Signing {0} without timestamp (ephemeral cert)." -f $f.FullName)
      $null = Set-AuthenticodeSignature -LiteralPath $f.FullName -Certificate $cert
    }
    else {
      Write-Verbose ("Signing {0} with timestamp server." -f $f.FullName)
      $null = Set-AuthenticodeSignature -LiteralPath $f.FullName -Certificate $cert -TimestampServer 'http://timestamp.digicert.com'
    }
  }
  $processed++
  $logCheckpoint = ($ProgressInterval -gt 0) -and (($processed -eq 1) -or ($processed % $ProgressInterval -eq 0) -or ($processed -eq $total))
  if ($logCheckpoint) {
    Write-Host ("[{0}/{1}] Last signed: {2}" -f $processed, $total, $f.FullName)
  }
  if ($ThrottleMilliseconds -gt 0) {
    Start-Sleep -Milliseconds $ThrottleMilliseconds
  }
}
$stopwatch.Stop()
Write-Output ("Signed {0} script(s) in {1:n2}s." -f $processed, $stopwatch.Elapsed.TotalSeconds)

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDYpfv9H/2BrGi3
# 0MwBmTlEqdu/5KsCsUUBa2BGGZtVxKCCAxYwggMSMIIB+qADAgECAhBTopZaMnO+
# kU9jH9AEvKuOMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEyMjIyNzU4WhcNMjUxMTI2MjIzNzU4WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAvUoTjvrrbjqgxIUrxox6lQOoecbRPGi9WiW7+jxoSeu+
# RS2VpT76TnkVY1B9r9IWMIEKHxqLBuqj0u1GeUoNYPqp7H/Ae8q0nd6C7e+2E9jo
# J3Ss4A0r/ySDOssVVns0DC7chVMOxm8fQ6lNAng4UXJBEWHVqfA9OGVskdX5qQ5k
# uBUwJijdJCIHI+/D4m3M5eUGv22i7O3kz2jUGR6b9O1SP4vXjI96gb6rMlXQltK2
# jGNmrm/1yV6BpiQ3D1DiEMLigPsLzFHmGpZADcGeDU40wXoMfcsgr5gsR6o3cdur
# siq64FTUJp39Ud+EtyFEYQI5k7cNaiW7iWBNk3M+xQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFD3W3E95+Ve8
# vtLX92iEbiCm3E2TMA0GCSqGSIb3DQEBCwUAA4IBAQCQS42mPlTkt/PnZIYP8+Tb
# 21qVZR5rTHqkar9gsJOY0iSOulb5bdSCbJxi13rvC9M1CrtE2Yf42vTp0Cz+Yc2+
# yFWL0nq9vZ+qp/7iHWhVXSDz6O5/M1zkYrHl2CYOxN/SLy4ECygC5jfKPIzP0PDf
# Wo+sWGzsHfix4oNhgOY2DCaoLnd22wqJgkP9T8OjbpVs6DWpBYK8AEuQYac/bKnd
# v2GABePvXPCF87CURahiN3GLYB8TMHbrXrnzNTlPNo6SEXF3Fk3776xOjMr6EaHF
# 71gCWtdHWpaA/b4hkH+jRuynDIO1IwxuxL+wuE1il+sgoESJlKvF2Hun1vfoFr8b
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBTopZaMnO+kU9jH9AEvKuOMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIBiG+2ADMClH
# s6Yi2OyfzhR1yY57aD5XUqXcEBcdbcrjMA0GCSqGSIb3DQEBAQUABIIBAF/25GWP
# QLqSXPC/a10siN2NaZQc5aNvDck34Nb3/waQO47h3eAkLnIf5JYrAN0xwRaHfiPg
# Lihy2kpg0BbHKNRpuVIvvf0oyAObAIJ6gUUkcQ1nQcnvO9TSS+vZMMkViuOQlwWx
# zb/TodJS9YARLQxx11PosH6WknksXtsLLPZCj9g1PXLiOrL3ExV6Dju7pXz/VAHc
# VL0MRZpaPHyxkPHNuq6wroC8RaHT7poyhf/fU+evmeT10myiQQM2jvetDUJe5ZnX
# 0jBZJCdM6JbaCL2YcZJ+Ywm/gvNXILYZ3mrAU2kyeha/RPIRAJjUa5a6HrlAXy5j
# ThRHgRu7EhZ/f2I=
# SIG # End signature block
