# Verify-Signatures.ps1
[CmdletBinding()]
param(
  [Parameter()][string]$SearchRoot = (Get-Location).Path,
  [Parameter()][string[]]$Include = @("*.ps1","*.psm1"),
  [Parameter()][string[]]$ExcludeDirs = @(".git",".github",".venv","node_modules")
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'
$files = Get-ChildItem -LiteralPath $SearchRoot -Recurse -File -Include $Include | Where-Object {
  $rel = $_.FullName.Substring($SearchRoot.Length).TrimStart('\','/')
  -not ($ExcludeDirs | ForEach-Object { $rel -like ("{0}\*" -f $_) })
}
$bad = @()
foreach ($f in $files) {
  $sig = Get-AuthenticodeSignature -LiteralPath $f.FullName
  if ($sig.Status -ne 'Valid') { $bad += [pscustomobject]@{ Path = $f.FullName; Status = $sig.Status } }
}
if ($bad.Count -gt 0) {
  $bad | Format-Table -AutoSize | Out-String | Write-Output
  throw "Signature check failed for $($bad.Count) file(s)."
}
Write-Output "All script signatures are VALID."

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDA5chJevy6MGSV
# tHJMuyIwbEkqLQdD7aRYKil20DYfiaCCAxYwggMSMIIB+qADAgECAhBTopZaMnO+
# kU9jH9AEvKuOMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEyMjIyNzU4WhcNMjUxMTI2MjIzNzU4WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAvUoTjvrrbjqgxIUrxox6lQOoecbRPGi9WiW7+jxoSeu+
# RS2VpT76TnkVY1B9r9IWMIEKHxqLBuqj0u1GeUoNYPqp7H/Ae8q0nd6C7e+2E9jo
# J3Ss4A0r/ySDOssVVns0DC7chVMOxm8fQ6lNAng4UXJBEWHVqfA9OGVskdX5qQ5k
# uBUwJijdJCIHI+/D4m3M5eUGv22i7O3kz2jUGR6b9O1SP4vXjI96gb6rMlXQltK2
# jGNmrm/1yV6BpiQ3D1DiEMLigPsLzFHmGpZADcGeDU40wXoMfcsgr5gsR6o3cdur
# siq64FTUJp39Ud+EtyFEYQI5k7cNaiW7iWBNk3M+xQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFD3W3E95+Ve8
# vtLX92iEbiCm3E2TMA0GCSqGSIb3DQEBCwUAA4IBAQCQS42mPlTkt/PnZIYP8+Tb
# 21qVZR5rTHqkar9gsJOY0iSOulb5bdSCbJxi13rvC9M1CrtE2Yf42vTp0Cz+Yc2+
# yFWL0nq9vZ+qp/7iHWhVXSDz6O5/M1zkYrHl2CYOxN/SLy4ECygC5jfKPIzP0PDf
# Wo+sWGzsHfix4oNhgOY2DCaoLnd22wqJgkP9T8OjbpVs6DWpBYK8AEuQYac/bKnd
# v2GABePvXPCF87CURahiN3GLYB8TMHbrXrnzNTlPNo6SEXF3Fk3776xOjMr6EaHF
# 71gCWtdHWpaA/b4hkH+jRuynDIO1IwxuxL+wuE1il+sgoESJlKvF2Hun1vfoFr8b
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBTopZaMnO+kU9jH9AEvKuOMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIIEZpCeYMGc2
# kHxmC59rnv7kFfu0+1EDOsevLQv84+74MA0GCSqGSIb3DQEBAQUABIIBABQbTMOG
# nVkLe+pKQFgu38dEczM6iObuU0Ek6XM4sNaEL2BUoOfjp0UXSFQ7TYGlSf7HkLPg
# 3BCTNnK9g+ykWx9ovUaZ4E1ZwLzuxHJwU1A39qG87MQcD5oczkXm/krxmrIkFU6F
# Dt9ilK7zXOyIU9Gp3hVZ9qo78xBKBKosN81UyTbIWvrmH8baFZDwEMM5cP2+mwb0
# ncMR5N+ML0jNxYWoDcPjwmFLtITU00Y50pERIcoZnhMrjoZRNjWExGBthhe9haBt
# Ivjrv8TpedoVPKOP58pnkY8Ia2OZCoVmHfzLZ0g/VEIM6IFrgwE+Gz4iaQOuIsHg
# XByv6oviSaLvY84=
# SIG # End signature block
