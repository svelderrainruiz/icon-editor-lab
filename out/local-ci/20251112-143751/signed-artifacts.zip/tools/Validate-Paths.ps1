# Validate-Paths.ps1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Test-PathSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter()][switch]$RequireAbsolute
    )
    if ($Path -match '[;&|`]' -or $Path -match '\.\.') { return $false }
    try {
        $rp = Resolve-Path -LiteralPath $Path -ErrorAction Stop
        if ($RequireAbsolute -and -not ($rp.Path -match '^(?:[A-Za-z]:[\\/]|/)')) { return $false }
        return $true
    } catch { return $false }
}

function Validate-PathSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter()][switch]$RequireAbsolute
    )
    if (-not (Test-PathSafe -Path $Path -RequireAbsolute:$RequireAbsolute)) {
        throw "Unsafe or invalid path: $Path"
    }
    return (Resolve-Path -LiteralPath $Path).Path
}

Export-ModuleMember -Function Test-PathSafe, Validate-PathSafe

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBRKRGFgRiwJrUW
# ser+RbKUtmM3v2Ar6IG3lNNJMXHBxaCCAxYwggMSMIIB+qADAgECAhBTopZaMnO+
# kU9jH9AEvKuOMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEyMjIyNzU4WhcNMjUxMTI2MjIzNzU4WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAvUoTjvrrbjqgxIUrxox6lQOoecbRPGi9WiW7+jxoSeu+
# RS2VpT76TnkVY1B9r9IWMIEKHxqLBuqj0u1GeUoNYPqp7H/Ae8q0nd6C7e+2E9jo
# J3Ss4A0r/ySDOssVVns0DC7chVMOxm8fQ6lNAng4UXJBEWHVqfA9OGVskdX5qQ5k
# uBUwJijdJCIHI+/D4m3M5eUGv22i7O3kz2jUGR6b9O1SP4vXjI96gb6rMlXQltK2
# jGNmrm/1yV6BpiQ3D1DiEMLigPsLzFHmGpZADcGeDU40wXoMfcsgr5gsR6o3cdur
# siq64FTUJp39Ud+EtyFEYQI5k7cNaiW7iWBNk3M+xQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFD3W3E95+Ve8
# vtLX92iEbiCm3E2TMA0GCSqGSIb3DQEBCwUAA4IBAQCQS42mPlTkt/PnZIYP8+Tb
# 21qVZR5rTHqkar9gsJOY0iSOulb5bdSCbJxi13rvC9M1CrtE2Yf42vTp0Cz+Yc2+
# yFWL0nq9vZ+qp/7iHWhVXSDz6O5/M1zkYrHl2CYOxN/SLy4ECygC5jfKPIzP0PDf
# Wo+sWGzsHfix4oNhgOY2DCaoLnd22wqJgkP9T8OjbpVs6DWpBYK8AEuQYac/bKnd
# v2GABePvXPCF87CURahiN3GLYB8TMHbrXrnzNTlPNo6SEXF3Fk3776xOjMr6EaHF
# 71gCWtdHWpaA/b4hkH+jRuynDIO1IwxuxL+wuE1il+sgoESJlKvF2Hun1vfoFr8b
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBTopZaMnO+kU9jH9AEvKuOMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEINpvsU+HHb6K
# gYnFC+DOD7Pi21ghNNfHTvYHF7x5UIBMMA0GCSqGSIb3DQEBAQUABIIBADCEGoM2
# iP2mpqG2jAjff3vp84KqG/llKtnValANJ0AFE7Sn3z64sXabf7tZpJkq8qT7AvIU
# mGoXTgUmA8CI+VPrSA7+Gf/cWfyTKAuF1foHtW3/Xv/RcnCKpXRb7IUM9Z2MaFN2
# Wut9crZ3hudmDgnYyab6r4O40sx+Ybd24te3UyBX3+L3eO0ECv52Jg/BHTM+9XGd
# c6RKyeDdCWwiVBL4B4cQgE6A8VGhnRhn2/lVvvDQSO7L5haGs6TlI4VWqc+jE70J
# RE/pQDrpeY1J0v/Lq0ORHvqCzartVBPq7JFAuOm5DzI0W1lZgSiOpgWZaRPpxaLA
# n7N1wU7+/YSPpfc=
# SIG # End signature block
