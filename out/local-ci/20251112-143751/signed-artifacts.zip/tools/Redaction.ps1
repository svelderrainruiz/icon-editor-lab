# Redaction.ps1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Write-LogSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Message,
        [Parameter()][ValidateSet('INFO','WARN','ERROR')][string]$Level = 'INFO'
    )
    # Redact common secret/token patterns (simple heuristic)
    $msg = $Message -replace '([A-Za-z0-9-_]{20,})','****' `
                    -replace '(?i)(secret|token|password)\s*[:=]\s*[^ \t\r\n]+','$1=****'
    $ts = (Get-Date).ToString('s')
    Write-Output "[$ts][$Level] $msg"
}
if ($ExecutionContext.SessionState.Module) {
    Export-ModuleMember -Function Write-LogSafe
}

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCB5QE8/zfwZTTR5
# g9if2C7NwESBApxi1XkQIcw6fBWi3aCCAxYwggMSMIIB+qADAgECAhBTopZaMnO+
# kU9jH9AEvKuOMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEyMjIyNzU4WhcNMjUxMTI2MjIzNzU4WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAvUoTjvrrbjqgxIUrxox6lQOoecbRPGi9WiW7+jxoSeu+
# RS2VpT76TnkVY1B9r9IWMIEKHxqLBuqj0u1GeUoNYPqp7H/Ae8q0nd6C7e+2E9jo
# J3Ss4A0r/ySDOssVVns0DC7chVMOxm8fQ6lNAng4UXJBEWHVqfA9OGVskdX5qQ5k
# uBUwJijdJCIHI+/D4m3M5eUGv22i7O3kz2jUGR6b9O1SP4vXjI96gb6rMlXQltK2
# jGNmrm/1yV6BpiQ3D1DiEMLigPsLzFHmGpZADcGeDU40wXoMfcsgr5gsR6o3cdur
# siq64FTUJp39Ud+EtyFEYQI5k7cNaiW7iWBNk3M+xQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFD3W3E95+Ve8
# vtLX92iEbiCm3E2TMA0GCSqGSIb3DQEBCwUAA4IBAQCQS42mPlTkt/PnZIYP8+Tb
# 21qVZR5rTHqkar9gsJOY0iSOulb5bdSCbJxi13rvC9M1CrtE2Yf42vTp0Cz+Yc2+
# yFWL0nq9vZ+qp/7iHWhVXSDz6O5/M1zkYrHl2CYOxN/SLy4ECygC5jfKPIzP0PDf
# Wo+sWGzsHfix4oNhgOY2DCaoLnd22wqJgkP9T8OjbpVs6DWpBYK8AEuQYac/bKnd
# v2GABePvXPCF87CURahiN3GLYB8TMHbrXrnzNTlPNo6SEXF3Fk3776xOjMr6EaHF
# 71gCWtdHWpaA/b4hkH+jRuynDIO1IwxuxL+wuE1il+sgoESJlKvF2Hun1vfoFr8b
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBTopZaMnO+kU9jH9AEvKuOMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIEfHLCIlw9Py
# EI3fUHQlFhw4tq7Q+oRZQIlIetQ/aFBMMA0GCSqGSIb3DQEBAQUABIIBAGhVvLEL
# DycwRfWZguZ7jwnNjKmFYFDXlbCgNJbEcOnX7pbcANXoUhLpblnhwHJbPNyaSVqR
# GyUH2Lqi/4GwQMnOL+kAmi0opD7IL04Ib51qyfZC0IWBM9sWIW0HXhMgkfcxZGjR
# kk6EJRFQGmgYrbM9J8tcBvGQ8dxQsGk75ZNPYEOdH5rHXEwVY8qIgChFqCVzGqTd
# tvSP7f9DUSPYtkWqxTly3BhibimF8jUgf5I3BaG82tzKfl1Wl5asiaEgOsgCkhs7
# o/DuqdiI4vQEIbfd6O4xgr9tQlcSXhkwswA25ibbetD/mnM9KXwdAndmo2SImlEM
# TnMwZzFkvWCOnpc=
# SIG # End signature block
