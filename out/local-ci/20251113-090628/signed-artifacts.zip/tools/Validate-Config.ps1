[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$ConfigPath,
  [Parameter()][string]$SchemaPath = (Join-Path $PSScriptRoot '..' 'configs' 'schema' 'vi-diff-heuristics.schema.json')
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'
. (Join-Path $PSScriptRoot 'Redaction.ps1')
$cfgContent = Get-Content -LiteralPath $ConfigPath -Raw
# Basic JSON validity check
$null = $cfgContent | ConvertFrom-Json -ErrorAction Stop
# Schema validation (if schema exists)
if (Test-Path -LiteralPath $SchemaPath -PathType Leaf) {
  $cfgContent | Test-Json -SchemaFile $SchemaPath -ErrorAction Stop | Out-Null
}
Write-Output "Config validated successfully:" (Resolve-Path -LiteralPath $ConfigPath).Path

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAtM1F8YzQ4xa9F
# 7QuDGJd4jTwMhZsuR+3nhXLiXLTUlKCCAxYwggMSMIIB+qADAgECAhAV3Lng6q7Y
# jkactr+VoxXSMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTY1NzUwWhcNMjUxMTI3MTcwNzUwWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEArtDuaupz7UEhYxOwmM/EQ0aJuyzCemjXBMziu4NhRo/F
# I0PPf0lckL+HvHFxHSTCPq09fu0EFKrv6DcSI8iOw/pkCFHHjF89L6W6Ecr3xnhi
# Wx8mIv7M8ASuLIWVyLReN+2YzWgkbMmOEAsKWZ0zyiKpxcK4X1STGSjLugjd3MSo
# rcl0za2FIG1ItIpoDkEyd/vRxteRgjBTtbzscfaK6zL1HiHWt8SAE6lAMeF88tcu
# LNG5jh/Ql0QGufuLGJ5H0vmuX5/sORaIPRt42lRwGyaN1DUQ+j8Kn/9Zyb54Pu86
# 9wJPIbNs8dmdc4rfNrpIt1msTdPJFYMZRWvB9Qh5VQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFILkkla4NTkI
# ZkfKUi2oBtW5FZPQMA0GCSqGSIb3DQEBCwUAA4IBAQAUfedQQYl4uA2iqs/wJom5
# TDoxnGe7M4sxc4pOwqqM867NgnN7vhT4YEEPojtbpXENbW/5WK1U+SpfQsPQTX7I
# +g0awtObvF/Yhbz52B2TKJzPrm4utYGrnUpVMxYqLbj70UYcTOu9+0Pf2t5bcLZg
# Hn/UEO0iejgo7BfgrBPveScXHAEKBVAYLe3Aeqt6a6M1xAF/zOIfelNATYs1g771
# BGnWSnDJieXaEVG0DaQ8Q5dGC7uHeD3u4BIusAcahG8K7ZOHvtg6t+LtbUse0E/z
# 6TMqWDv3zomJOXYJLt6rJ4rpgLiwDXUItQo9YjkVHkONKA0bvso/bGXN6njfKGJQ
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAV3Lng6q7Yjkactr+VoxXSMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPGNlwZgDGGO
# 4eoZqf6qFtcbYyZe5LvdTuTwGIaPVsX8MA0GCSqGSIb3DQEBAQUABIIBAJTkXJpa
# ED6wVaFkpcZlibrAGUS+741B5AaUVmXtV9xMuQJkvdUHAl8gCgUHCqIS5YH8tPF8
# t1PxwgKdqeJ0MlGcPuzZww+d4kqd9QEyKFoIQmZco6Im9dE53SxnMGrsIt/csyb5
# l93WsV75xIQHFbXfghvASZIdTmlMAZv4r2N2HV91FBxFCfzclKct6HLqENBhSZbh
# rWR3NhtIWD63K0px5qJIPGLBD9LBlGdk+UUl1ybMnuhE4u4IWOXP5XqJu4Qo5M5A
# 2okFdiIhFT1F/IygXqHKpPqsTNNbtU6wKsq7tchC+J8wtJAP2hsV4b56FTKMZKHy
# 1uv11Q+3GTKlfWQ=
# SIG # End signature block
