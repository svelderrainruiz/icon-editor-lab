# Hash-Artifacts.ps1
[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$Root,
  [Parameter()][string]$Output = 'checksums.sha256'
)

Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'

$rootAbs = Resolve-Path -LiteralPath $Root -ErrorAction Stop
$rootPath = $rootAbs.ProviderPath
$items = Get-ChildItem -LiteralPath $rootPath -Recurse -File -ErrorAction Stop
$lines = New-Object System.Collections.Generic.List[string]
foreach ($i in $items) {
  $h = Get-FileHash -LiteralPath $i.FullName -Algorithm SHA256
  $relativePath = [System.IO.Path]::GetRelativePath($rootPath, $i.FullName)
  try {
    $lines.Add(("{0}  {1}" -f $h.Hash.ToLower(), $relativePath))
  } catch {
    throw "Failed to format hash entry for '$($i.FullName)' relative '$relativePath': $($_.Exception.Message)"
  }
}
$pathOut = Join-Path $rootPath $Output
$lines | Set-Content -LiteralPath $pathOut -Encoding UTF8 -NoNewline:$false
Write-Output "Wrote checksums to $pathOut"

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCASG2cZB9SxQNBP
# DwVC9asjKlcJItPjhuWB1EHHmj/2laCCAxYwggMSMIIB+qADAgECAhAV3Lng6q7Y
# jkactr+VoxXSMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTY1NzUwWhcNMjUxMTI3MTcwNzUwWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEArtDuaupz7UEhYxOwmM/EQ0aJuyzCemjXBMziu4NhRo/F
# I0PPf0lckL+HvHFxHSTCPq09fu0EFKrv6DcSI8iOw/pkCFHHjF89L6W6Ecr3xnhi
# Wx8mIv7M8ASuLIWVyLReN+2YzWgkbMmOEAsKWZ0zyiKpxcK4X1STGSjLugjd3MSo
# rcl0za2FIG1ItIpoDkEyd/vRxteRgjBTtbzscfaK6zL1HiHWt8SAE6lAMeF88tcu
# LNG5jh/Ql0QGufuLGJ5H0vmuX5/sORaIPRt42lRwGyaN1DUQ+j8Kn/9Zyb54Pu86
# 9wJPIbNs8dmdc4rfNrpIt1msTdPJFYMZRWvB9Qh5VQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFILkkla4NTkI
# ZkfKUi2oBtW5FZPQMA0GCSqGSIb3DQEBCwUAA4IBAQAUfedQQYl4uA2iqs/wJom5
# TDoxnGe7M4sxc4pOwqqM867NgnN7vhT4YEEPojtbpXENbW/5WK1U+SpfQsPQTX7I
# +g0awtObvF/Yhbz52B2TKJzPrm4utYGrnUpVMxYqLbj70UYcTOu9+0Pf2t5bcLZg
# Hn/UEO0iejgo7BfgrBPveScXHAEKBVAYLe3Aeqt6a6M1xAF/zOIfelNATYs1g771
# BGnWSnDJieXaEVG0DaQ8Q5dGC7uHeD3u4BIusAcahG8K7ZOHvtg6t+LtbUse0E/z
# 6TMqWDv3zomJOXYJLt6rJ4rpgLiwDXUItQo9YjkVHkONKA0bvso/bGXN6njfKGJQ
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAV3Lng6q7Yjkactr+VoxXSMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIFwh7Ia6nNVg
# FzrXU1zSmX6Kq7zfAQC5vDsMmiqye02wMA0GCSqGSIb3DQEBAQUABIIBAExKBW27
# BD/TwGQeQi6TVe8PkvmyFmAEgsB9829OLwuEcIgfReRDB+blHTHWAseVpGc41yW7
# EW6Hn1JPHZMuOQz5iLWe9KkxEZzYVfQmWkfZlPCM+Ddn1Pl5pOO+oI8lWOcna3KQ
# /XBuyPRDMcdgAvwHZJcuGzgOKAKzqltx881Hj8JTSJ7yffluPnlKTcskTN0/v/zg
# DqNT1QySVhrEEDqcuTVaHld7LKiiBY2zCrUo2yCNZfCSYlwYGMzQlVun9PWzaaWz
# e4qU34VLSnYXJ2KBgYl+QownSjfcGlCvWThZmu4gtN4nuLEnXLzUhfCPRmeJa8+Z
# EhvxoTPJsbYUT1Q=
# SIG # End signature block
