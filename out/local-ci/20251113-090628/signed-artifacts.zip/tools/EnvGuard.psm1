# EnvGuard.psm1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Get-EnvSnapshot {
    [CmdletBinding()]
    param([string[]]$AllowList = @('PATH','TEMP','TMP','HOME','USERPROFILE'))
    $snap = @{}
    foreach ($name in [Environment]::GetEnvironmentVariables().Keys) {
        if ($AllowList -contains $name) { $snap[$name] = [Environment]::GetEnvironmentVariable($name,'Process') }
    }
    return $snap
}

function Set-EnvFromSnapshot {
    [CmdletBinding()]
    param([Parameter(Mandatory)][hashtable]$Snapshot)
    foreach ($k in $Snapshot.Keys) {
        [Environment]::SetEnvironmentVariable($k, [string]$Snapshot[$k], 'Process')
    }
}

Export-ModuleMember -Function Get-EnvSnapshot, Set-EnvFromSnapshot

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAzwwfWBljXiDkz
# 9AHE9bg618B2oMEor3Mbt2BkcXsxKKCCAxYwggMSMIIB+qADAgECAhAV3Lng6q7Y
# jkactr+VoxXSMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTY1NzUwWhcNMjUxMTI3MTcwNzUwWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEArtDuaupz7UEhYxOwmM/EQ0aJuyzCemjXBMziu4NhRo/F
# I0PPf0lckL+HvHFxHSTCPq09fu0EFKrv6DcSI8iOw/pkCFHHjF89L6W6Ecr3xnhi
# Wx8mIv7M8ASuLIWVyLReN+2YzWgkbMmOEAsKWZ0zyiKpxcK4X1STGSjLugjd3MSo
# rcl0za2FIG1ItIpoDkEyd/vRxteRgjBTtbzscfaK6zL1HiHWt8SAE6lAMeF88tcu
# LNG5jh/Ql0QGufuLGJ5H0vmuX5/sORaIPRt42lRwGyaN1DUQ+j8Kn/9Zyb54Pu86
# 9wJPIbNs8dmdc4rfNrpIt1msTdPJFYMZRWvB9Qh5VQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFILkkla4NTkI
# ZkfKUi2oBtW5FZPQMA0GCSqGSIb3DQEBCwUAA4IBAQAUfedQQYl4uA2iqs/wJom5
# TDoxnGe7M4sxc4pOwqqM867NgnN7vhT4YEEPojtbpXENbW/5WK1U+SpfQsPQTX7I
# +g0awtObvF/Yhbz52B2TKJzPrm4utYGrnUpVMxYqLbj70UYcTOu9+0Pf2t5bcLZg
# Hn/UEO0iejgo7BfgrBPveScXHAEKBVAYLe3Aeqt6a6M1xAF/zOIfelNATYs1g771
# BGnWSnDJieXaEVG0DaQ8Q5dGC7uHeD3u4BIusAcahG8K7ZOHvtg6t+LtbUse0E/z
# 6TMqWDv3zomJOXYJLt6rJ4rpgLiwDXUItQo9YjkVHkONKA0bvso/bGXN6njfKGJQ
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAV3Lng6q7Yjkactr+VoxXSMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIJlQaYHytxsd
# hJ21/Xd1OOTWhUd4iNiRCRC/DDWxp9vgMA0GCSqGSIb3DQEBAQUABIIBAB72f83d
# aJ7+U7yk5sfWTRFsa7inOFe/YwKld/RvAkcnUXBEcs8hCB+ozULtMpx4Hj5swXTM
# SWXKAdRybNp20tek2mk8BZrqtp4FCqCsbhyiDzKEgw3tA+VQrF0p1F750KoZCnt3
# sXid9CQvQUEY66NlHx7X58uwaj1wXY5llHQNNvJGqmjorSf/iYKfjNsPeiCxUstf
# QLxABdHB7kWqnVMD1ZY8QUqY6qcynw7LsUWGGZc0yTJnu2iGqj3LFAWKQcvx1K5S
# gAH6ZByAEM+rykzas3giCq8fiK/1wrUGV8vW8NrB4NkHa0FbiWtmZoitwSKLBNDV
# 3X+L3pUabuUkqgs=
# SIG # End signature block
