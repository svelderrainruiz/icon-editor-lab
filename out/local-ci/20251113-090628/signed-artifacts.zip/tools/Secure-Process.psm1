# Secure-Process.psm1
Set-StrictMode -Version Latest
. (Join-Path $PSScriptRoot 'Validate-Paths.ps1')
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Invoke-ProcessSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$FilePath,
        [Parameter()][string[]]$ArgumentList = @(),
        [Parameter()][int]$TimeoutSec = 600,
        [Parameter()][string]$WorkingDirectory = (Get-Location).Path
    )
    if (-not (Test-Path -LiteralPath $FilePath -PathType Leaf)) { throw "FilePath not found: $FilePath" }
    $psi = [System.Diagnostics.ProcessStartInfo]::new()
    $psi.FileName = $FilePath
    $psi.WorkingDirectory = (Validate-PathSafe -Path $WorkingDirectory)
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.UseShellExecute = $false
    foreach ($a in $ArgumentList) { $null = $psi.ArgumentList.Add($a) }

    $p = [System.Diagnostics.Process]::new()
    $p.StartInfo = $psi
    if (-not $p.Start()) { throw "Failed to start process: $FilePath" }
    try {
        if (-not $p.WaitForExit($TimeoutSec * 1000)) {
            try { $p.Kill($true) } catch {}
            throw "Process timed out after $TimeoutSec s: $FilePath"
        }
        $stdout = $p.StandardOutput.ReadToEnd()
        $stderr = $p.StandardError.ReadToEnd()
        return [pscustomobject]@{
            ExitCode = $p.ExitCode
            StdOut = $stdout
            StdErr = $stderr
        }
    } finally {
        if (-not $p.HasExited) { try { $p.Kill($true) } catch {} }
        $p.Dispose()
    }
}
Export-ModuleMember -Function Invoke-ProcessSafe

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDLM/hZ77J6ko3k
# J1T1SnSI3Zjg9T8EF5sOyyHIvgXLgqCCAxYwggMSMIIB+qADAgECAhAV3Lng6q7Y
# jkactr+VoxXSMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTY1NzUwWhcNMjUxMTI3MTcwNzUwWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEArtDuaupz7UEhYxOwmM/EQ0aJuyzCemjXBMziu4NhRo/F
# I0PPf0lckL+HvHFxHSTCPq09fu0EFKrv6DcSI8iOw/pkCFHHjF89L6W6Ecr3xnhi
# Wx8mIv7M8ASuLIWVyLReN+2YzWgkbMmOEAsKWZ0zyiKpxcK4X1STGSjLugjd3MSo
# rcl0za2FIG1ItIpoDkEyd/vRxteRgjBTtbzscfaK6zL1HiHWt8SAE6lAMeF88tcu
# LNG5jh/Ql0QGufuLGJ5H0vmuX5/sORaIPRt42lRwGyaN1DUQ+j8Kn/9Zyb54Pu86
# 9wJPIbNs8dmdc4rfNrpIt1msTdPJFYMZRWvB9Qh5VQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFILkkla4NTkI
# ZkfKUi2oBtW5FZPQMA0GCSqGSIb3DQEBCwUAA4IBAQAUfedQQYl4uA2iqs/wJom5
# TDoxnGe7M4sxc4pOwqqM867NgnN7vhT4YEEPojtbpXENbW/5WK1U+SpfQsPQTX7I
# +g0awtObvF/Yhbz52B2TKJzPrm4utYGrnUpVMxYqLbj70UYcTOu9+0Pf2t5bcLZg
# Hn/UEO0iejgo7BfgrBPveScXHAEKBVAYLe3Aeqt6a6M1xAF/zOIfelNATYs1g771
# BGnWSnDJieXaEVG0DaQ8Q5dGC7uHeD3u4BIusAcahG8K7ZOHvtg6t+LtbUse0E/z
# 6TMqWDv3zomJOXYJLt6rJ4rpgLiwDXUItQo9YjkVHkONKA0bvso/bGXN6njfKGJQ
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAV3Lng6q7Yjkactr+VoxXSMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPEK5pYr/oiP
# 6zXDh72ZtLHO5VLyj1aDMXhTjDbbSs4wMA0GCSqGSIb3DQEBAQUABIIBAEf0cG91
# fB1ejhN6qb2ZqYvVPE9X7a/Ii/m1MJgJgjZu7BLTS36GWxuYKtkm25eZ0FJNN/HB
# 8l9ryzoT967f6ZdGxAIfS7rcOWH4xCJJ2tMvgnYBJv8wM+bBqTthZwtxuIB8VOzy
# HB+esOWBHIbUQtv9ONkgABPp9TH/uDmOL00aCiNhDrVE3D9v6+KQ8+xkrb6E+E5r
# jUI2j8ObTLJTpb/rQgR72dehvRxJd2Uq7Q58ZPr99WloQoLZIVYBbZaIE4SgqUcb
# 7a1URgPp37okFM2uHCFSm6HuagFGQ7Jydbt7eSfIHVyZhg1z80SMXalEeGe+SgjT
# rWWykWEzhMYg7bw=
# SIG # End signature block
