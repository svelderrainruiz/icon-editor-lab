#Requires -Version 7.0
<#
.SYNOPSIS
  Consistent entry point for running the repository's Pester suite.

.DESCRIPTION
  Loads tests/Pester.runsettings.psd1, applies optional tag/exclude filters,
  and runs Invoke-Pester. When -CI is specified, writes JUnit output under
  out/test-results/pester.xml (creating the folder if needed).

.PARAMETER Tag
  Only run tests tagged with any of the specified values.

.PARAMETER ExcludeTag
  Skip tests tagged with any of the specified values.

.PARAMETER CI
  Enables JUnit output to out/test-results/pester.xml.
#>

[CmdletBinding()]
param(
  [string[]]$Tag,
  [string[]]$ExcludeTag,
  [switch]$CI
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repoRoot = Resolve-Path (Join-Path $PSScriptRoot '..')
$configPath = Join-Path $repoRoot 'tests' 'Pester.runsettings.psd1'
if (-not (Test-Path $configPath)) {
  throw "Pester configuration not found: $configPath"
}

$config = Import-PowerShellDataFile -LiteralPath $configPath

# Normalize relative paths based on repo root
$config.Run.Path = @(
  $config.Run.Path | ForEach-Object {
    (Resolve-Path (Join-Path $repoRoot $_)).ProviderPath
  }
)
$resolvedResultPath = Resolve-Path (Join-Path $repoRoot $config.TestResult.OutputPath) -ErrorAction SilentlyContinue
if ($resolvedResultPath) {
  $config.TestResult.OutputPath = $resolvedResultPath.ProviderPath
} else {
  $config.TestResult.OutputPath = Join-Path $repoRoot 'out/test-results/pester.xml'
}
if (-not $config.TestResult.OutputPath) {
  $config.TestResult.OutputPath = Join-Path $repoRoot 'out/test-results/pester.xml'
}

if ($Tag) {
  $config.Filter.Tag = @($Tag)
}
if ($ExcludeTag) {
  $config.Filter.ExcludeTag = @($ExcludeTag)
}

if ($CI) {
  $resultsPath = $config.TestResult.OutputPath
  $resultsDir = Split-Path $resultsPath -Parent
  if (-not (Test-Path $resultsDir)) { New-Item -ItemType Directory -Path $resultsDir -Force | Out-Null }
  $config.TestResult.Enabled = $true
  Write-Host "CI mode: writing Pester results to $resultsPath"
} else {
  $config.TestResult.Enabled = $false
}

Write-Host "Invoking Pester with tags: $($config.Filter.Tag -join ', ')" -ForegroundColor Cyan
Invoke-Pester -Configuration $config

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDYd2uoPAkTXPJb
# bn+j5BoktSlFrWLc2tx3vJ8l5hj/eaCCAxYwggMSMIIB+qADAgECAhAV3Lng6q7Y
# jkactr+VoxXSMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTY1NzUwWhcNMjUxMTI3MTcwNzUwWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEArtDuaupz7UEhYxOwmM/EQ0aJuyzCemjXBMziu4NhRo/F
# I0PPf0lckL+HvHFxHSTCPq09fu0EFKrv6DcSI8iOw/pkCFHHjF89L6W6Ecr3xnhi
# Wx8mIv7M8ASuLIWVyLReN+2YzWgkbMmOEAsKWZ0zyiKpxcK4X1STGSjLugjd3MSo
# rcl0za2FIG1ItIpoDkEyd/vRxteRgjBTtbzscfaK6zL1HiHWt8SAE6lAMeF88tcu
# LNG5jh/Ql0QGufuLGJ5H0vmuX5/sORaIPRt42lRwGyaN1DUQ+j8Kn/9Zyb54Pu86
# 9wJPIbNs8dmdc4rfNrpIt1msTdPJFYMZRWvB9Qh5VQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFILkkla4NTkI
# ZkfKUi2oBtW5FZPQMA0GCSqGSIb3DQEBCwUAA4IBAQAUfedQQYl4uA2iqs/wJom5
# TDoxnGe7M4sxc4pOwqqM867NgnN7vhT4YEEPojtbpXENbW/5WK1U+SpfQsPQTX7I
# +g0awtObvF/Yhbz52B2TKJzPrm4utYGrnUpVMxYqLbj70UYcTOu9+0Pf2t5bcLZg
# Hn/UEO0iejgo7BfgrBPveScXHAEKBVAYLe3Aeqt6a6M1xAF/zOIfelNATYs1g771
# BGnWSnDJieXaEVG0DaQ8Q5dGC7uHeD3u4BIusAcahG8K7ZOHvtg6t+LtbUse0E/z
# 6TMqWDv3zomJOXYJLt6rJ4rpgLiwDXUItQo9YjkVHkONKA0bvso/bGXN6njfKGJQ
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAV3Lng6q7Yjkactr+VoxXSMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEII11SC6wt7Xz
# Nju6w2mLIcqzI70/iCgkEho6gi7yzw2NMA0GCSqGSIb3DQEBAQUABIIBABA6uqfW
# rH3i3Ro/HqxfNsxHg8NWAfShoR8A5sBTjgRI/zV79YbOTmS5EWi3cemDcHJCXJxK
# QWAHO+daTBe6KjqScJInQ0s3DlyEM/p1vABf1FVxsbg0ZBp95FqjfWj01/FOEQ5T
# Me8WJ6zO5U2CF2wHfgHnkPDZJ2Qydpl/21uc0xLaIZFYHMUIM2MJh2m+VH5asTth
# kfPvCUMQ/vwLUswE4uHedy8R9XiI1kddegQ7aTc6DPmcCeD/0rYH29Nm8kTTq5XZ
# Qe+pM2WeBIQWYhWhWZl61WLVhe2tikrmci+FPiY8vKXAUreq36SDUlAPa2J4V/tB
# 4yFJO0e/KSFh694=
# SIG # End signature block
