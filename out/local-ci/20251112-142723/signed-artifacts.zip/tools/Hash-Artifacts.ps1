# Hash-Artifacts.ps1
[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$Root,
  [Parameter()][string]$Output = 'checksums.sha256'
)

Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'

$rootAbs = Resolve-Path -LiteralPath $Root -ErrorAction Stop
$rootPath = $rootAbs.ProviderPath
$items = Get-ChildItem -LiteralPath $rootPath -Recurse -File -ErrorAction Stop
$lines = New-Object System.Collections.Generic.List[string]
foreach ($i in $items) {
  $h = Get-FileHash -LiteralPath $i.FullName -Algorithm SHA256
  $relativePath = [System.IO.Path]::GetRelativePath($rootPath, $i.FullName)
  try {
    $lines.Add(("{0}  {1}" -f $h.Hash.ToLower(), $relativePath))
  } catch {
    throw "Failed to format hash entry for '$($i.FullName)' relative '$relativePath': $($_.Exception.Message)"
  }
}
$pathOut = Join-Path $rootPath $Output
$lines | Set-Content -LiteralPath $pathOut -Encoding UTF8 -NoNewline:$false
Write-Output "Wrote checksums to $pathOut"

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCASG2cZB9SxQNBP
# DwVC9asjKlcJItPjhuWB1EHHmj/2laCCAxYwggMSMIIB+qADAgECAhBPLBjTDRmm
# pkLX+JLBwcDgMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEyMjIxNzMxWhcNMjUxMTI2MjIyNzMxWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAnl6jRS/MJpiVVJXAMQ79HJbDhC6OR5Vms/xaWTmBJ23n
# QsjRG8TCzQwviA5N+HAxVpufE/nDJmd8hE7FOHKmY9CWu4s1sQXS6wtor/kTzIT/
# VJ7WhmqSuGGUDx1cNteJoDjd4seB0MJ4dlamEKAl/gqJa3o+F/TKKq1/9Ef4GGtA
# dPCNd2RYlPDNelUH7Y2NctOKsKd9xNkrgDUcDRZe83500z7MdUrpqoS9HZhphfEU
# Q85u7qQX6juV4MZDSGoIhgmWkN5LYIVbI15h8Ky0uvDZbYt/rz4iapoFnkBNJAqK
# GclnZto5A7PuCf19gEniQEUFJl+e9TceWB7h8F/oFQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFLpo2LEvdDQr
# PcW3fqlAmZmHQ0TAMA0GCSqGSIb3DQEBCwUAA4IBAQCX418Ml5zWvtE9u/+3gScc
# y6TDK6Z7nVCLR0sjP4yNy21zGYNIX3m86hYPrN9GqWuTlry46YfISyINkwkKCN76
# cLBdyHRrBwycmxvJmAFGbRUOexVm/RtzYmLvXN5l1+ryMK4pBP6EANSfpwPV8PaU
# cO9c2t2/pAlLeZgrEKbggGX7BaWkjY+ZupJYBSbjCXl4UT5VdDNiPb7ouN/+9soA
# zHSk1ovOBfPeAS8T4cxmE5UXGxR5HNqHyhjgxkN0PipKduH3kB3yAe6Ms0iQxNcW
# 7AdGVBqJi0xiicPKGBwbYPgYtY+5V18Oj3RQyV7AjFAjSlNgnovtJLBi/WA7wMV+
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBPLBjTDRmmpkLX+JLBwcDgMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIFwh7Ia6nNVg
# FzrXU1zSmX6Kq7zfAQC5vDsMmiqye02wMA0GCSqGSIb3DQEBAQUABIIBAFNBZYQ8
# Rbj0EVfb7xP/eDBv9S6Gy38laarFvIqWWmqTKtcELz24WtrcU3iEC++xm8L904R0
# 7d6jejdcbfZvb9x6vwndoL3Jp78jt9lklXLWmT+Mn/7NY+eBCzjTgZ50UMa+sWSs
# wnGI8WrOifjzwy60sZO6iu1jAT8KP4K/V6Ia5e5lNf5TtnIDZyzSkRvPFt56oPbY
# UVn87ypmjm9JJ7T4w8ynhqadgGHAAVkWcQOeb8Cd1TqX/LC7UYa1zPxswBQwkNSY
# WQNzKX7GkymPOs1aosY61F288y72IMnsVUdIshWHrz9IATLR4npagXZ6gwwSLmXY
# zb0ONA7wve9jxLA=
# SIG # End signature block
