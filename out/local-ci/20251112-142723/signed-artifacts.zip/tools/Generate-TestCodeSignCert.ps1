#Requires -Version 7.0
<#
.SYNOPSIS
  Generate a temporary, self-signed code-signing certificate for local/fork testing.

.DESCRIPTION
  - Creates a self-signed "Code Signing" cert in the current user's store
  - Exports a PFX with a strong random password
  - Emits a Base64 blob for use as an environment secret
  - Optionally writes secrets to secrets.json and/or .env
  - Prints cleanup commands to remove the cert and files

.NOTES
  For TESTING ONLY. Do not use for production/release signing.
#>

[CmdletBinding()]
param(
  [string]$Subject = 'CN=CI Test Signing',
  [int]$DaysValid = 14,
  [string]$OutDir = (Join-Path -Path $PWD -ChildPath 'out\test-codesign'),
  [switch]$EmitJson,
  [switch]$EmitEnv,
  [switch]$Quiet
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

if (-not $IsWindows) {
  throw "This script requires Windows (uses New-SelfSignedCertificate)."
}

# Ensure output folder
$null = New-Item -ItemType Directory -Force -Path $OutDir

# Create self-signed code-signing cert (exportable key)
$notAfter = (Get-Date).AddDays([Math]::Max(1, $DaysValid))
$cert = New-SelfSignedCertificate `
  -Subject $Subject `
  -Type CodeSigningCert `
  -CertStoreLocation 'Cert:\CurrentUser\My' `
  -NotAfter $notAfter `
  -KeyExportPolicy Exportable `
  -KeyAlgorithm RSA -KeyLength 3072 `
  -HashAlgorithm SHA256

if (-not $cert) { throw "Failed to create self-signed code-signing certificate." }

# Generate a strong random password (Base64 of 48 random bytes)
$pwdPlain = [Convert]::ToBase64String([System.Security.Cryptography.RandomNumberGenerator]::GetBytes(48))
$pwdSecure = ConvertTo-SecureString -String $pwdPlain -AsPlainText -Force

# Export to PFX
$pfxName = "test-codesign-$($cert.Thumbprint.Substring(0,8)).pfx"
$pfxPath = Join-Path $OutDir $pfxName
Export-PfxCertificate -Cert $cert -FilePath $pfxPath -Password $pwdSecure | Out-Null

# Base64-encode the PFX for easy use as a secret
$b64Path = Join-Path $OutDir "test-codesign.pfx.b64"
[IO.File]::WriteAllBytes($b64Path, [Convert]::FromBase64String(([Convert]::ToBase64String([IO.File]::ReadAllBytes($pfxPath)))))
# Re-read as trimmed string (ensures newline at end when written below)
$pfxB64 = Get-Content -LiteralPath $b64Path -Raw

# Write convenient plain-text files for quick 'gh secret set' usage
$pwdPath = Join-Path $OutDir "WIN_CODESIGN_PFX_PASSWORD.txt"
$b64TxtPath = Join-Path $OutDir "WIN_CODESIGN_PFX_B64.txt"
Set-Content -LiteralPath $pwdPath -Value $pwdPlain -Encoding UTF8 -NoNewline:$false
Set-Content -LiteralPath $b64TxtPath -Value $pfxB64 -Encoding UTF8 -NoNewline:$false

# Optional secret bundles
if ($EmitJson) {
  $jsonPath = Join-Path $OutDir "secrets.json"
  @{ WIN_CODESIGN_PFX_B64 = $pfxB64; WIN_CODESIGN_PFX_PASSWORD = $pwdPlain } |
    ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $jsonPath -Encoding UTF8
}

if ($EmitEnv) {
  $envPath = Join-Path $OutDir "secrets.env"
  @(
    "WIN_CODESIGN_PFX_B64=$pfxB64"
    "WIN_CODESIGN_PFX_PASSWORD=$pwdPlain"
  ) | Set-Content -LiteralPath $envPath -Encoding UTF8
}

if (-not $Quiet) {
  Write-Host ""
  Write-Host "✅ Generated TEST code-signing certificate" -ForegroundColor Green
  Write-Host "  Subject        : $($cert.Subject)"
  Write-Host "  Thumbprint     : $($cert.Thumbprint)"
  Write-Host "  Valid Until    : $($cert.NotAfter.ToString('u'))"
  Write-Host "  PFX            : $pfxPath"
  Write-Host "  B64 (file)     : $b64TxtPath"
  Write-Host "  Password (file): $pwdPath"
  if ($EmitJson) { Write-Host "  JSON           : $jsonPath" }
  if ($EmitEnv)  { Write-Host "  .env           : $envPath" }

  Write-Host ""
  Write-Host "🔐 Secret names to use (match the hardened CI):"
  Write-Host "  - WIN_CODESIGN_PFX_B64"
  Write-Host "  - WIN_CODESIGN_PFX_PASSWORD"

  Write-Host ""
  Write-Host "📦 Examples (run from repo root) — set environment secrets in your fork:"
  Write-Host "  # codesign-dev environment"
  Write-Host "  gh secret set -e codesign-dev WIN_CODESIGN_PFX_B64       -b \"$(Get-Content '$b64TxtPath' -Raw)\""
  Write-Host "  gh secret set -e codesign-dev WIN_CODESIGN_PFX_PASSWORD  -b \"$(Get-Content '$pwdPath'  -Raw)\""
  Write-Host ""
  Write-Host "  # codesign-prod environment (in your fork only, for end-to-end testing)"
  Write-Host "  gh secret set -e codesign-prod WIN_CODESIGN_PFX_B64      -b \"$(Get-Content '$b64TxtPath' -Raw)\""
  Write-Host "  gh secret set -e codesign-prod WIN_CODESIGN_PFX_PASSWORD -b \"$(Get-Content '$pwdPath'  -Raw)\""

  Write-Host ""
  Write-Host "🧹 Cleanup (remove the TEST cert and files when done):"
  Write-Host "  # Remove cert from CurrentUser store"
  Write-Host "  certutil -user -delstore My $($cert.Thumbprint)"
  Write-Host "  # Or (PowerShell): Remove-Item -LiteralPath Cert:\\CurrentUser\\My\\$($cert.Thumbprint) -Force"
  Write-Host "  # Remove files"
  Write-Host "  Remove-Item -LiteralPath '$pfxPath','${b64TxtPath}','${pwdPath}' -Force"
  if ($EmitJson) { Write-Host "  Remove-Item -LiteralPath '$jsonPath' -Force" }
  if ($EmitEnv)  { Write-Host "  Remove-Item -LiteralPath '$envPath'  -Force" }
  Write-Host ""
  Write-Warning "This certificate is for local/test signing ONLY. Do not use it for releases."
}

# Return a small object for programmatic use
[pscustomobject]@{
  Subject   = $cert.Subject
  Thumbprint= $cert.Thumbprint
  PfxPath   = $pfxPath
  PfxBase64 = $pfxB64
  Password  = $pwdPlain
  OutDir    = $OutDir
}


# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBnPlLEdh9CurFz
# Kde54+NXx4R3j31bMpNV4kK0lo5xrqCCAxYwggMSMIIB+qADAgECAhBPLBjTDRmm
# pkLX+JLBwcDgMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEyMjIxNzMxWhcNMjUxMTI2MjIyNzMxWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAnl6jRS/MJpiVVJXAMQ79HJbDhC6OR5Vms/xaWTmBJ23n
# QsjRG8TCzQwviA5N+HAxVpufE/nDJmd8hE7FOHKmY9CWu4s1sQXS6wtor/kTzIT/
# VJ7WhmqSuGGUDx1cNteJoDjd4seB0MJ4dlamEKAl/gqJa3o+F/TKKq1/9Ef4GGtA
# dPCNd2RYlPDNelUH7Y2NctOKsKd9xNkrgDUcDRZe83500z7MdUrpqoS9HZhphfEU
# Q85u7qQX6juV4MZDSGoIhgmWkN5LYIVbI15h8Ky0uvDZbYt/rz4iapoFnkBNJAqK
# GclnZto5A7PuCf19gEniQEUFJl+e9TceWB7h8F/oFQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFLpo2LEvdDQr
# PcW3fqlAmZmHQ0TAMA0GCSqGSIb3DQEBCwUAA4IBAQCX418Ml5zWvtE9u/+3gScc
# y6TDK6Z7nVCLR0sjP4yNy21zGYNIX3m86hYPrN9GqWuTlry46YfISyINkwkKCN76
# cLBdyHRrBwycmxvJmAFGbRUOexVm/RtzYmLvXN5l1+ryMK4pBP6EANSfpwPV8PaU
# cO9c2t2/pAlLeZgrEKbggGX7BaWkjY+ZupJYBSbjCXl4UT5VdDNiPb7ouN/+9soA
# zHSk1ovOBfPeAS8T4cxmE5UXGxR5HNqHyhjgxkN0PipKduH3kB3yAe6Ms0iQxNcW
# 7AdGVBqJi0xiicPKGBwbYPgYtY+5V18Oj3RQyV7AjFAjSlNgnovtJLBi/WA7wMV+
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBPLBjTDRmmpkLX+JLBwcDgMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIC+gJntA56/z
# FhLepV+JpKj7iU29+njbZ1vV8ZkWyxCDMA0GCSqGSIb3DQEBAQUABIIBAFbeL7Ts
# KvZ+zXc9G0XJ+xsuMTa/EJwRAA2cFw+7Lmfdvc9GWnMNTApfgbP9wlCoyVecVm+A
# 8l0HgG9MyIwSx7vKGBa0CBzvD5q5cT0y6C61ipienQa9kmIf+vsWApvHrkRDfoaG
# P7hlfOqGYjwHU5HR6R97SwJ+qJvrVbeNBv71DHMRXEP8vyvGNMkp8gNgXGkucu4j
# Lzb1drkS+R8oeOiaVCt5U6H0fVO4AGlj0t9zQ8QsQyD3JzYUJrrFUaysxxkuZyZn
# Udh3KZ2wh/BiX/heCCZ/mwY0FT+Jm3kZhKRqQfbeipzliCiqHY4k35vCnylzVjr5
# feYIDu7jiyWe1Zw=
# SIG # End signature block
