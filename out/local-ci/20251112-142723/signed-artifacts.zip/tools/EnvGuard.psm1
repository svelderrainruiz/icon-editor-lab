# EnvGuard.psm1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Get-EnvSnapshot {
    [CmdletBinding()]
    param([string[]]$AllowList = @('PATH','TEMP','TMP','HOME','USERPROFILE'))
    $snap = @{}
    foreach ($name in [Environment]::GetEnvironmentVariables().Keys) {
        if ($AllowList -contains $name) { $snap[$name] = [Environment]::GetEnvironmentVariable($name,'Process') }
    }
    return $snap
}

function Set-EnvFromSnapshot {
    [CmdletBinding()]
    param([Parameter(Mandatory)][hashtable]$Snapshot)
    foreach ($k in $Snapshot.Keys) {
        [Environment]::SetEnvironmentVariable($k, [string]$Snapshot[$k], 'Process')
    }
}

Export-ModuleMember -Function Get-EnvSnapshot, Set-EnvFromSnapshot

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAzwwfWBljXiDkz
# 9AHE9bg618B2oMEor3Mbt2BkcXsxKKCCAxYwggMSMIIB+qADAgECAhBPLBjTDRmm
# pkLX+JLBwcDgMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEyMjIxNzMxWhcNMjUxMTI2MjIyNzMxWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAnl6jRS/MJpiVVJXAMQ79HJbDhC6OR5Vms/xaWTmBJ23n
# QsjRG8TCzQwviA5N+HAxVpufE/nDJmd8hE7FOHKmY9CWu4s1sQXS6wtor/kTzIT/
# VJ7WhmqSuGGUDx1cNteJoDjd4seB0MJ4dlamEKAl/gqJa3o+F/TKKq1/9Ef4GGtA
# dPCNd2RYlPDNelUH7Y2NctOKsKd9xNkrgDUcDRZe83500z7MdUrpqoS9HZhphfEU
# Q85u7qQX6juV4MZDSGoIhgmWkN5LYIVbI15h8Ky0uvDZbYt/rz4iapoFnkBNJAqK
# GclnZto5A7PuCf19gEniQEUFJl+e9TceWB7h8F/oFQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFLpo2LEvdDQr
# PcW3fqlAmZmHQ0TAMA0GCSqGSIb3DQEBCwUAA4IBAQCX418Ml5zWvtE9u/+3gScc
# y6TDK6Z7nVCLR0sjP4yNy21zGYNIX3m86hYPrN9GqWuTlry46YfISyINkwkKCN76
# cLBdyHRrBwycmxvJmAFGbRUOexVm/RtzYmLvXN5l1+ryMK4pBP6EANSfpwPV8PaU
# cO9c2t2/pAlLeZgrEKbggGX7BaWkjY+ZupJYBSbjCXl4UT5VdDNiPb7ouN/+9soA
# zHSk1ovOBfPeAS8T4cxmE5UXGxR5HNqHyhjgxkN0PipKduH3kB3yAe6Ms0iQxNcW
# 7AdGVBqJi0xiicPKGBwbYPgYtY+5V18Oj3RQyV7AjFAjSlNgnovtJLBi/WA7wMV+
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBPLBjTDRmmpkLX+JLBwcDgMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIJlQaYHytxsd
# hJ21/Xd1OOTWhUd4iNiRCRC/DDWxp9vgMA0GCSqGSIb3DQEBAQUABIIBAI9sgxik
# 3qcdBZE2RQSX9eACC72xIkQKN37oTlX9ckHwOWE3IHYSxcQWQXrHyEWoY9bPPcKt
# Tmsntv+adVEjpydc4oYqQ0YEpAHGOk+6dDhOMtq2sKfhB4WG3dV4C7KrGftroKk4
# Ws89grj7s/4U1bhlRdAsMttzEfN9mFknQWQfE8I3vWlUauYlXpaAmjfDzsl9ZbjC
# nGUp8Js6mL+QwJvGOdo4N8XpB8D0fT5CuENm/jk0CuxXgrEyNj/bFsEvfIwOWQRu
# OhI6IpNdfXrNEb7B2QZKBWmroDIVCNr182XPglo4kg863ZOqn7Kmu6khWJJUmzpv
# 8gC6XfkKFSHnog8=
# SIG # End signature block
