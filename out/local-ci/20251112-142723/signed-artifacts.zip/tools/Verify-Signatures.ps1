# Verify-Signatures.ps1
[CmdletBinding()]
param(
  [Parameter()][string]$SearchRoot = (Get-Location).Path,
  [Parameter()][string[]]$Include = @("*.ps1","*.psm1"),
  [Parameter()][string[]]$ExcludeDirs = @(".git",".github",".venv","node_modules")
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'
$files = Get-ChildItem -LiteralPath $SearchRoot -Recurse -File -Include $Include | Where-Object {
  $rel = $_.FullName.Substring($SearchRoot.Length).TrimStart('\','/')
  -not ($ExcludeDirs | ForEach-Object { $rel -like ("{0}\*" -f $_) })
}
$bad = @()
foreach ($f in $files) {
  $sig = Get-AuthenticodeSignature -LiteralPath $f.FullName
  if ($sig.Status -ne 'Valid') { $bad += [pscustomobject]@{ Path = $f.FullName; Status = $sig.Status } }
}
if ($bad.Count -gt 0) {
  $bad | Format-Table -AutoSize | Out-String | Write-Output
  throw "Signature check failed for $($bad.Count) file(s)."
}
Write-Output "All script signatures are VALID."

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDA5chJevy6MGSV
# tHJMuyIwbEkqLQdD7aRYKil20DYfiaCCAxYwggMSMIIB+qADAgECAhBPLBjTDRmm
# pkLX+JLBwcDgMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEyMjIxNzMxWhcNMjUxMTI2MjIyNzMxWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAnl6jRS/MJpiVVJXAMQ79HJbDhC6OR5Vms/xaWTmBJ23n
# QsjRG8TCzQwviA5N+HAxVpufE/nDJmd8hE7FOHKmY9CWu4s1sQXS6wtor/kTzIT/
# VJ7WhmqSuGGUDx1cNteJoDjd4seB0MJ4dlamEKAl/gqJa3o+F/TKKq1/9Ef4GGtA
# dPCNd2RYlPDNelUH7Y2NctOKsKd9xNkrgDUcDRZe83500z7MdUrpqoS9HZhphfEU
# Q85u7qQX6juV4MZDSGoIhgmWkN5LYIVbI15h8Ky0uvDZbYt/rz4iapoFnkBNJAqK
# GclnZto5A7PuCf19gEniQEUFJl+e9TceWB7h8F/oFQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFLpo2LEvdDQr
# PcW3fqlAmZmHQ0TAMA0GCSqGSIb3DQEBCwUAA4IBAQCX418Ml5zWvtE9u/+3gScc
# y6TDK6Z7nVCLR0sjP4yNy21zGYNIX3m86hYPrN9GqWuTlry46YfISyINkwkKCN76
# cLBdyHRrBwycmxvJmAFGbRUOexVm/RtzYmLvXN5l1+ryMK4pBP6EANSfpwPV8PaU
# cO9c2t2/pAlLeZgrEKbggGX7BaWkjY+ZupJYBSbjCXl4UT5VdDNiPb7ouN/+9soA
# zHSk1ovOBfPeAS8T4cxmE5UXGxR5HNqHyhjgxkN0PipKduH3kB3yAe6Ms0iQxNcW
# 7AdGVBqJi0xiicPKGBwbYPgYtY+5V18Oj3RQyV7AjFAjSlNgnovtJLBi/WA7wMV+
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBPLBjTDRmmpkLX+JLBwcDgMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIIEZpCeYMGc2
# kHxmC59rnv7kFfu0+1EDOsevLQv84+74MA0GCSqGSIb3DQEBAQUABIIBAGaA02oN
# Npf1qeY6vzIYYktDljzbZ5UGOYGtjAFsTjM8ALmZj/f7FL8KfQzbnwj2SoDB7aZO
# bIrCiCzE/7oz6+K36UW/qSdkxQM6LRuF55aDE7CZN4wr2smEjoRVr4YhvVwX+TMF
# DHW/v4hftdDhoH1x9pixWxymCB2YKOJv5s7MR7aMgb8urJHAEsgTRZQ0JlhEHskD
# v+J6wQnzHZh8QKk1xc4IL7L/JYxRQ/0/ZUA/vfewhQcDLDU/j4nJFiBUGhCuzTbe
# nXVH7zxJT7sVvVcUUP6r/0qXBxJ2rUI1VMxjuhPc3DOFE6g4jQ16FrL/BucJqC2e
# QDTHTxdok4wQXlY=
# SIG # End signature block
