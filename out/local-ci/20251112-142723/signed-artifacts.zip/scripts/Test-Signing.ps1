#Requires -Version 7.0
<#
.SYNOPSIS
  Runs fork-mode and trusted-mode signing batches locally to mirror CI behavior.

.DESCRIPTION
  - Prepares SIGN_ROOT by copying repo scripts (tools/, scripts/) plus sample payloads.
  - Generates an ephemeral certificate for each mode and runs Invoke-ScriptSigningBatch.ps1.
  - Prints the summary output so we can compare with GitHub runners.

.PARAMETER SignRoot
  Directory to stage unsigned artifacts. Defaults to 'out'.

.PARAMETER MaxFiles
  Max script count to process (passed through to the batch helper).

.PARAMETER TimeoutSeconds
  Timeout for timestamping; batch helper uses it for per-file waits.

.PARAMETER ToolsOnly
  Limit the test payload to scripts under tools/.

.PARAMETER ScriptsOnly
  Limit the test payload to scripts under scripts/.

.PARAMETER SkipToolTests
  Skip running the harness Pester suite (tools and scripts tags). By default the suite runs.

.NOTES
  Every run captures a transcript under out/local-signing-logs for traceability.
#>

[CmdletBinding()]
param(
  [string]$SignRoot = 'out',
  [int]$MaxFiles = 200,
  [int]$TimeoutSeconds = 20,
  [switch]$ToolsOnly,
  [switch]$ScriptsOnly,
  [switch]$IncludeSamples = $true,
  [switch]$SimulateTimestampFailure,
  [switch]$SkipToolTests,
  [string[]]$ExcludePaths = @('local-signing-logs','local-ci')
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

if ($ToolsOnly -and $ScriptsOnly) {
  throw "Use either -ToolsOnly or -ScriptsOnly, not both."
}

function Test-IsExcludedPath {
  param(
    [string]$RelativePath,
    [string[]]$Excludes
  )
  if (-not $RelativePath) { return $false }
  $segments = $RelativePath -split '[\\/]' | Where-Object { $_ }
  foreach ($segment in $segments) {
    if ($Excludes -contains $segment) { return $true }
  }
  return $false
}

function Get-RootsToCopy {
  if ($ToolsOnly)   { return @('tools') }
  if ($ScriptsOnly) { return @('scripts') }
  return @('tools','scripts')
}

function Prepare-SignRoot {
  param(
    [string]$Root,
    [string[]]$SourceRoots,
    [string[]]$ExcludeFolders
  )
  if (-not (Test-Path $Root)) {
    New-Item -ItemType Directory -Path $Root | Out-Null
  } else {
    Get-ChildItem -Path $Root -Force | Where-Object { $ExcludeFolders -notcontains $_.Name } | Remove-Item -Recurse -Force
    foreach ($folder in $ExcludeFolders) {
      $path = Join-Path $Root $folder
      if (-not (Test-Path $path)) {
        New-Item -ItemType Directory -Path $path | Out-Null
      }
    }
  }

  $rootsToCopy = $SourceRoots

  foreach ($rr in $rootsToCopy) {
    $src = Join-Path $PWD $rr
    if (-not (Test-Path $src)) { continue }
    Get-ChildItem -Path $src -Include *.ps1,*.psm1 -Recurse -File |
      ForEach-Object {
        $relative = $_.FullName.Substring($PWD.ToString().Length + 1)
        $dest = Join-Path $Root $relative
        $destDir = Split-Path $dest -Parent
        if (-not (Test-Path $destDir)) { New-Item -ItemType Directory -Path $destDir -Force | Out-Null }
        Copy-Item -Path $_.FullName -Destination $dest -Force
      }
  }

  if ($IncludeSamples) {
    "Write-Output 'Sample payload for signing test.'" | Set-Content -Path (Join-Path $Root 'Sample-Signed.ps1') -Encoding UTF8
    [IO.File]::WriteAllBytes((Join-Path $Root 'sample.exe'), [byte[]](1..16))
  }
}

function Invoke-SigningMode {
  param(
    [string]$ModeLabel,
    [switch]$UseTimestamp,
    [int]$MaxFiles,
    [int]$TimeoutSeconds,
    [string[]]$ExcludeFolders
  )
  $cert = New-SelfSignedCertificate -Subject "CN=CI Local $ModeLabel" -Type CodeSigningCert -CertStoreLocation Cert:\CurrentUser\My -NotAfter (Get-Date).AddDays(14)
  $thumb = $cert.Thumbprint
  $args = @(
    '-NoLogo','-NoProfile','-File','tools/Invoke-ScriptSigningBatch.ps1',
    '-Root', $SignRoot,
    '-CertificateThumbprint', $thumb,
    '-MaxFiles', $MaxFiles,
    '-TimeoutSeconds', $TimeoutSeconds,
    '-Mode', $ModeLabel
  )
  if ($ExcludeFolders -and $ExcludeFolders.Count -gt 0) {
    $args += '-ExcludePaths'
    $args += $ExcludeFolders
  }
  if ($UseTimestamp) {
    $args += @('-UseTimestamp','-TimestampServer','https://timestamp.digicert.com')
    if ($SimulateTimestampFailure -and $ModeLabel -like 'trusted*') {
      $args += '-SimulateTimestampFailure'
    }
  }
  Write-Host "`n== Running mode: $ModeLabel ==" -ForegroundColor Cyan
  pwsh @args
}

function Invoke-HarnessTests {
  param([string[]]$Tags)
  $effectiveTags = @($Tags | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
  if ($effectiveTags.Count -eq 0) {
    Write-Host "No harness tags selected; skipping Pester harness run." -ForegroundColor Yellow
    return
  }

  $runner = Join-Path $PSScriptRoot 'Invoke-RepoPester.ps1'
  if (-not (Test-Path $runner)) {
    throw "Cannot locate Invoke-RepoPester.ps1 at $runner"
  }

  Write-Host "`n== Running harness Pester suite (tags: $($effectiveTags -join ', ')) ==" -ForegroundColor Cyan
  & $runner -Tag $effectiveTags
}

$transcriptDir = Join-Path $PWD 'out/local-signing-logs'
if (-not (Test-Path $transcriptDir)) { New-Item -ItemType Directory -Path $transcriptDir -Force | Out-Null }
$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$logPath = Join-Path $transcriptDir "signing-$timestamp.log"
Start-Transcript -Path $logPath | Out-Null

try {
  $selectedRoots = Get-RootsToCopy
  Prepare-SignRoot -Root $SignRoot -SourceRoots $selectedRoots -ExcludeFolders $ExcludePaths
  Invoke-SigningMode -ModeLabel 'fork-local' -MaxFiles $MaxFiles -TimeoutSeconds $TimeoutSeconds -ExcludeFolders $ExcludePaths
  Invoke-SigningMode -ModeLabel 'trusted-local' -UseTimestamp -MaxFiles $MaxFiles -TimeoutSeconds $TimeoutSeconds -ExcludeFolders $ExcludePaths
  if (-not $SkipToolTests) {
    $harnessTags = @()
    if ($ToolsOnly) {
      $harnessTags = @('tools')
    } elseif ($ScriptsOnly) {
      $harnessTags = @('scripts')
    } else {
      $harnessTags = @('tools','scripts')
    }
    Invoke-HarnessTests -Tags $harnessTags
  } else {
    Write-Host "Skipping harness Pester suite (-SkipToolTests set)." -ForegroundColor Yellow
  }
} finally {
  Stop-Transcript | Out-Null
  Write-Host "Transcript written to $logPath" -ForegroundColor Yellow
}

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCArusWqFFiYhyFp
# QvO2PQeCk5qmU8SbNotYCFEYw6jOCaCCAxYwggMSMIIB+qADAgECAhBPLBjTDRmm
# pkLX+JLBwcDgMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEyMjIxNzMxWhcNMjUxMTI2MjIyNzMxWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAnl6jRS/MJpiVVJXAMQ79HJbDhC6OR5Vms/xaWTmBJ23n
# QsjRG8TCzQwviA5N+HAxVpufE/nDJmd8hE7FOHKmY9CWu4s1sQXS6wtor/kTzIT/
# VJ7WhmqSuGGUDx1cNteJoDjd4seB0MJ4dlamEKAl/gqJa3o+F/TKKq1/9Ef4GGtA
# dPCNd2RYlPDNelUH7Y2NctOKsKd9xNkrgDUcDRZe83500z7MdUrpqoS9HZhphfEU
# Q85u7qQX6juV4MZDSGoIhgmWkN5LYIVbI15h8Ky0uvDZbYt/rz4iapoFnkBNJAqK
# GclnZto5A7PuCf19gEniQEUFJl+e9TceWB7h8F/oFQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFLpo2LEvdDQr
# PcW3fqlAmZmHQ0TAMA0GCSqGSIb3DQEBCwUAA4IBAQCX418Ml5zWvtE9u/+3gScc
# y6TDK6Z7nVCLR0sjP4yNy21zGYNIX3m86hYPrN9GqWuTlry46YfISyINkwkKCN76
# cLBdyHRrBwycmxvJmAFGbRUOexVm/RtzYmLvXN5l1+ryMK4pBP6EANSfpwPV8PaU
# cO9c2t2/pAlLeZgrEKbggGX7BaWkjY+ZupJYBSbjCXl4UT5VdDNiPb7ouN/+9soA
# zHSk1ovOBfPeAS8T4cxmE5UXGxR5HNqHyhjgxkN0PipKduH3kB3yAe6Ms0iQxNcW
# 7AdGVBqJi0xiicPKGBwbYPgYtY+5V18Oj3RQyV7AjFAjSlNgnovtJLBi/WA7wMV+
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBPLBjTDRmmpkLX+JLBwcDgMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEINeYYWcRHuzr
# U688EKYnZSa2dyi5ouOy67izv0egpe51MA0GCSqGSIb3DQEBAQUABIIBAGJRst3+
# M/OOK8pHJTPf29LMUUWX/2asCbkN1bKH3K0k1145/TBLSda9T2L/ATwLRGH3ilze
# /1dfvX5F3US7EaX5i8l2ZX+83NffSJcA8+Gh43+0HxAFYVFm+cHNU6AoGJca5svy
# Rf0v5Set85q8n8zcUl5GFWg1+qMmq0DS51Cl8wgqnVnu8zKlqh2wvZ3qHQ1t/aUh
# dh9Qd8NOgwkWKeJC9fmuiV49gu1/v24cfB0mFP3lhQh8iAqVsaIYRvMTl0Ro9S3Q
# c5+w+ZuAioX8EoNw8/rSCOKHlbVjtSfhoYtYiWO1DIQZ4s4TkxrzgPy0Kfw6Uoz8
# DL53IJvJ/KUXzNc=
# SIG # End signature block
