#Requires -Version 7.0
[CmdletBinding()]
param(
    [string]$Root = 'out/semver-bundle'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$rootPath = [System.IO.Path]::GetFullPath($Root)
if (-not (Test-Path -LiteralPath $rootPath -PathType Container)) {
    throw "[SVB300] No SemVer bundles found under $rootPath"
}

$bundle = Get-ChildItem -LiteralPath $rootPath -Directory | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $bundle) {
    throw "[SVB300] No SemVer bundles found under $rootPath"
}

$summaryPath = Join-Path $bundle.FullName 'semver-summary.json'
$summary = $null
if (Test-Path -LiteralPath $summaryPath -PathType Leaf) {
    try {
        $summary = Get-Content -LiteralPath $summaryPath -Raw | ConvertFrom-Json -ErrorAction Stop
    } catch {
        Write-Warning ("[SVB202] Failed to read summary JSON: {0}" -f $_.Exception.Message)
    }
}

[pscustomobject]@{
    BundleRoot = $bundle.FullName
    ZipPath    = "$($bundle.FullName).zip"
    Summary    = $summary
}

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDX1yHpgv4n6QSq
# t5kkJikX+boV/u0FrptEuQebx9o3l6CCAxYwggMSMIIB+qADAgECAhAeQ0rNxhNN
# jk1s5MvQd0RVMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMjE1MTI0WhcNMjUxMTI3MjIwMTI0WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA7DFzaM4b+gW87h6aUVGitlcb8JHdTHt9fcZOJEOGWm2Z
# D5/ShKgEDLCf0SGuMLk6+duKofSl+25jRk2Sna/n9f7iaRf01lQ5MO0+FO9jGKHM
# eLVGRNsgCFDcxYG9FEcpcEe897HY0IStONCLvD9DR1ICJEmEzxnoSY3MO49gQaZq
# xrVOqVhHT1MkYOwcOFKnVjNShWsyyzGYFlhn5lTq7FuvTGbOUsBxpnIakGNnHJI6
# 3Ne24TnojX28pf3WTsh+zXSpYbZn1PV09MbPPFbjmK5UnQ+V0HucIGIE5HjvcBKX
# 9B57rkAq06mKJThf4vDsJ+jED8OBbalruFTIMdAgRQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFLOm5hqRy8Q6
# fpSa2zqvNcu3J7XbMA0GCSqGSIb3DQEBCwUAA4IBAQCX7UEyeARXZdH87dNQz0kl
# doKrltT98ZGOa/ym0uqGyFpA5+HkeIKtP4/HLWeI47tHCmAcR5v5IcIiwmbVp/N1
# REyV9LKi9RMXIdfA8uKP2w7cIv81uNDSEkJ8JaYkacNryIXbzor7o7pihHaz+Xc/
# j5XMJfgF0ibhhfThpvFJzvb+W3crScligJILLeOo1uz4PwOgbDPY3VH+GdXOChMK
# LmAyQm1q4MRWcXPkZAb3/O7OKGrRqMF3IsKDazPKfCAq6I/pMFWAc7W39WlyxfcA
# QuTgQR2dMN2XJOZ5IuWkOPqhVQo2mOmI8PDGGKdphL6VFG0tJwwC1z6p8Sm+pa8h
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAeQ0rNxhNNjk1s5MvQd0RVMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIEYBD5Y3r8tS
# z19YGGp/FTByrUm5EHI8CkcR3OTA0txvMA0GCSqGSIb3DQEBAQUABIIBAKEkYfuC
# DVBprHuKVPzjn/P2fOFKs2fD8jXSYdmqpcKwCRdYD3pcL/wei2okyWEASXPrxj+C
# Lgx6+fTQQoJ7AUyyRRm82Cl4UvSpckE+/eQYYXROV40+rAjqaBWYXU7GtRUnVtzh
# iNeEfKNaxPoVqx2uURg49hxgtBh/+jEmObo5r+ZgRB9GBO1Zx6EGIeuouxjAEn9W
# ZAL5yP797KA0ujgW/0X+TkPT6O5QP7Kwq2jVa6uT0HF4sxU0l8zI1MNfvJEQanlX
# 1yz6Asb6RJXfxwc3dC4sQAVw3el9TS5Xz1uL5gocVHU+lNcaJEgbqJXi+JCctEty
# q2VYw75xrxPQHy4=
# SIG # End signature block
