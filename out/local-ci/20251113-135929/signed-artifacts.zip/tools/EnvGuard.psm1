# EnvGuard.psm1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Get-EnvSnapshot {
    [CmdletBinding()]
    param([string[]]$AllowList = @('PATH','TEMP','TMP','HOME','USERPROFILE'))
    $snap = @{}
    foreach ($name in [Environment]::GetEnvironmentVariables().Keys) {
        if ($AllowList -contains $name) { $snap[$name] = [Environment]::GetEnvironmentVariable($name,'Process') }
    }
    return $snap
}

function Set-EnvFromSnapshot {
    [CmdletBinding()]
    param([Parameter(Mandatory)][hashtable]$Snapshot)
    foreach ($k in $Snapshot.Keys) {
        [Environment]::SetEnvironmentVariable($k, [string]$Snapshot[$k], 'Process')
    }
}

Export-ModuleMember -Function Get-EnvSnapshot, Set-EnvFromSnapshot

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAzwwfWBljXiDkz
# 9AHE9bg618B2oMEor3Mbt2BkcXsxKKCCAxYwggMSMIIB+qADAgECAhAeQ0rNxhNN
# jk1s5MvQd0RVMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMjE1MTI0WhcNMjUxMTI3MjIwMTI0WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA7DFzaM4b+gW87h6aUVGitlcb8JHdTHt9fcZOJEOGWm2Z
# D5/ShKgEDLCf0SGuMLk6+duKofSl+25jRk2Sna/n9f7iaRf01lQ5MO0+FO9jGKHM
# eLVGRNsgCFDcxYG9FEcpcEe897HY0IStONCLvD9DR1ICJEmEzxnoSY3MO49gQaZq
# xrVOqVhHT1MkYOwcOFKnVjNShWsyyzGYFlhn5lTq7FuvTGbOUsBxpnIakGNnHJI6
# 3Ne24TnojX28pf3WTsh+zXSpYbZn1PV09MbPPFbjmK5UnQ+V0HucIGIE5HjvcBKX
# 9B57rkAq06mKJThf4vDsJ+jED8OBbalruFTIMdAgRQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFLOm5hqRy8Q6
# fpSa2zqvNcu3J7XbMA0GCSqGSIb3DQEBCwUAA4IBAQCX7UEyeARXZdH87dNQz0kl
# doKrltT98ZGOa/ym0uqGyFpA5+HkeIKtP4/HLWeI47tHCmAcR5v5IcIiwmbVp/N1
# REyV9LKi9RMXIdfA8uKP2w7cIv81uNDSEkJ8JaYkacNryIXbzor7o7pihHaz+Xc/
# j5XMJfgF0ibhhfThpvFJzvb+W3crScligJILLeOo1uz4PwOgbDPY3VH+GdXOChMK
# LmAyQm1q4MRWcXPkZAb3/O7OKGrRqMF3IsKDazPKfCAq6I/pMFWAc7W39WlyxfcA
# QuTgQR2dMN2XJOZ5IuWkOPqhVQo2mOmI8PDGGKdphL6VFG0tJwwC1z6p8Sm+pa8h
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAeQ0rNxhNNjk1s5MvQd0RVMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIJlQaYHytxsd
# hJ21/Xd1OOTWhUd4iNiRCRC/DDWxp9vgMA0GCSqGSIb3DQEBAQUABIIBANRiFvyg
# 9f6bGzT37mb1UifmRTKGrnd8sVR8o92lNmKhP7co1vCYGdNtXjGke03lrJ449tWm
# TqVPfo9+av0bmCKyDJCJXx3GM4m3V/Ezs+kMeV7p5KKkmirO3UHiIDuOByOrz/vv
# 6DNhjhgxCNw113R8dkH4yeF/95lYp9hZLUXTh06YrjBx6ZeoQycP9TuucXp6C1pT
# K3bgTc6C1yIvbCMN8zWBh2jLBbTTrCJW5lU85zNbN2QLQpQanLxTxiRshDNzpiJy
# L5TaBGMv4WfXWSkaiElKImDmwpAjWHt/rosHNMVDnfYJUc09hiZM7shOIX/nxGRJ
# BXmhuE9BPSC0Tuw=
# SIG # End signature block
