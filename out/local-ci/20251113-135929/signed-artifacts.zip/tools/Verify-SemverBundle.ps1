#Requires -Version 7.0
[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$BundlePath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Resolve-Manifest {
  param([string]$Path)
  if ((Test-Path -LiteralPath $Path -PathType Container)) {
    $candidate = Join-Path $Path 'bundle.json'
    if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) {
      throw "bundle.json not found under $Path"
    }
    return $candidate
  }
  if ((Test-Path -LiteralPath $Path -PathType Leaf) -and $Path.EndsWith('.zip')) {
    $tempDir = New-Item -ItemType Directory -Force -Path (Join-Path $env:TEMP "semver-bundle-$(Get-Random)")
    Expand-Archive -LiteralPath $Path -DestinationPath $tempDir -Force
    $manifest = Join-Path $tempDir 'bundle.json'
    if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) {
      throw "bundle.json missing inside archive $Path"
    }
    return $manifest
  }
  throw "Unsupported bundle path: $Path"
}

$manifestPath = Resolve-Manifest -Path $BundlePath
$bundleRoot = Split-Path -Parent $manifestPath
$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
$failures = @()

foreach ($file in $manifest.files) {
  $fullPath = Join-Path $bundleRoot $file.relativePath
  if (-not (Test-Path -LiteralPath $fullPath -PathType Leaf)) {
    $failures += "Missing file: $($file.relativePath)"
    continue
  }
  $hash = (Get-FileHash -LiteralPath $fullPath -Algorithm SHA256).Hash
  if ($hash -ne $file.sha256) {
    $failures += "Hash mismatch ($($file.relativePath)) expected $($file.sha256) actual $hash"
  }
}

if ($failures.Count -gt 0) {
  Write-Error "Bundle verification failed:" -ErrorAction Stop
}

Write-Host "Bundle verified successfully: $bundleRoot" -ForegroundColor Green

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDjr3yXkH4ndjxr
# 1Y11zhgNRCuKm1tcHCh7s0nCEGFYb6CCAxYwggMSMIIB+qADAgECAhAeQ0rNxhNN
# jk1s5MvQd0RVMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMjE1MTI0WhcNMjUxMTI3MjIwMTI0WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA7DFzaM4b+gW87h6aUVGitlcb8JHdTHt9fcZOJEOGWm2Z
# D5/ShKgEDLCf0SGuMLk6+duKofSl+25jRk2Sna/n9f7iaRf01lQ5MO0+FO9jGKHM
# eLVGRNsgCFDcxYG9FEcpcEe897HY0IStONCLvD9DR1ICJEmEzxnoSY3MO49gQaZq
# xrVOqVhHT1MkYOwcOFKnVjNShWsyyzGYFlhn5lTq7FuvTGbOUsBxpnIakGNnHJI6
# 3Ne24TnojX28pf3WTsh+zXSpYbZn1PV09MbPPFbjmK5UnQ+V0HucIGIE5HjvcBKX
# 9B57rkAq06mKJThf4vDsJ+jED8OBbalruFTIMdAgRQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFLOm5hqRy8Q6
# fpSa2zqvNcu3J7XbMA0GCSqGSIb3DQEBCwUAA4IBAQCX7UEyeARXZdH87dNQz0kl
# doKrltT98ZGOa/ym0uqGyFpA5+HkeIKtP4/HLWeI47tHCmAcR5v5IcIiwmbVp/N1
# REyV9LKi9RMXIdfA8uKP2w7cIv81uNDSEkJ8JaYkacNryIXbzor7o7pihHaz+Xc/
# j5XMJfgF0ibhhfThpvFJzvb+W3crScligJILLeOo1uz4PwOgbDPY3VH+GdXOChMK
# LmAyQm1q4MRWcXPkZAb3/O7OKGrRqMF3IsKDazPKfCAq6I/pMFWAc7W39WlyxfcA
# QuTgQR2dMN2XJOZ5IuWkOPqhVQo2mOmI8PDGGKdphL6VFG0tJwwC1z6p8Sm+pa8h
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAeQ0rNxhNNjk1s5MvQd0RVMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEILQuIDyMgfaK
# B382xHdCDlgpFW4Gkiy8p3BaoHKMRV6AMA0GCSqGSIb3DQEBAQUABIIBAHtHVTgM
# 3YYoMRH35EL1GlZ6PZuaNSnH/5XjJIcmq5hUIhX2iqOMLSqPxaCAhmy1g9RqhP8A
# LVZ01xHYrH8EjPicAxJS9TQnv/J+cPYSNp5XSEy3rSTGHJ3xKXkjei2p1i7sLMM/
# mvR/x1q30B5MuJjAymFw2dFH8FM4ddmdQSs/WTvGjg15P7NLm7wBnOLwCX/vedrJ
# v2d3bMNnSPvYak41eH5krf2VxZL/dUp0jQZy7C8lgO1f8cZc0PHOq3EQd1JVF3/G
# oYXTZOj84lMTfvEiTKUsGrrpgumbP617AIU3OuF5CEeBnvfkBwQn4veDqecx3Tkv
# EV7ZzEDOxQ78LCc=
# SIG # End signature block
