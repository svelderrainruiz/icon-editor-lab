[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$ConfigPath,
  [Parameter()][string]$SchemaPath = (Join-Path $PSScriptRoot '..' 'configs' 'schema' 'vi-diff-heuristics.schema.json')
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'
. (Join-Path $PSScriptRoot 'Redaction.ps1')
$cfgContent = Get-Content -LiteralPath $ConfigPath -Raw
# Basic JSON validity check
$null = $cfgContent | ConvertFrom-Json -ErrorAction Stop
# Schema validation (if schema exists)
if (Test-Path -LiteralPath $SchemaPath -PathType Leaf) {
  $cfgContent | Test-Json -SchemaFile $SchemaPath -ErrorAction Stop | Out-Null
}
Write-Output "Config validated successfully:" (Resolve-Path -LiteralPath $ConfigPath).Path

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAtM1F8YzQ4xa9F
# 7QuDGJd4jTwMhZsuR+3nhXLiXLTUlKCCAxYwggMSMIIB+qADAgECAhAeQ0rNxhNN
# jk1s5MvQd0RVMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMjE1MTI0WhcNMjUxMTI3MjIwMTI0WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA7DFzaM4b+gW87h6aUVGitlcb8JHdTHt9fcZOJEOGWm2Z
# D5/ShKgEDLCf0SGuMLk6+duKofSl+25jRk2Sna/n9f7iaRf01lQ5MO0+FO9jGKHM
# eLVGRNsgCFDcxYG9FEcpcEe897HY0IStONCLvD9DR1ICJEmEzxnoSY3MO49gQaZq
# xrVOqVhHT1MkYOwcOFKnVjNShWsyyzGYFlhn5lTq7FuvTGbOUsBxpnIakGNnHJI6
# 3Ne24TnojX28pf3WTsh+zXSpYbZn1PV09MbPPFbjmK5UnQ+V0HucIGIE5HjvcBKX
# 9B57rkAq06mKJThf4vDsJ+jED8OBbalruFTIMdAgRQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFLOm5hqRy8Q6
# fpSa2zqvNcu3J7XbMA0GCSqGSIb3DQEBCwUAA4IBAQCX7UEyeARXZdH87dNQz0kl
# doKrltT98ZGOa/ym0uqGyFpA5+HkeIKtP4/HLWeI47tHCmAcR5v5IcIiwmbVp/N1
# REyV9LKi9RMXIdfA8uKP2w7cIv81uNDSEkJ8JaYkacNryIXbzor7o7pihHaz+Xc/
# j5XMJfgF0ibhhfThpvFJzvb+W3crScligJILLeOo1uz4PwOgbDPY3VH+GdXOChMK
# LmAyQm1q4MRWcXPkZAb3/O7OKGrRqMF3IsKDazPKfCAq6I/pMFWAc7W39WlyxfcA
# QuTgQR2dMN2XJOZ5IuWkOPqhVQo2mOmI8PDGGKdphL6VFG0tJwwC1z6p8Sm+pa8h
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAeQ0rNxhNNjk1s5MvQd0RVMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPGNlwZgDGGO
# 4eoZqf6qFtcbYyZe5LvdTuTwGIaPVsX8MA0GCSqGSIb3DQEBAQUABIIBACb9OZ5q
# pNiUrc2cHKN4LELz1xOvJaxluaA/PMGIjeVtGoUQrHeTnIcLkL6pqLRmPLZRTR6M
# +Wf243Tc3xMDXWJFPhDbsLDJ+xRjf6FkN8J4QEgGdIInq8ARbygb+BITb1IZ7t9H
# zh8w67SP7nInl3TP2mNjgTzfnEfSqKx4PcyX7Ie47bZ9c7d/aG6fHyDcmOxv/QF3
# xV2hy8gbuk0ikqBOGTMk4euzkR5xgDwuV2l7KGjeLAFn1GFi44zvIJFrYlk3/UyO
# eK4hSLGLhejxQYxRUZ3NBaKDrbHnoRlQGingUTXwCraFOeN86G1r0mA/niQm51ah
# vy4SWdf3QQbHeKc=
# SIG # End signature block
