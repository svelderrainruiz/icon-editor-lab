# Sign-Scripts.ps1
[CmdletBinding()]
param(
  [Parameter()][string]$Thumbprint,
  [Parameter()][string]$SearchRoot = (Get-Location).Path,
  [Parameter()][string[]]$Include = @("*.ps1","*.psm1"),
  [Parameter()][string[]]$ExcludeDirs = @(".git",".github",".venv","node_modules"),
  [switch]$SkipTimestamp,
  [Parameter()][ValidateRange(1,1000)][int]$ProgressInterval = 25,
  [Parameter()][ValidateRange(0,1000)][int]$ThrottleMilliseconds = 0
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'
if (-not (Test-Path -LiteralPath $SearchRoot -PathType Container)) {
  throw "Search root not found: $SearchRoot"
}
Write-Host "Signing scripts under: $SearchRoot"
$includeMatchers = @(
  $Include | ForEach-Object {
    if ($_ -and $_.Trim()) {
      [System.Management.Automation.WildcardPattern]::new($_.Trim(),'IgnoreCase')
    }
  }
)
if ($includeMatchers.Count -eq 0) {
  $includeMatchers = @([System.Management.Automation.WildcardPattern]::new('*','IgnoreCase'))
}
function Get-GitTrackedFiles {
  param()
  $gitDir = Join-Path $SearchRoot '.git'
  if (-not (Test-Path -LiteralPath $gitDir -PathType Container)) {
    return @()
  }
  Push-Location $SearchRoot
  try {
    $arguments = @('ls-files','-z','--','*.ps1','*.psm1')
    $output = & git @arguments 2>$null
    if ($LASTEXITCODE -ne 0 -or -not $output) {
      return @()
    }
    return $output -split "`0" | Where-Object { $_ }
  }
  finally {
    Pop-Location
  }
}
function Get-CodeSigningCert {
  param([string]$Thumbprint)
  if ($Thumbprint) {
    $c = Get-ChildItem Cert:\CurrentUser\My\$Thumbprint -ErrorAction SilentlyContinue
    if ($c) { return $c }
  }
  $c = Get-ChildItem Cert:\CurrentUser\My | Where-Object { $_.HasPrivateKey -and $_.EnhancedKeyUsageList.FriendlyName -contains 'Code Signing' } | Select-Object -First 1
  if (-not $c) { throw 'No suitable code-signing certificate found.' }
  return $c
}
$cert = Get-CodeSigningCert -Thumbprint $Thumbprint
$gitCandidates = Get-GitTrackedFiles
if ($gitCandidates.Count -gt 0) {
  Write-Host ("Discovered {0} git-tracked candidate(s) via ls-files." -f $gitCandidates.Count)
  $candidates = @(
    $gitCandidates | ForEach-Object {
      $path = Join-Path $SearchRoot $_
      if (Test-Path -LiteralPath $path -PathType Leaf) { Get-Item -LiteralPath $path }
    } | Where-Object { $_ }
  )
}
else {
  Write-Host 'git ls-files returned no matches; falling back to filesystem enumeration.'
  $candidates = @(Get-ChildItem -LiteralPath $SearchRoot -Recurse -File)
}
Write-Host ("Discovered {0} candidate file(s) before filtering." -f $candidates.Count)
$files = @($candidates | Where-Object {
  $rel = $_.FullName.Substring($SearchRoot.Length).TrimStart('\','/')
  if ($ExcludeDirs | Where-Object { $rel -like ("{0}\*" -f $_) }) {
    return $false
  }
  foreach ($matcher in $includeMatchers) {
    if ($matcher.IsMatch($_.Name)) { return $true }
  }
  return $false
})
$total = $files.Count
if ($total -eq 0) {
  Write-Warning 'No files matched the signing criteria; nothing to do.'
  return
}
$stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
$processed = 0
foreach ($f in $files) {
  $sig = Get-AuthenticodeSignature -LiteralPath $f.FullName
  if ($sig.Status -ne 'Valid') {
    if ($SkipTimestamp) {
      Write-Verbose ("Signing {0} without timestamp (ephemeral cert)." -f $f.FullName)
      $null = Set-AuthenticodeSignature -LiteralPath $f.FullName -Certificate $cert
    }
    else {
      Write-Verbose ("Signing {0} with timestamp server." -f $f.FullName)
      $null = Set-AuthenticodeSignature -LiteralPath $f.FullName -Certificate $cert -TimestampServer 'http://timestamp.digicert.com'
    }
  }
  $processed++
  $logCheckpoint = ($ProgressInterval -gt 0) -and (($processed -eq 1) -or ($processed % $ProgressInterval -eq 0) -or ($processed -eq $total))
  if ($logCheckpoint) {
    Write-Host ("[{0}/{1}] Last signed: {2}" -f $processed, $total, $f.FullName)
  }
  if ($ThrottleMilliseconds -gt 0) {
    Start-Sleep -Milliseconds $ThrottleMilliseconds
  }
}
$stopwatch.Stop()
Write-Output ("Signed {0} script(s) in {1:n2}s." -f $processed, $stopwatch.Elapsed.TotalSeconds)

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDYpfv9H/2BrGi3
# 0MwBmTlEqdu/5KsCsUUBa2BGGZtVxKCCAxYwggMSMIIB+qADAgECAhAeQ0rNxhNN
# jk1s5MvQd0RVMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMjE1MTI0WhcNMjUxMTI3MjIwMTI0WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA7DFzaM4b+gW87h6aUVGitlcb8JHdTHt9fcZOJEOGWm2Z
# D5/ShKgEDLCf0SGuMLk6+duKofSl+25jRk2Sna/n9f7iaRf01lQ5MO0+FO9jGKHM
# eLVGRNsgCFDcxYG9FEcpcEe897HY0IStONCLvD9DR1ICJEmEzxnoSY3MO49gQaZq
# xrVOqVhHT1MkYOwcOFKnVjNShWsyyzGYFlhn5lTq7FuvTGbOUsBxpnIakGNnHJI6
# 3Ne24TnojX28pf3WTsh+zXSpYbZn1PV09MbPPFbjmK5UnQ+V0HucIGIE5HjvcBKX
# 9B57rkAq06mKJThf4vDsJ+jED8OBbalruFTIMdAgRQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFLOm5hqRy8Q6
# fpSa2zqvNcu3J7XbMA0GCSqGSIb3DQEBCwUAA4IBAQCX7UEyeARXZdH87dNQz0kl
# doKrltT98ZGOa/ym0uqGyFpA5+HkeIKtP4/HLWeI47tHCmAcR5v5IcIiwmbVp/N1
# REyV9LKi9RMXIdfA8uKP2w7cIv81uNDSEkJ8JaYkacNryIXbzor7o7pihHaz+Xc/
# j5XMJfgF0ibhhfThpvFJzvb+W3crScligJILLeOo1uz4PwOgbDPY3VH+GdXOChMK
# LmAyQm1q4MRWcXPkZAb3/O7OKGrRqMF3IsKDazPKfCAq6I/pMFWAc7W39WlyxfcA
# QuTgQR2dMN2XJOZ5IuWkOPqhVQo2mOmI8PDGGKdphL6VFG0tJwwC1z6p8Sm+pa8h
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAeQ0rNxhNNjk1s5MvQd0RVMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIBiG+2ADMClH
# s6Yi2OyfzhR1yY57aD5XUqXcEBcdbcrjMA0GCSqGSIb3DQEBAQUABIIBAG6xEBER
# zeSohzeZ0kCPQHvRLes94iFfbRZ9rcEEEQ+7A7bgwGd1eFiTB2dRuBracBpVE0m4
# 7cut4mcKtgdFyNsqY3K7iDIao7lEaDWg3iDydMJ9vVOzt4OcFaeUQDVK2sf2sYzO
# Y9hoZ7WhwezF4/oEYl5VBryjqjBw9/KGPsjstqyIFhuZSw1r5h6UiICDgeOg7gSS
# fExCnv444G2mbmc3KTifFnzAMIFuFT1Zq9bgJDitXV/r4EC3k43ibvQ59brFB5NX
# huh9tJcG2qiHS8tOx5VngBIvGnx3eU5YckZqEt6afXWowwTaP0fV6nlkrUJh7swE
# jlMetarvGokr9Rc=
# SIG # End signature block
