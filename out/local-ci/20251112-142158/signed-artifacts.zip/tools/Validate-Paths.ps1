# Validate-Paths.ps1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Test-PathSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter()][switch]$RequireAbsolute
    )
    if ($Path -match '[;&|`]' -or $Path -match '\.\.') { return $false }
    try {
        $rp = Resolve-Path -LiteralPath $Path -ErrorAction Stop
        if ($RequireAbsolute -and -not ($rp.Path -match '^(?:[A-Za-z]:[\\/]|/)')) { return $false }
        return $true
    } catch { return $false }
}

function Validate-PathSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter()][switch]$RequireAbsolute
    )
    if (-not (Test-PathSafe -Path $Path -RequireAbsolute:$RequireAbsolute)) {
        throw "Unsafe or invalid path: $Path"
    }
    return (Resolve-Path -LiteralPath $Path).Path
}

Export-ModuleMember -Function Test-PathSafe, Validate-PathSafe

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBRKRGFgRiwJrUW
# ser+RbKUtmM3v2Ar6IG3lNNJMXHBxaCCAxYwggMSMIIB+qADAgECAhAULDkmNIU8
# mEIZFfOMXwc6MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEyMjIxMjA1WhcNMjUxMTI2MjIyMjA1WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAx165pbQ/eUkiiEfR+jiVeuaLhqQJcDOw9y5Fu6BrNwUg
# LU6lYXuWgXmtPOR323gL9kEV+N3h9NTENmvkSGWNS2ZGgPHxOODAcsAZnQah2glD
# QSBb9r5g+e/SkzKzymnGRl5IOT+iot2xjTlCOODuRwX/9Fm0skmrjTzdtws+LyfE
# y+eau8wWUeDJnfSBKviayL1U5ctm/UkEtyqIpRG8Uajxj54s3B7UWmv56hY6lQx1
# eUSIxxMpuWKuSiaAKLFrV7i4NcQ8ossLHaBUyJKuiM7fLn3NGl8qzq0qpzby58s7
# xRS25wxIfhOhAHY03lTrYlUkWXL0BmUe6hI2LRFjEQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFFqziKakCPK3
# jRRvz+Af4e8bwQ0bMA0GCSqGSIb3DQEBCwUAA4IBAQCLHlNNLjd0cr0EuQfetHMV
# DPy2R3DUQJ9r9GZz0H0vzTvFYdJn4+skFA2q74dhjrLJkDyf9HuU7Sb+4stXxZ3G
# dH4fNpvRSCbSjhgzUJo7XOxU7q/Bxhz2OqMWJ+uEJYFyIKNIh8lXoQkIeYWKOPmD
# Loj3R3XwR1rAF3cGFjelxQSJphuaHy1F26KzNjIInnP1Tq9SwT+if9KVGmmRJYXn
# LMN+m3qTNN2+NSfWR5wzfVMXMM/e4w0+fnoC7RN79xM1OFKitCFlEKNhXz7pa5NI
# RuNAMydrHEuXdnGeGl2m5cAts4k/W6Yij3TYv4+Tv4JIrHLVEjDfaRZ6pwAVU/oi
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAULDkmNIU8mEIZFfOMXwc6MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEINpvsU+HHb6K
# gYnFC+DOD7Pi21ghNNfHTvYHF7x5UIBMMA0GCSqGSIb3DQEBAQUABIIBABnGnPCS
# FX1HDcyZk7Tkz4XU21AbnJ1TECaSwob91aJqqTBM0sEVfDoB+aoff7Ho19uAMV9l
# mfsiRfIlVpN+rxNyA1y64Gm5BtBk+E7gyOZusjskGXhgVJapwH3r/aYKjZOx/Ger
# WKDElQosX9seVDKJ+HRHPHkvEcJ+E9NZ0PpD+J40tAdQgnulp2wKtTKYEMniPqHq
# HM27LjCFa6KdP0aB7QlIlBxA0wT/u+7t8TB/fJoFUUU4S3yklUbaoheqUMc02R3S
# 4dz/S71vXQFOAfJy8Viiw3B/oEahNZ3+ptmxChnWowEyQoHofvSqqiQSsSH5PzEH
# HW0GIVAwDC0UEXY=
# SIG # End signature block
