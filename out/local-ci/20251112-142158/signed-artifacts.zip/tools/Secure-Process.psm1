# Secure-Process.psm1
Set-StrictMode -Version Latest
. (Join-Path $PSScriptRoot 'Validate-Paths.ps1')
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Invoke-ProcessSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$FilePath,
        [Parameter()][string[]]$ArgumentList = @(),
        [Parameter()][int]$TimeoutSec = 600,
        [Parameter()][string]$WorkingDirectory = (Get-Location).Path
    )
    if (-not (Test-Path -LiteralPath $FilePath -PathType Leaf)) { throw "FilePath not found: $FilePath" }
    $psi = [System.Diagnostics.ProcessStartInfo]::new()
    $psi.FileName = $FilePath
    $psi.WorkingDirectory = (Validate-PathSafe -Path $WorkingDirectory)
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.UseShellExecute = $false
    foreach ($a in $ArgumentList) { $null = $psi.ArgumentList.Add($a) }

    $p = [System.Diagnostics.Process]::new()
    $p.StartInfo = $psi
    if (-not $p.Start()) { throw "Failed to start process: $FilePath" }
    try {
        if (-not $p.WaitForExit($TimeoutSec * 1000)) {
            try { $p.Kill($true) } catch {}
            throw "Process timed out after $TimeoutSec s: $FilePath"
        }
        $stdout = $p.StandardOutput.ReadToEnd()
        $stderr = $p.StandardError.ReadToEnd()
        return [pscustomobject]@{
            ExitCode = $p.ExitCode
            StdOut = $stdout
            StdErr = $stderr
        }
    } finally {
        if (-not $p.HasExited) { try { $p.Kill($true) } catch {} }
        $p.Dispose()
    }
}
Export-ModuleMember -Function Invoke-ProcessSafe

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDLM/hZ77J6ko3k
# J1T1SnSI3Zjg9T8EF5sOyyHIvgXLgqCCAxYwggMSMIIB+qADAgECAhAULDkmNIU8
# mEIZFfOMXwc6MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEyMjIxMjA1WhcNMjUxMTI2MjIyMjA1WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAx165pbQ/eUkiiEfR+jiVeuaLhqQJcDOw9y5Fu6BrNwUg
# LU6lYXuWgXmtPOR323gL9kEV+N3h9NTENmvkSGWNS2ZGgPHxOODAcsAZnQah2glD
# QSBb9r5g+e/SkzKzymnGRl5IOT+iot2xjTlCOODuRwX/9Fm0skmrjTzdtws+LyfE
# y+eau8wWUeDJnfSBKviayL1U5ctm/UkEtyqIpRG8Uajxj54s3B7UWmv56hY6lQx1
# eUSIxxMpuWKuSiaAKLFrV7i4NcQ8ossLHaBUyJKuiM7fLn3NGl8qzq0qpzby58s7
# xRS25wxIfhOhAHY03lTrYlUkWXL0BmUe6hI2LRFjEQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFFqziKakCPK3
# jRRvz+Af4e8bwQ0bMA0GCSqGSIb3DQEBCwUAA4IBAQCLHlNNLjd0cr0EuQfetHMV
# DPy2R3DUQJ9r9GZz0H0vzTvFYdJn4+skFA2q74dhjrLJkDyf9HuU7Sb+4stXxZ3G
# dH4fNpvRSCbSjhgzUJo7XOxU7q/Bxhz2OqMWJ+uEJYFyIKNIh8lXoQkIeYWKOPmD
# Loj3R3XwR1rAF3cGFjelxQSJphuaHy1F26KzNjIInnP1Tq9SwT+if9KVGmmRJYXn
# LMN+m3qTNN2+NSfWR5wzfVMXMM/e4w0+fnoC7RN79xM1OFKitCFlEKNhXz7pa5NI
# RuNAMydrHEuXdnGeGl2m5cAts4k/W6Yij3TYv4+Tv4JIrHLVEjDfaRZ6pwAVU/oi
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAULDkmNIU8mEIZFfOMXwc6MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPEK5pYr/oiP
# 6zXDh72ZtLHO5VLyj1aDMXhTjDbbSs4wMA0GCSqGSIb3DQEBAQUABIIBACzySQoQ
# 5QAIvyHDiDpkZ0rsHh1SNvFhDlhXtbyffeFVIAB1tI4/z6VPdlXs6/+Qu1Ei6TDk
# cQzwJpDe9aOJsXOvG/Qmu8tsnQ4O0x8c08auA7HluHIQbk4Csf7qe69IYxkPStEL
# WHgwhzluk/HXaROz1Nra4VCZUTWBL5IZwf7UiN7ne8A53paT4NGONbnKVlZfm4ZT
# v65W7rG2J0T3UPuJZgpRygB0jjoJ2V3PhgrtsSFXmRdVg/hI5AWQv/KDiLb9YF80
# H3Yy86YnKRw7FmPngs8jmzbNVYAgH+q9/eS3yULyp/Bpc0LNBiYwBP11zIAAYKiC
# JiOvZNMve3QICyw=
# SIG # End signature block
