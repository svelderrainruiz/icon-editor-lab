# Redaction.ps1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Write-LogSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Message,
        [Parameter()][ValidateSet('INFO','WARN','ERROR')][string]$Level = 'INFO'
    )
    # Redact common secret/token patterns (simple heuristic)
    $msg = $Message -replace '([A-Za-z0-9-_]{20,})','****' `
                    -replace '(?i)(secret|token|password)\s*[:=]\s*[^ \t\r\n]+','$1=****'
    $ts = (Get-Date).ToString('s')
    Write-Output "[$ts][$Level] $msg"
}
if ($ExecutionContext.SessionState.Module) {
    Export-ModuleMember -Function Write-LogSafe
}

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCB5QE8/zfwZTTR5
# g9if2C7NwESBApxi1XkQIcw6fBWi3aCCAxYwggMSMIIB+qADAgECAhAULDkmNIU8
# mEIZFfOMXwc6MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEyMjIxMjA1WhcNMjUxMTI2MjIyMjA1WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAx165pbQ/eUkiiEfR+jiVeuaLhqQJcDOw9y5Fu6BrNwUg
# LU6lYXuWgXmtPOR323gL9kEV+N3h9NTENmvkSGWNS2ZGgPHxOODAcsAZnQah2glD
# QSBb9r5g+e/SkzKzymnGRl5IOT+iot2xjTlCOODuRwX/9Fm0skmrjTzdtws+LyfE
# y+eau8wWUeDJnfSBKviayL1U5ctm/UkEtyqIpRG8Uajxj54s3B7UWmv56hY6lQx1
# eUSIxxMpuWKuSiaAKLFrV7i4NcQ8ossLHaBUyJKuiM7fLn3NGl8qzq0qpzby58s7
# xRS25wxIfhOhAHY03lTrYlUkWXL0BmUe6hI2LRFjEQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFFqziKakCPK3
# jRRvz+Af4e8bwQ0bMA0GCSqGSIb3DQEBCwUAA4IBAQCLHlNNLjd0cr0EuQfetHMV
# DPy2R3DUQJ9r9GZz0H0vzTvFYdJn4+skFA2q74dhjrLJkDyf9HuU7Sb+4stXxZ3G
# dH4fNpvRSCbSjhgzUJo7XOxU7q/Bxhz2OqMWJ+uEJYFyIKNIh8lXoQkIeYWKOPmD
# Loj3R3XwR1rAF3cGFjelxQSJphuaHy1F26KzNjIInnP1Tq9SwT+if9KVGmmRJYXn
# LMN+m3qTNN2+NSfWR5wzfVMXMM/e4w0+fnoC7RN79xM1OFKitCFlEKNhXz7pa5NI
# RuNAMydrHEuXdnGeGl2m5cAts4k/W6Yij3TYv4+Tv4JIrHLVEjDfaRZ6pwAVU/oi
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAULDkmNIU8mEIZFfOMXwc6MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIEfHLCIlw9Py
# EI3fUHQlFhw4tq7Q+oRZQIlIetQ/aFBMMA0GCSqGSIb3DQEBAQUABIIBAJ7EZkbt
# qG/zozzEMfCbbkFUm84oB4TojIpzJs+T6COBe6Y+TaC0UgRK8WOmj+p8FcJDNblY
# nu2UTxid37Ui8tjxJgm4YAzA1PXDcN9/8qxPBYYRGlZz1YkrkTu5Px4EbWev5LlZ
# jIPXfzEiTs8/Wc+ymFPjDfnSEDN4hXE7PS1zQ1+L5TrNUXHkErogKZb+BPySiRHn
# 1rVjkHeTP9/v0cNtaBEZtpKtTmVU7nlkda+Z4GHVmr9TNr4SirP25YlGwDvAUGW7
# 03+DlyxT3I+YUFI13Y8OxCAaKv0gP6TBvALwfAkItMpZhKsa+Kf5a+Tv2jjZmZ6G
# klqYhdG2JoENsRo=
# SIG # End signature block
