#Requires -Version 7.0
<#
.SYNOPSIS
  Consistent entry point for running the repository's Pester suite.

.DESCRIPTION
  Loads tests/Pester.runsettings.psd1, applies optional tag/exclude filters,
  and runs Invoke-Pester. When -CI is specified, writes JUnit output under
  out/test-results/pester.xml (creating the folder if needed).

.PARAMETER Tag
  Only run tests tagged with any of the specified values.

.PARAMETER ExcludeTag
  Skip tests tagged with any of the specified values.

.PARAMETER CI
  Enables JUnit output to out/test-results/pester.xml.
#>

[CmdletBinding()]
param(
  [string[]]$Tag,
  [string[]]$ExcludeTag,
  [switch]$CI
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repoRoot = Resolve-Path (Join-Path $PSScriptRoot '..')
$configPath = Join-Path $repoRoot 'tests' 'Pester.runsettings.psd1'
if (-not (Test-Path $configPath)) {
  throw "Pester configuration not found: $configPath"
}

$config = Import-PowerShellDataFile -LiteralPath $configPath

# Normalize relative paths based on repo root
$config.Run.Path = @(
  $config.Run.Path | ForEach-Object {
    (Resolve-Path (Join-Path $repoRoot $_)).ProviderPath
  }
)
$resolvedResultPath = Resolve-Path (Join-Path $repoRoot $config.TestResult.OutputPath) -ErrorAction SilentlyContinue
if ($resolvedResultPath) {
  $config.TestResult.OutputPath = $resolvedResultPath.ProviderPath
} else {
  $config.TestResult.OutputPath = Join-Path $repoRoot 'out/test-results/pester.xml'
}
if (-not $config.TestResult.OutputPath) {
  $config.TestResult.OutputPath = Join-Path $repoRoot 'out/test-results/pester.xml'
}

if ($Tag) {
  $config.Filter.Tag = @($Tag)
}
if ($ExcludeTag) {
  $config.Filter.ExcludeTag = @($ExcludeTag)
}

if ($CI) {
  $resultsPath = $config.TestResult.OutputPath
  $resultsDir = Split-Path $resultsPath -Parent
  if (-not (Test-Path $resultsDir)) { New-Item -ItemType Directory -Path $resultsDir -Force | Out-Null }
  $config.TestResult.Enabled = $true
  Write-Host "CI mode: writing Pester results to $resultsPath"
} else {
  $config.TestResult.Enabled = $false
}

Write-Host "Invoking Pester with tags: $($config.Filter.Tag -join ', ')" -ForegroundColor Cyan
Invoke-Pester -Configuration $config

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDYd2uoPAkTXPJb
# bn+j5BoktSlFrWLc2tx3vJ8l5hj/eaCCAxYwggMSMIIB+qADAgECAhAULDkmNIU8
# mEIZFfOMXwc6MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEyMjIxMjA1WhcNMjUxMTI2MjIyMjA1WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAx165pbQ/eUkiiEfR+jiVeuaLhqQJcDOw9y5Fu6BrNwUg
# LU6lYXuWgXmtPOR323gL9kEV+N3h9NTENmvkSGWNS2ZGgPHxOODAcsAZnQah2glD
# QSBb9r5g+e/SkzKzymnGRl5IOT+iot2xjTlCOODuRwX/9Fm0skmrjTzdtws+LyfE
# y+eau8wWUeDJnfSBKviayL1U5ctm/UkEtyqIpRG8Uajxj54s3B7UWmv56hY6lQx1
# eUSIxxMpuWKuSiaAKLFrV7i4NcQ8ossLHaBUyJKuiM7fLn3NGl8qzq0qpzby58s7
# xRS25wxIfhOhAHY03lTrYlUkWXL0BmUe6hI2LRFjEQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFFqziKakCPK3
# jRRvz+Af4e8bwQ0bMA0GCSqGSIb3DQEBCwUAA4IBAQCLHlNNLjd0cr0EuQfetHMV
# DPy2R3DUQJ9r9GZz0H0vzTvFYdJn4+skFA2q74dhjrLJkDyf9HuU7Sb+4stXxZ3G
# dH4fNpvRSCbSjhgzUJo7XOxU7q/Bxhz2OqMWJ+uEJYFyIKNIh8lXoQkIeYWKOPmD
# Loj3R3XwR1rAF3cGFjelxQSJphuaHy1F26KzNjIInnP1Tq9SwT+if9KVGmmRJYXn
# LMN+m3qTNN2+NSfWR5wzfVMXMM/e4w0+fnoC7RN79xM1OFKitCFlEKNhXz7pa5NI
# RuNAMydrHEuXdnGeGl2m5cAts4k/W6Yij3TYv4+Tv4JIrHLVEjDfaRZ6pwAVU/oi
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAULDkmNIU8mEIZFfOMXwc6MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEII11SC6wt7Xz
# Nju6w2mLIcqzI70/iCgkEho6gi7yzw2NMA0GCSqGSIb3DQEBAQUABIIBAMO0jEoy
# o7E5+hjRI4Sfxsqh8Xk8iigsaJT0dsREET4exg5pj8Unf+Ae1XIV8eDhYfCWjHaa
# OlEPRmLGNk654qh5gF2BMYJi3+uW6eO5BAkRgM0QovjlwP9qbYp+WgGVyiDja9rb
# VQ1jIHXaquT1QsKApQ514W5Ksxf0IHxGRR3UcTpVbQjXqgXiZ6xRnpRagilK2Hwz
# AVWc/XsATHSxradJ/CXdJbokCIPjJ3gPvCcxfgsZc2MDkUIfQKLQMLKnPSYb9JLq
# lxRmDxxanvO+ANtEc9zz0xxClWQJjdlVIUlXic4lCIV57wKccwtuE2SFmtWv6Uab
# H+i/wPiC5pR9Reo=
# SIG # End signature block
