#Requires -Version 7.0
<#
.SYNOPSIS
  Consistent entry point for running the repository's Pester suite.

.DESCRIPTION
  Loads tests/Pester.runsettings.psd1, applies optional tag/exclude filters,
  and runs Invoke-Pester. When -CI is specified, writes JUnit output under
  out/test-results/pester.xml (creating the folder if needed).

.PARAMETER Tag
  Only run tests tagged with any of the specified values.

.PARAMETER ExcludeTag
  Skip tests tagged with any of the specified values.

.PARAMETER CI
  Enables JUnit output to out/test-results/pester.xml.
#>

[CmdletBinding()]
param(
  [string[]]$Tag,
  [string[]]$ExcludeTag,
  [switch]$CI
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repoRoot = Resolve-Path (Join-Path $PSScriptRoot '..')
$configPath = Join-Path $repoRoot 'tests' 'Pester.runsettings.psd1'
if (-not (Test-Path $configPath)) {
  throw "Pester configuration not found: $configPath"
}

$config = Import-PowerShellDataFile -LiteralPath $configPath

# Normalize relative paths based on repo root
$config.Run.Path = @(
  $config.Run.Path | ForEach-Object {
    (Resolve-Path (Join-Path $repoRoot $_)).ProviderPath
  }
)
$resolvedResultPath = Resolve-Path (Join-Path $repoRoot $config.TestResult.OutputPath) -ErrorAction SilentlyContinue
if ($resolvedResultPath) {
  $config.TestResult.OutputPath = $resolvedResultPath.ProviderPath
} else {
  $config.TestResult.OutputPath = Join-Path $repoRoot 'out/test-results/pester.xml'
}
if (-not $config.TestResult.OutputPath) {
  $config.TestResult.OutputPath = Join-Path $repoRoot 'out/test-results/pester.xml'
}

if ($Tag) {
  $config.Filter.Tag = @($Tag)
}
if ($ExcludeTag) {
  $config.Filter.ExcludeTag = @($ExcludeTag)
}

if ($CI) {
  $resultsPath = $config.TestResult.OutputPath
  $resultsDir = Split-Path $resultsPath -Parent
  if (-not (Test-Path $resultsDir)) { New-Item -ItemType Directory -Path $resultsDir -Force | Out-Null }
  $config.TestResult.Enabled = $true
  Write-Host "CI mode: writing Pester results to $resultsPath"
} else {
  $config.TestResult.Enabled = $false
}

Write-Host "Invoking Pester with tags: $($config.Filter.Tag -join ', ')" -ForegroundColor Cyan
Invoke-Pester -Configuration $config

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDYd2uoPAkTXPJb
# bn+j5BoktSlFrWLc2tx3vJ8l5hj/eaCCAxYwggMSMIIB+qADAgECAhBMl7RsVhwN
# kkJ2ReeGmLNFMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEyMjIxMzQwWhcNMjUxMTI2MjIyMzQwWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA4jNPC2qunGENhu9BwN2qiNDAkgtphuYeoETVh1VVMrZt
# 0C2hEpIbiPkEKvEi0TvF1c1DExQhjUZx1hr5ptg7JsDerxBRqdrmDb9MaENstPpM
# H8Mh52K3pY0AKkh1VpWoA6O4tWIXykPpULOs8qWQHu3k33iqFxz88JBRNZvON54A
# Zy8yJ5MudfrPKr1t8PbhR5uXnulJidknzclKBQNAL7CYjrlMuk30HnG6jfuboeNT
# cmrswfnn3Am8L3wVsvmWWcOWEiuLvL4yGnpbvUNEVYzC2lH6dBT5i3Fucz2He47e
# k0kBGSl+FbryrqvEsjWs4tmzOgrpaVng9e12VOjIBQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFBBkQcJF+R+Q
# WB4BBfFxX04MWWj7MA0GCSqGSIb3DQEBCwUAA4IBAQCDKbxRmQ+JAXYbEVNYZKWA
# 4X0d3UGWwh1rQ7bXLuijNM1t040vJ1Chlj8jgKbe1k9uXcSCZ/m2W3qUpr4+bs7E
# v9K3B+KcH8y9+a2M5/0nSn/GtWaqy0fw+cYmduJEkL1mOyj29SWitVwo88ugOhOb
# zKCoGeYY2XfuZNZHxVEcDmcdZ0z/AbI+jvTigAQFtpntEByMIyUsEEToEx66CHzU
# SrW3QHm4LYlhr0r2DMUONoA9jVik0PcFX3cFOswfbDuURF0IISIgt7uc3+to4hi0
# KMD+o7RcNssbSNRMpOXMMtvvCpaycN7pnipVXZ7294sx068fogcxUr/JyE4PUWkS
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBMl7RsVhwNkkJ2ReeGmLNFMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEII11SC6wt7Xz
# Nju6w2mLIcqzI70/iCgkEho6gi7yzw2NMA0GCSqGSIb3DQEBAQUABIIBAE46vj4s
# gpe91fft0OyIVgTWmNQRkCp9xmiuVgzsfzTOV41qKmTPA+iWMPODMbn5yZkwOa/x
# SDdBdDcbzB51mIFvj+42Hhpn6yqWB+z95PTLx4fLHt0iBaQInh5qA8X/C2KN7DF/
# bLEteY9aKXJ0UjU9YxFfbcItwmnS0t94uzYau+vepFaDI26rPcV5q8PFNUGK9Wy4
# 38OGxSCK3tJdvcheQYuSsaTtttGRRA2Zh4a9vIJDSEEHhwTkvv/H0KMZ5PKs+3+x
# +cXZ5gdJzBZ8dT+EqHVz2sxs3voc79xaX7FUyAsiNNxooEF+TWrAhlV1OmKYaXdF
# YkLWpijKWrUoadk=
# SIG # End signature block
