# EnvGuard.psm1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Get-EnvSnapshot {
    [CmdletBinding()]
    param([string[]]$AllowList = @('PATH','TEMP','TMP','HOME','USERPROFILE'))
    $snap = @{}
    foreach ($name in [Environment]::GetEnvironmentVariables().Keys) {
        if ($AllowList -contains $name) { $snap[$name] = [Environment]::GetEnvironmentVariable($name,'Process') }
    }
    return $snap
}

function Set-EnvFromSnapshot {
    [CmdletBinding()]
    param([Parameter(Mandatory)][hashtable]$Snapshot)
    foreach ($k in $Snapshot.Keys) {
        [Environment]::SetEnvironmentVariable($k, [string]$Snapshot[$k], 'Process')
    }
}

Export-ModuleMember -Function Get-EnvSnapshot, Set-EnvFromSnapshot

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAzwwfWBljXiDkz
# 9AHE9bg618B2oMEor3Mbt2BkcXsxKKCCAxYwggMSMIIB+qADAgECAhBMl7RsVhwN
# kkJ2ReeGmLNFMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEyMjIxMzQwWhcNMjUxMTI2MjIyMzQwWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA4jNPC2qunGENhu9BwN2qiNDAkgtphuYeoETVh1VVMrZt
# 0C2hEpIbiPkEKvEi0TvF1c1DExQhjUZx1hr5ptg7JsDerxBRqdrmDb9MaENstPpM
# H8Mh52K3pY0AKkh1VpWoA6O4tWIXykPpULOs8qWQHu3k33iqFxz88JBRNZvON54A
# Zy8yJ5MudfrPKr1t8PbhR5uXnulJidknzclKBQNAL7CYjrlMuk30HnG6jfuboeNT
# cmrswfnn3Am8L3wVsvmWWcOWEiuLvL4yGnpbvUNEVYzC2lH6dBT5i3Fucz2He47e
# k0kBGSl+FbryrqvEsjWs4tmzOgrpaVng9e12VOjIBQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFBBkQcJF+R+Q
# WB4BBfFxX04MWWj7MA0GCSqGSIb3DQEBCwUAA4IBAQCDKbxRmQ+JAXYbEVNYZKWA
# 4X0d3UGWwh1rQ7bXLuijNM1t040vJ1Chlj8jgKbe1k9uXcSCZ/m2W3qUpr4+bs7E
# v9K3B+KcH8y9+a2M5/0nSn/GtWaqy0fw+cYmduJEkL1mOyj29SWitVwo88ugOhOb
# zKCoGeYY2XfuZNZHxVEcDmcdZ0z/AbI+jvTigAQFtpntEByMIyUsEEToEx66CHzU
# SrW3QHm4LYlhr0r2DMUONoA9jVik0PcFX3cFOswfbDuURF0IISIgt7uc3+to4hi0
# KMD+o7RcNssbSNRMpOXMMtvvCpaycN7pnipVXZ7294sx068fogcxUr/JyE4PUWkS
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBMl7RsVhwNkkJ2ReeGmLNFMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIJlQaYHytxsd
# hJ21/Xd1OOTWhUd4iNiRCRC/DDWxp9vgMA0GCSqGSIb3DQEBAQUABIIBAK8DmDuk
# wGJ2M3X3YnUPUSiD/m/zEwWtNZe+uoKEhbY9QFeD+B2behDwQFDWOnfu9s7pZ6Tm
# vC4d3fEBdQM2yUDxK2I2GyNQZUkB52lUCFTHx3+lGvvM5upEJWnXWWC1HpFOkr9P
# fy/SXzHOX0U5mB6XFHo+kjfvM6t6V94t06Pl1uZHbpUtdk1w+iYqMFy+iVTaL2DB
# YHC2QyKg97EFXoBfSVmliHiXu954VkSy5Ec6GWlBSxgTEPb1/ZUE04WggPkn9660
# L2dlecuP5m+F7PfXlv5lVCIV/IRpfv9WNC6Rx8itUs19dlgaX1JMy8y7XS91sqZk
# iDVJdmY10cHD0Y0=
# SIG # End signature block
