#Requires -Version 7.0
[CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact='High')]
param(
  [string]$Thumbprint,
  [string]$OutDir = (Join-Path -Path $PWD -ChildPath 'out\test-codesign'),
  [string]$PfxPath,
  [switch]$DeleteGhSecrets,
  [string[]]$Environments = @('codesign-dev','codesign-prod'),
  [switch]$Force
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
if (-not $IsWindows) { throw "This script requires Windows." }

function Normalize-Thumb([string]$t) {
  if (-not $t) { return $null }
  ($t -replace '\s','').ToUpperInvariant()
}

function Resolve-PfxAndPassword {
  param([string]$OutDir,[string]$PfxPath)
  $pwdPathCandidates = @(
    (Join-Path $OutDir 'WIN_CODESIGN_PFX_PASSWORD.txt')
  )
  $pfxFile = $null

  if ($PfxPath) {
    if (-not (Test-Path -LiteralPath $PfxPath)) { throw "Specified PFX not found: $PfxPath" }
    $pfxFile = Get-Item -LiteralPath $PfxPath
  } else {
    if (-not (Test-Path -LiteralPath $OutDir)) { return $null }
    $pfxFile = Get-ChildItem -LiteralPath $OutDir -Filter 'test-codesign-*.pfx' -File -ErrorAction SilentlyContinue |
               Sort-Object LastWriteTime -Descending | Select-Object -First 1
  }
  if (-not $pfxFile) { return $null }

  $pwdFile = $pwdPathCandidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
  if (-not $pwdFile) { throw "Password file not found in $OutDir (expected WIN_CODESIGN_PFX_PASSWORD.txt)." }

  [pscustomobject]@{
    PfxPath = $pfxFile.FullName
    Password = (Get-Content -LiteralPath $pwdFile -Raw)
  }
}

function Resolve-Thumbprint {
  param([string]$Thumbprint,[string]$OutDir,[string]$PfxPath)
  $t = Normalize-Thumb $Thumbprint
  if ($t) { return $t }

  $p = Resolve-PfxAndPassword -OutDir $OutDir -PfxPath $PfxPath
  if (-not $p) { return $null }

  try {
    $bytes = [IO.File]::ReadAllBytes($p.PfxPath)
    $cert  = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2
    $cert.Import($bytes, $p.Password,
      [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::EphemeralKeySet)
    return (Normalize-Thumb $cert.Thumbprint)
  } catch {
    throw "Failed to derive thumbprint from PFX '$($p.PfxPath)': $($_.Exception.Message)"
  }
}

$resolvedThumb = Resolve-Thumbprint -Thumbprint $Thumbprint -OutDir $OutDir -PfxPath $PfxPath
if (-not $resolvedThumb) {
  throw "Could not resolve a certificate thumbprint. Provide -Thumbprint, or ensure $OutDir has a 'test-codesign-*.pfx' and 'WIN_CODESIGN_PFX_PASSWORD.txt'."
}

# --- Remove certificate from CurrentUser\My ---
$certPath = "Cert:\\CurrentUser\\My\\$resolvedThumb"
$removedCert = $false
if (Test-Path -LiteralPath $certPath) {
  if ($PSCmdlet.ShouldProcess("Delete certificate $resolvedThumb from CurrentUser\\My", "Remove-Item $certPath")) {
    try {
      Remove-Item -LiteralPath $certPath -Force
      $removedCert = $true
    } catch {
      # Fallback to certutil
      try {
        & certutil -user -delstore My $resolvedThumb | Out-Null
        $removedCert = $true
      } catch {
        Write-Warning "Failed to delete cert $resolvedThumb from store: $($_.Exception.Message)"
      }
    }
  }
} else {
  Write-Host "No matching cert in CurrentUser\\My (thumbprint $resolvedThumb)."
}

# --- Collect files to delete ---
$files = @()

if ($PfxPath -and (Test-Path -LiteralPath $PfxPath)) {
  $files += (Get-Item -LiteralPath $PfxPath).FullName
} elseif (Test-Path -LiteralPath $OutDir) {
  $files += (Get-ChildItem -LiteralPath $OutDir -Filter 'test-codesign-*.pfx' -File -ErrorAction SilentlyContinue |
             Select-Object -ExpandProperty FullName)
}

$sidecars = @(
  (Join-Path $OutDir 'WIN_CODESIGN_PFX_B64.txt'),
  (Join-Path $OutDir 'WIN_CODESIGN_PFX_PASSWORD.txt'),
  (Join-Path $OutDir 'test-codesign.pfx.b64'),
  (Join-Path $OutDir 'secrets.json'),
  (Join-Path $OutDir 'secrets.env')
)
$files += ($sidecars | Where-Object { Test-Path -LiteralPath $_ })

$files = $files | Select-Object -Unique

# --- Delete files ---
$deleted = New-Object System.Collections.Generic.List[string]
foreach ($f in $files) {
  if ($PSCmdlet.ShouldProcess("Delete file", $f)) {
    try {
      Remove-Item -LiteralPath $f -Force:$Force -ErrorAction Stop
      $deleted.Add($f) | Out-Null
    } catch {
      Write-Warning "Failed to delete $f: $($_.Exception.Message)"
    }
  }
}

# --- Optionally delete env secrets with gh ---
$secretsDeleted = @()
if ($DeleteGhSecrets) {
  if (-not (Get-Command gh -ErrorAction SilentlyContinue)) {
    Write-Warning "gh CLI not found; skipping environment secret deletion."
  } else {
    $names = @('WIN_CODESIGN_PFX_B64','WIN_CODESIGN_PFX_PASSWORD')
    foreach ($envName in $Environments) {
      foreach ($n in $names) {
        if ($PSCmdlet.ShouldProcess("Delete env secret", "$n (env=$envName)")) {
          try {
            $p = Start-Process -FilePath "gh" -ArgumentList @("secret","delete",$n,"--env",$envName,"--yes") `
                               -NoNewWindow -PassThru -Wait
            if ($p.ExitCode -eq 0) { $secretsDeleted += "$envName/$n" }
          } catch {
            Write-Warning "Failed to delete secret $n in env $envName: $($_.Exception.Message)"
          }
        }
      }
    }
  }
}

# --- Summary ---
Write-Host ""
Write-Host "Cleanup summary" -ForegroundColor Cyan
Write-Host ("  Thumbprint removed from store : {0}" -f ($removedCert ? $resolvedThumb : 'not found / not removed'))
if ($deleted.Count -gt 0) {
  Write-Host "  Files deleted:"; $deleted | ForEach-Object { Write-Host "    - $_" }
} else {
  Write-Host "  Files deleted: (none)"
}
if ($DeleteGhSecrets) {
  if ($secretsDeleted.Count -gt 0) {
    Write-Host "  Env secrets deleted:"; $secretsDeleted | ForEach-Object { Write-Host "    - $_" }
  } else {
    Write-Host "  Env secrets deleted: (none)"
  }
}


# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCC9+YAS6eyMazrc
# OORVNfBB8W9nXf2463upesKl4YoPNKCCAxYwggMSMIIB+qADAgECAhBMl7RsVhwN
# kkJ2ReeGmLNFMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEyMjIxMzQwWhcNMjUxMTI2MjIyMzQwWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA4jNPC2qunGENhu9BwN2qiNDAkgtphuYeoETVh1VVMrZt
# 0C2hEpIbiPkEKvEi0TvF1c1DExQhjUZx1hr5ptg7JsDerxBRqdrmDb9MaENstPpM
# H8Mh52K3pY0AKkh1VpWoA6O4tWIXykPpULOs8qWQHu3k33iqFxz88JBRNZvON54A
# Zy8yJ5MudfrPKr1t8PbhR5uXnulJidknzclKBQNAL7CYjrlMuk30HnG6jfuboeNT
# cmrswfnn3Am8L3wVsvmWWcOWEiuLvL4yGnpbvUNEVYzC2lH6dBT5i3Fucz2He47e
# k0kBGSl+FbryrqvEsjWs4tmzOgrpaVng9e12VOjIBQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFBBkQcJF+R+Q
# WB4BBfFxX04MWWj7MA0GCSqGSIb3DQEBCwUAA4IBAQCDKbxRmQ+JAXYbEVNYZKWA
# 4X0d3UGWwh1rQ7bXLuijNM1t040vJ1Chlj8jgKbe1k9uXcSCZ/m2W3qUpr4+bs7E
# v9K3B+KcH8y9+a2M5/0nSn/GtWaqy0fw+cYmduJEkL1mOyj29SWitVwo88ugOhOb
# zKCoGeYY2XfuZNZHxVEcDmcdZ0z/AbI+jvTigAQFtpntEByMIyUsEEToEx66CHzU
# SrW3QHm4LYlhr0r2DMUONoA9jVik0PcFX3cFOswfbDuURF0IISIgt7uc3+to4hi0
# KMD+o7RcNssbSNRMpOXMMtvvCpaycN7pnipVXZ7294sx068fogcxUr/JyE4PUWkS
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBMl7RsVhwNkkJ2ReeGmLNFMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIHdtx8lNxvdE
# GwQraeAY4Y6icbWBMysq/r8X9ubdHLmOMA0GCSqGSIb3DQEBAQUABIIBAA+acZ1W
# uNDhwLmSdSU3k/QJ1Qq+eMooCXuzcHPd4O5NmPY/LrrNcsY/Lrsm/hGzJ5qUbkHe
# l3ofrWMKqyQvGw0NumcxgHJ4k/NosJZKG0GJXpYpC37XwWzhQdtHqN0Ct8y4LWUQ
# 7NEwSDB9y+zPRMdKyWSyGgn/cALdqJ9I6JbWptTC2LqY6JtS5Zlm9t+DjE+22jO5
# 5UnjAnKpOCBjGFHyn5FUdFrwGTfsqRkeqt2otq/p29nctBqJqAdsGMOQVzKOxtq0
# 7XdD87cr4+bPk2m+FKaTk+tDC++aN1vcJbatALIh8i7pusdb3Pb+QgALtu/w1H6W
# L0h2yQZ1fG4OEkw=
# SIG # End signature block
