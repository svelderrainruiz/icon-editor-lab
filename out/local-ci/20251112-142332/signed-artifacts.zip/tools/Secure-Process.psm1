# Secure-Process.psm1
Set-StrictMode -Version Latest
. (Join-Path $PSScriptRoot 'Validate-Paths.ps1')
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Invoke-ProcessSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$FilePath,
        [Parameter()][string[]]$ArgumentList = @(),
        [Parameter()][int]$TimeoutSec = 600,
        [Parameter()][string]$WorkingDirectory = (Get-Location).Path
    )
    if (-not (Test-Path -LiteralPath $FilePath -PathType Leaf)) { throw "FilePath not found: $FilePath" }
    $psi = [System.Diagnostics.ProcessStartInfo]::new()
    $psi.FileName = $FilePath
    $psi.WorkingDirectory = (Validate-PathSafe -Path $WorkingDirectory)
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.UseShellExecute = $false
    foreach ($a in $ArgumentList) { $null = $psi.ArgumentList.Add($a) }

    $p = [System.Diagnostics.Process]::new()
    $p.StartInfo = $psi
    if (-not $p.Start()) { throw "Failed to start process: $FilePath" }
    try {
        if (-not $p.WaitForExit($TimeoutSec * 1000)) {
            try { $p.Kill($true) } catch {}
            throw "Process timed out after $TimeoutSec s: $FilePath"
        }
        $stdout = $p.StandardOutput.ReadToEnd()
        $stderr = $p.StandardError.ReadToEnd()
        return [pscustomobject]@{
            ExitCode = $p.ExitCode
            StdOut = $stdout
            StdErr = $stderr
        }
    } finally {
        if (-not $p.HasExited) { try { $p.Kill($true) } catch {} }
        $p.Dispose()
    }
}
Export-ModuleMember -Function Invoke-ProcessSafe

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDLM/hZ77J6ko3k
# J1T1SnSI3Zjg9T8EF5sOyyHIvgXLgqCCAxYwggMSMIIB+qADAgECAhBMl7RsVhwN
# kkJ2ReeGmLNFMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEyMjIxMzQwWhcNMjUxMTI2MjIyMzQwWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA4jNPC2qunGENhu9BwN2qiNDAkgtphuYeoETVh1VVMrZt
# 0C2hEpIbiPkEKvEi0TvF1c1DExQhjUZx1hr5ptg7JsDerxBRqdrmDb9MaENstPpM
# H8Mh52K3pY0AKkh1VpWoA6O4tWIXykPpULOs8qWQHu3k33iqFxz88JBRNZvON54A
# Zy8yJ5MudfrPKr1t8PbhR5uXnulJidknzclKBQNAL7CYjrlMuk30HnG6jfuboeNT
# cmrswfnn3Am8L3wVsvmWWcOWEiuLvL4yGnpbvUNEVYzC2lH6dBT5i3Fucz2He47e
# k0kBGSl+FbryrqvEsjWs4tmzOgrpaVng9e12VOjIBQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFBBkQcJF+R+Q
# WB4BBfFxX04MWWj7MA0GCSqGSIb3DQEBCwUAA4IBAQCDKbxRmQ+JAXYbEVNYZKWA
# 4X0d3UGWwh1rQ7bXLuijNM1t040vJ1Chlj8jgKbe1k9uXcSCZ/m2W3qUpr4+bs7E
# v9K3B+KcH8y9+a2M5/0nSn/GtWaqy0fw+cYmduJEkL1mOyj29SWitVwo88ugOhOb
# zKCoGeYY2XfuZNZHxVEcDmcdZ0z/AbI+jvTigAQFtpntEByMIyUsEEToEx66CHzU
# SrW3QHm4LYlhr0r2DMUONoA9jVik0PcFX3cFOswfbDuURF0IISIgt7uc3+to4hi0
# KMD+o7RcNssbSNRMpOXMMtvvCpaycN7pnipVXZ7294sx068fogcxUr/JyE4PUWkS
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBMl7RsVhwNkkJ2ReeGmLNFMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPEK5pYr/oiP
# 6zXDh72ZtLHO5VLyj1aDMXhTjDbbSs4wMA0GCSqGSIb3DQEBAQUABIIBAE0sIF36
# rJFC7mjb7E84J1ODfed4KGIrPAUtUINKVfBcIiRs0XdNCLXzor2rpQVk+mC6ZeF4
# +DqZLl+368laJhRmLamX5glho845ncE0fQ+pDCg1BZux2ypRwLkTlxJ4xouO1FZ0
# WlgZU8pAko+pmDl4pkqCyS9hycWClqtPH8RgQDlpPi8w0LshdUBHwztvL/QYXlFI
# ZCaXfpG8Y95xqHOJY+NxOx1olMHE05w8u4Dffa93JJ/6yeHay8HuGk3k0JzY/M+s
# +sMsrNKltITVX9Zk1UMwaum9DlYxXFm9GfqqypSk45LTSdUBDIww0kE808EJvGsU
# jhkPsumyMJ1zAf4=
# SIG # End signature block
