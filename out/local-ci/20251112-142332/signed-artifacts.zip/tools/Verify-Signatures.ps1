# Verify-Signatures.ps1
[CmdletBinding()]
param(
  [Parameter()][string]$SearchRoot = (Get-Location).Path,
  [Parameter()][string[]]$Include = @("*.ps1","*.psm1"),
  [Parameter()][string[]]$ExcludeDirs = @(".git",".github",".venv","node_modules")
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'
$files = Get-ChildItem -LiteralPath $SearchRoot -Recurse -File -Include $Include | Where-Object {
  $rel = $_.FullName.Substring($SearchRoot.Length).TrimStart('\','/')
  -not ($ExcludeDirs | ForEach-Object { $rel -like ("{0}\*" -f $_) })
}
$bad = @()
foreach ($f in $files) {
  $sig = Get-AuthenticodeSignature -LiteralPath $f.FullName
  if ($sig.Status -ne 'Valid') { $bad += [pscustomobject]@{ Path = $f.FullName; Status = $sig.Status } }
}
if ($bad.Count -gt 0) {
  $bad | Format-Table -AutoSize | Out-String | Write-Output
  throw "Signature check failed for $($bad.Count) file(s)."
}
Write-Output "All script signatures are VALID."

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDA5chJevy6MGSV
# tHJMuyIwbEkqLQdD7aRYKil20DYfiaCCAxYwggMSMIIB+qADAgECAhBMl7RsVhwN
# kkJ2ReeGmLNFMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEyMjIxMzQwWhcNMjUxMTI2MjIyMzQwWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA4jNPC2qunGENhu9BwN2qiNDAkgtphuYeoETVh1VVMrZt
# 0C2hEpIbiPkEKvEi0TvF1c1DExQhjUZx1hr5ptg7JsDerxBRqdrmDb9MaENstPpM
# H8Mh52K3pY0AKkh1VpWoA6O4tWIXykPpULOs8qWQHu3k33iqFxz88JBRNZvON54A
# Zy8yJ5MudfrPKr1t8PbhR5uXnulJidknzclKBQNAL7CYjrlMuk30HnG6jfuboeNT
# cmrswfnn3Am8L3wVsvmWWcOWEiuLvL4yGnpbvUNEVYzC2lH6dBT5i3Fucz2He47e
# k0kBGSl+FbryrqvEsjWs4tmzOgrpaVng9e12VOjIBQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFBBkQcJF+R+Q
# WB4BBfFxX04MWWj7MA0GCSqGSIb3DQEBCwUAA4IBAQCDKbxRmQ+JAXYbEVNYZKWA
# 4X0d3UGWwh1rQ7bXLuijNM1t040vJ1Chlj8jgKbe1k9uXcSCZ/m2W3qUpr4+bs7E
# v9K3B+KcH8y9+a2M5/0nSn/GtWaqy0fw+cYmduJEkL1mOyj29SWitVwo88ugOhOb
# zKCoGeYY2XfuZNZHxVEcDmcdZ0z/AbI+jvTigAQFtpntEByMIyUsEEToEx66CHzU
# SrW3QHm4LYlhr0r2DMUONoA9jVik0PcFX3cFOswfbDuURF0IISIgt7uc3+to4hi0
# KMD+o7RcNssbSNRMpOXMMtvvCpaycN7pnipVXZ7294sx068fogcxUr/JyE4PUWkS
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBMl7RsVhwNkkJ2ReeGmLNFMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIIEZpCeYMGc2
# kHxmC59rnv7kFfu0+1EDOsevLQv84+74MA0GCSqGSIb3DQEBAQUABIIBAM8zhE9F
# hFMdmlvIbw4VqYyhtsZjZeoaVxUFZ+/UJWjOtYInxZ5kUlwV7APaa6orlUSlOxmv
# ohM2dVi7Sm/YIgOZjWMEydJZeFfnNTFyLhUje2VHdyYWYCFr7ofuRLR5VWBVQkBv
# NTK1kmvFkaMXtrYv3Ho2w9lDhkXTjlAPbZpH3QmoVgN82p+ryeOgxnifa6rkKKsi
# 6evA1Sz68a23kA5B0Ut9eNO7EteZJRwPi3wf7NoqLnTCon4REP4StitIwFH646yc
# 8Ohr4etfJPzZbXso4HPrXrHTKyhGoObg0de0GN8kJu4BAeSHpe056efyTqMFtLwK
# luYNjM1mqHneg2k=
# SIG # End signature block
