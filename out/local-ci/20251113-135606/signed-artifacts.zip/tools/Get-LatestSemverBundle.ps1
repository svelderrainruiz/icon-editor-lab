#Requires -Version 7.0
[CmdletBinding()]
param(
    [string]$Root = 'out/semver-bundle'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$rootPath = [System.IO.Path]::GetFullPath($Root)
if (-not (Test-Path -LiteralPath $rootPath -PathType Container)) {
    throw "[SVB300] No SemVer bundles found under $rootPath"
}

$bundle = Get-ChildItem -LiteralPath $rootPath -Directory | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $bundle) {
    throw "[SVB300] No SemVer bundles found under $rootPath"
}

$summaryPath = Join-Path $bundle.FullName 'semver-summary.json'
$summary = $null
if (Test-Path -LiteralPath $summaryPath -PathType Leaf) {
    try {
        $summary = Get-Content -LiteralPath $summaryPath -Raw | ConvertFrom-Json -ErrorAction Stop
    } catch {
        Write-Warning ("[SVB202] Failed to read summary JSON: {0}" -f $_.Exception.Message)
    }
}

[pscustomobject]@{
    BundleRoot = $bundle.FullName
    ZipPath    = "$($bundle.FullName).zip"
    Summary    = $summary
}

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDX1yHpgv4n6QSq
# t5kkJikX+boV/u0FrptEuQebx9o3l6CCAxYwggMSMIIB+qADAgECAhBdQYHkWOx+
# qk0MB91GKqk0MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMjE0NzAxWhcNMjUxMTI3MjE1NzAxWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAr4Vp44wx8qO3r/9IArt2tVXFNj65Qi5BP9Ku+q9bNVDu
# LEKReQGmN6KJAQgcHgImBu1uIKZrtzPyKawiVa6GUPp4CUN+Vzw27+/F4S2W0+Lo
# xZyY/jAPqnzEBCE8/ywFk5Dyf9GBU/pEaujGVQo+NhrBCdHcsUHzzVRvUO2U454b
# xnrcJQx4Kk11dyBnd/6SHXSAtimAERjGC9drx81RZZSnJqaN0ENNpbn5UJVJJpik
# PGetE1sPdVxG7D8jz8D2tXUZCbY8qvQrHe14tBWt8jVvJiw9iQSWwQcvWbuqMUvm
# mGKq4gVswF3Ro5RFLxFqD2oL3aQx/+GLe23/xuAzUQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFLms5F46lx4o
# 55pJ9VNgM28cGnqVMA0GCSqGSIb3DQEBCwUAA4IBAQB+3/BlO+FgbnaLZKSoHa3q
# uDeSVeMGYZpBHpVfVoljdlf/yNsYfo8DGPXzZFbMMrPs/cnJH1A6XMeTedI+UtIb
# jx9fTLaonAsCzHM3BrcPMq+YariKH+T5eOQvketknEWImaJp9VSX+bJ1NuZFUOP0
# JgTG5uUFMtpsDpXVPbbUeeWDKq60Ob3GzKpbJFr5UX9StotB+lMf6aknb7Wu1TsV
# /wZTkEj8H2eZKH4XdMHBd+EyTPyLaLCcZoG3P3950WAwHCn8otWYr6sYrO64H7C4
# AnupAMnabiKnwp6n/WBYJSHIaN6QyZsMMFivNbSfVhh/EubI88sjS1LOIBCsID32
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBdQYHkWOx+qk0MB91GKqk0MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIEYBD5Y3r8tS
# z19YGGp/FTByrUm5EHI8CkcR3OTA0txvMA0GCSqGSIb3DQEBAQUABIIBAD+GnZb4
# 0xWiGTikCdfV124yF6+dQoxnYtvbF311a3zRzgjdcz7kPbNos4VpKQNRdi1aiu2s
# msBCuXQjeJpP9F2Owvg+AnM29izJJJQ2J7uL+NhA/aLmn0Yp2RuXKGrcmklGXRor
# 4lsk28GF+ch8BGqNEQbmPooqvrKbMM7MOL05YEJ4MEv8t60gNLhwHfR81Z/oXdu0
# 7n8SentLvXD6MlGZohaRWnB7GNMeaVU4AAX68RgZY9MhgH+1wrsju/PJ2Mu0U2U5
# V6vvSBEs5ykXL6GBUen0swoVye0A3GrssGjqNL335E+/iz1zeufnau1aJer6/8nM
# 27lXwgZ5cVnriA0=
# SIG # End signature block
