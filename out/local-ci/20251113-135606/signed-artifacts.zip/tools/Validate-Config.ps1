[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$ConfigPath,
  [Parameter()][string]$SchemaPath = (Join-Path $PSScriptRoot '..' 'configs' 'schema' 'vi-diff-heuristics.schema.json')
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'
. (Join-Path $PSScriptRoot 'Redaction.ps1')
$cfgContent = Get-Content -LiteralPath $ConfigPath -Raw
# Basic JSON validity check
$null = $cfgContent | ConvertFrom-Json -ErrorAction Stop
# Schema validation (if schema exists)
if (Test-Path -LiteralPath $SchemaPath -PathType Leaf) {
  $cfgContent | Test-Json -SchemaFile $SchemaPath -ErrorAction Stop | Out-Null
}
Write-Output "Config validated successfully:" (Resolve-Path -LiteralPath $ConfigPath).Path

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAtM1F8YzQ4xa9F
# 7QuDGJd4jTwMhZsuR+3nhXLiXLTUlKCCAxYwggMSMIIB+qADAgECAhBdQYHkWOx+
# qk0MB91GKqk0MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMjE0NzAxWhcNMjUxMTI3MjE1NzAxWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAr4Vp44wx8qO3r/9IArt2tVXFNj65Qi5BP9Ku+q9bNVDu
# LEKReQGmN6KJAQgcHgImBu1uIKZrtzPyKawiVa6GUPp4CUN+Vzw27+/F4S2W0+Lo
# xZyY/jAPqnzEBCE8/ywFk5Dyf9GBU/pEaujGVQo+NhrBCdHcsUHzzVRvUO2U454b
# xnrcJQx4Kk11dyBnd/6SHXSAtimAERjGC9drx81RZZSnJqaN0ENNpbn5UJVJJpik
# PGetE1sPdVxG7D8jz8D2tXUZCbY8qvQrHe14tBWt8jVvJiw9iQSWwQcvWbuqMUvm
# mGKq4gVswF3Ro5RFLxFqD2oL3aQx/+GLe23/xuAzUQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFLms5F46lx4o
# 55pJ9VNgM28cGnqVMA0GCSqGSIb3DQEBCwUAA4IBAQB+3/BlO+FgbnaLZKSoHa3q
# uDeSVeMGYZpBHpVfVoljdlf/yNsYfo8DGPXzZFbMMrPs/cnJH1A6XMeTedI+UtIb
# jx9fTLaonAsCzHM3BrcPMq+YariKH+T5eOQvketknEWImaJp9VSX+bJ1NuZFUOP0
# JgTG5uUFMtpsDpXVPbbUeeWDKq60Ob3GzKpbJFr5UX9StotB+lMf6aknb7Wu1TsV
# /wZTkEj8H2eZKH4XdMHBd+EyTPyLaLCcZoG3P3950WAwHCn8otWYr6sYrO64H7C4
# AnupAMnabiKnwp6n/WBYJSHIaN6QyZsMMFivNbSfVhh/EubI88sjS1LOIBCsID32
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBdQYHkWOx+qk0MB91GKqk0MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPGNlwZgDGGO
# 4eoZqf6qFtcbYyZe5LvdTuTwGIaPVsX8MA0GCSqGSIb3DQEBAQUABIIBAIH2VZRh
# 8u2+3U1mR+h0deC5EBq0lTeRQSyJDNISZwdM/ud1PQ4RK6d/kjY4l9md7hHzeGV+
# +Lyd02DSeDVPpNezb4zAPbktk1d4qhLyIW+Z7yChhpGeJQcVB045w94egVBcKO5R
# LCN4wsbn8TbfTqwj7rLD4LW+/pGOWGEvCFkqeIxGKxYJdn0TLdHsF9HG1F5TdJ4x
# IMxTp86Eb/w0blLnqY66BIGanWGRBeWKAqLoNRpux7XZ/oyPCa2a6mRhDGn38w8P
# XxR9t0dMaIN1IcZoTM2JFg4N22A6a76axt6TrPBvJErKtxiJWesr5U09nji6eAq2
# jYRvHFRZhK5tg6Q=
# SIG # End signature block
