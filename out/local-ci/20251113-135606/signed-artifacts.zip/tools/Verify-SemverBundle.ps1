#Requires -Version 7.0
[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$BundlePath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Resolve-Manifest {
  param([string]$Path)
  if ((Test-Path -LiteralPath $Path -PathType Container)) {
    $candidate = Join-Path $Path 'bundle.json'
    if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) {
      throw "bundle.json not found under $Path"
    }
    return $candidate
  }
  if ((Test-Path -LiteralPath $Path -PathType Leaf) -and $Path.EndsWith('.zip')) {
    $tempDir = New-Item -ItemType Directory -Force -Path (Join-Path $env:TEMP "semver-bundle-$(Get-Random)")
    Expand-Archive -LiteralPath $Path -DestinationPath $tempDir -Force
    $manifest = Join-Path $tempDir 'bundle.json'
    if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) {
      throw "bundle.json missing inside archive $Path"
    }
    return $manifest
  }
  throw "Unsupported bundle path: $Path"
}

$manifestPath = Resolve-Manifest -Path $BundlePath
$bundleRoot = Split-Path -Parent $manifestPath
$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
$failures = @()

foreach ($file in $manifest.files) {
  $fullPath = Join-Path $bundleRoot $file.relativePath
  if (-not (Test-Path -LiteralPath $fullPath -PathType Leaf)) {
    $failures += "Missing file: $($file.relativePath)"
    continue
  }
  $hash = (Get-FileHash -LiteralPath $fullPath -Algorithm SHA256).Hash
  if ($hash -ne $file.sha256) {
    $failures += "Hash mismatch ($($file.relativePath)) expected $($file.sha256) actual $hash"
  }
}

if ($failures.Count -gt 0) {
  Write-Error "Bundle verification failed:" -ErrorAction Stop
}

Write-Host "Bundle verified successfully: $bundleRoot" -ForegroundColor Green

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDjr3yXkH4ndjxr
# 1Y11zhgNRCuKm1tcHCh7s0nCEGFYb6CCAxYwggMSMIIB+qADAgECAhBdQYHkWOx+
# qk0MB91GKqk0MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMjE0NzAxWhcNMjUxMTI3MjE1NzAxWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAr4Vp44wx8qO3r/9IArt2tVXFNj65Qi5BP9Ku+q9bNVDu
# LEKReQGmN6KJAQgcHgImBu1uIKZrtzPyKawiVa6GUPp4CUN+Vzw27+/F4S2W0+Lo
# xZyY/jAPqnzEBCE8/ywFk5Dyf9GBU/pEaujGVQo+NhrBCdHcsUHzzVRvUO2U454b
# xnrcJQx4Kk11dyBnd/6SHXSAtimAERjGC9drx81RZZSnJqaN0ENNpbn5UJVJJpik
# PGetE1sPdVxG7D8jz8D2tXUZCbY8qvQrHe14tBWt8jVvJiw9iQSWwQcvWbuqMUvm
# mGKq4gVswF3Ro5RFLxFqD2oL3aQx/+GLe23/xuAzUQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFLms5F46lx4o
# 55pJ9VNgM28cGnqVMA0GCSqGSIb3DQEBCwUAA4IBAQB+3/BlO+FgbnaLZKSoHa3q
# uDeSVeMGYZpBHpVfVoljdlf/yNsYfo8DGPXzZFbMMrPs/cnJH1A6XMeTedI+UtIb
# jx9fTLaonAsCzHM3BrcPMq+YariKH+T5eOQvketknEWImaJp9VSX+bJ1NuZFUOP0
# JgTG5uUFMtpsDpXVPbbUeeWDKq60Ob3GzKpbJFr5UX9StotB+lMf6aknb7Wu1TsV
# /wZTkEj8H2eZKH4XdMHBd+EyTPyLaLCcZoG3P3950WAwHCn8otWYr6sYrO64H7C4
# AnupAMnabiKnwp6n/WBYJSHIaN6QyZsMMFivNbSfVhh/EubI88sjS1LOIBCsID32
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBdQYHkWOx+qk0MB91GKqk0MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEILQuIDyMgfaK
# B382xHdCDlgpFW4Gkiy8p3BaoHKMRV6AMA0GCSqGSIb3DQEBAQUABIIBACflRIe4
# AS5X5Z8C6FlPysEaee6kt3gsMgCXJcUtcYhzcQ+O2WxfVuD0qCJ+00tilPQbb0su
# eDnjyBSER4jNNLHGPCEDVgWf+Fdh43yEtGNaP6LPS4MQlPpGOd+4xuL4h5Rayksf
# bJkaJ8U7FYVByv93C1uZAvu33CWd8xZ/TAuXv0rDAUe5aXesEmCEOw2utFQBSNIO
# vmoQwcCUY1JDJpdUbtvCbfAkZ+Fy1LBsb+5Ha8k84n7nq4cFocD4cM+AZlW0Uq46
# Etvcg7p8aJNjUf2Iwzcfsk3F9v/9qVwzfOIxiExBPgR8ZyDKMzHecJzcO+1mtLA6
# GcTs1d2AGm3tP3E=
# SIG # End signature block
