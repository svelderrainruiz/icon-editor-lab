#Requires -Version 7.0
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$BundleRoot,
    [switch]$WriteHost
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$bundleRoot = [System.IO.Path]::GetFullPath($BundleRoot)
if (-not (Test-Path -LiteralPath $bundleRoot -PathType Container)) {
    throw "Bundle root not found: $bundleRoot"
}

$summary = [ordered]@{
    schema      = 'icon-editor/semver-bundle-summary@v1'
    generatedAt = (Get-Date).ToString('o')
    bundleRoot  = $bundleRoot
    zipPath     = "$bundleRoot.zip"
    verified    = $true
}

$summaryPath = Join-Path $bundleRoot 'semver-summary.json'
$summary | ConvertTo-Json -Depth 4 | Out-File -FilePath $summaryPath -Encoding UTF8

if ($WriteHost) {
    Write-Host "[SemVerBundle] Summary"
    Write-Host ("  Bundle   : {0}" -f $bundleRoot)
    Write-Host ("  Zip      : {0}" -f "$bundleRoot.zip")
    Write-Host ("  Verified : {0}" -f $true)
    Write-Host ("  Summary  : {0}" -f $summaryPath)
}

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCv9pTtVq1odPNf
# nEfiuPuDX7rgU9AZjAmXsUzNPHHOOqCCAxYwggMSMIIB+qADAgECAhBdQYHkWOx+
# qk0MB91GKqk0MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMjE0NzAxWhcNMjUxMTI3MjE1NzAxWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAr4Vp44wx8qO3r/9IArt2tVXFNj65Qi5BP9Ku+q9bNVDu
# LEKReQGmN6KJAQgcHgImBu1uIKZrtzPyKawiVa6GUPp4CUN+Vzw27+/F4S2W0+Lo
# xZyY/jAPqnzEBCE8/ywFk5Dyf9GBU/pEaujGVQo+NhrBCdHcsUHzzVRvUO2U454b
# xnrcJQx4Kk11dyBnd/6SHXSAtimAERjGC9drx81RZZSnJqaN0ENNpbn5UJVJJpik
# PGetE1sPdVxG7D8jz8D2tXUZCbY8qvQrHe14tBWt8jVvJiw9iQSWwQcvWbuqMUvm
# mGKq4gVswF3Ro5RFLxFqD2oL3aQx/+GLe23/xuAzUQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFLms5F46lx4o
# 55pJ9VNgM28cGnqVMA0GCSqGSIb3DQEBCwUAA4IBAQB+3/BlO+FgbnaLZKSoHa3q
# uDeSVeMGYZpBHpVfVoljdlf/yNsYfo8DGPXzZFbMMrPs/cnJH1A6XMeTedI+UtIb
# jx9fTLaonAsCzHM3BrcPMq+YariKH+T5eOQvketknEWImaJp9VSX+bJ1NuZFUOP0
# JgTG5uUFMtpsDpXVPbbUeeWDKq60Ob3GzKpbJFr5UX9StotB+lMf6aknb7Wu1TsV
# /wZTkEj8H2eZKH4XdMHBd+EyTPyLaLCcZoG3P3950WAwHCn8otWYr6sYrO64H7C4
# AnupAMnabiKnwp6n/WBYJSHIaN6QyZsMMFivNbSfVhh/EubI88sjS1LOIBCsID32
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBdQYHkWOx+qk0MB91GKqk0MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPrmL4l37naI
# cuw6Hk+Z9Z0ioNWA4x/9X43uGcT1cTYyMA0GCSqGSIb3DQEBAQUABIIBAC1NY/a5
# ekG1GYXqnn1QT3UYI/X6/iqpqnl/cMzCdtxkNqHUUPeCNKIiDCwwSuyat9omF5Qq
# +cMAT5E9T8GNpKcTuDeOc97Odp3D4mmYEqjR4v4/Laan/t8BtTLOgNCOSGmBZq1L
# FjX3rkRbsRcw3Hv+XCLig3jo8X+7zYa9HHIoU4ahBh+ZjuhXcBp7vZVULZ6GGr4D
# LF/Xikk4kcJdEb5pj+8ntPA9bTAQU4jTk6OsQRVjNH8Yb6/UjfQ1g4wPLvQr5DYD
# a1Ec/YD11CTw+hHsaDGS3LhgCG7HWwem1YkihkwKyIQBPmt8wwVgOcVEI4ur5z1G
# 10PTNvUPIpQclp4=
# SIG # End signature block
