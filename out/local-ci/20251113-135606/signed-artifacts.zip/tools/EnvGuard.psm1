# EnvGuard.psm1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Get-EnvSnapshot {
    [CmdletBinding()]
    param([string[]]$AllowList = @('PATH','TEMP','TMP','HOME','USERPROFILE'))
    $snap = @{}
    foreach ($name in [Environment]::GetEnvironmentVariables().Keys) {
        if ($AllowList -contains $name) { $snap[$name] = [Environment]::GetEnvironmentVariable($name,'Process') }
    }
    return $snap
}

function Set-EnvFromSnapshot {
    [CmdletBinding()]
    param([Parameter(Mandatory)][hashtable]$Snapshot)
    foreach ($k in $Snapshot.Keys) {
        [Environment]::SetEnvironmentVariable($k, [string]$Snapshot[$k], 'Process')
    }
}

Export-ModuleMember -Function Get-EnvSnapshot, Set-EnvFromSnapshot

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAzwwfWBljXiDkz
# 9AHE9bg618B2oMEor3Mbt2BkcXsxKKCCAxYwggMSMIIB+qADAgECAhBdQYHkWOx+
# qk0MB91GKqk0MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMjE0NzAxWhcNMjUxMTI3MjE1NzAxWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAr4Vp44wx8qO3r/9IArt2tVXFNj65Qi5BP9Ku+q9bNVDu
# LEKReQGmN6KJAQgcHgImBu1uIKZrtzPyKawiVa6GUPp4CUN+Vzw27+/F4S2W0+Lo
# xZyY/jAPqnzEBCE8/ywFk5Dyf9GBU/pEaujGVQo+NhrBCdHcsUHzzVRvUO2U454b
# xnrcJQx4Kk11dyBnd/6SHXSAtimAERjGC9drx81RZZSnJqaN0ENNpbn5UJVJJpik
# PGetE1sPdVxG7D8jz8D2tXUZCbY8qvQrHe14tBWt8jVvJiw9iQSWwQcvWbuqMUvm
# mGKq4gVswF3Ro5RFLxFqD2oL3aQx/+GLe23/xuAzUQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFLms5F46lx4o
# 55pJ9VNgM28cGnqVMA0GCSqGSIb3DQEBCwUAA4IBAQB+3/BlO+FgbnaLZKSoHa3q
# uDeSVeMGYZpBHpVfVoljdlf/yNsYfo8DGPXzZFbMMrPs/cnJH1A6XMeTedI+UtIb
# jx9fTLaonAsCzHM3BrcPMq+YariKH+T5eOQvketknEWImaJp9VSX+bJ1NuZFUOP0
# JgTG5uUFMtpsDpXVPbbUeeWDKq60Ob3GzKpbJFr5UX9StotB+lMf6aknb7Wu1TsV
# /wZTkEj8H2eZKH4XdMHBd+EyTPyLaLCcZoG3P3950WAwHCn8otWYr6sYrO64H7C4
# AnupAMnabiKnwp6n/WBYJSHIaN6QyZsMMFivNbSfVhh/EubI88sjS1LOIBCsID32
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBdQYHkWOx+qk0MB91GKqk0MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIJlQaYHytxsd
# hJ21/Xd1OOTWhUd4iNiRCRC/DDWxp9vgMA0GCSqGSIb3DQEBAQUABIIBACsd/gkV
# N/2Cao2nrxmJLwHGaQPJSavfpFoD+4J9gWRdonvN6YoqDafyVx9O9d0tnKuIBm5+
# t3VrsICteligIxvB7CDX5amq/nkSiRgvV8wbgid8v6LjnAyM7kZGTkUaP40xY3fu
# lopL4KU4YVVn8qIFi306SZqkLj4eQkVpBXMRIfXT9YcbbM7JW90/h948bgISv7XC
# iEe1JWjX5XggEFjkZsupOtUtFPmx5bHBk0+oqnGq4Nr2XC527ctSGYVaG97bPan+
# eVnL8tOAkFJi3ZGjv0FzPcRsaahb9Nkg3wXTO8iE7LKEZ4IKjz0pj2zi7zWPDCcY
# LDi2P9ClsfjD8lY=
# SIG # End signature block
