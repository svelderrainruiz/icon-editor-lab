#Requires -Version 7.0
<#
.SYNOPSIS
  Consistent entry point for running the repository's Pester suite.

.DESCRIPTION
  Loads tests/Pester.runsettings.psd1, applies optional tag/exclude filters,
  and runs Invoke-Pester. When -CI is specified, writes JUnit output under
  out/test-results/pester.xml (creating the folder if needed).

.PARAMETER Tag
  Only run tests tagged with any of the specified values.

.PARAMETER ExcludeTag
  Skip tests tagged with any of the specified values.

.PARAMETER CI
  Enables JUnit output to out/test-results/pester.xml.
#>

[CmdletBinding()]
param(
  [string[]]$Tag,
  [string[]]$ExcludeTag,
  [switch]$CI
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repoRoot = Resolve-Path (Join-Path $PSScriptRoot '..')
$configPath = Join-Path $repoRoot 'tests' 'Pester.runsettings.psd1'
if (-not (Test-Path $configPath)) {
  throw "Pester configuration not found: $configPath"
}

$config = Import-PowerShellDataFile -LiteralPath $configPath

# Normalize relative paths based on repo root
$config.Run.Path = @(
  $config.Run.Path | ForEach-Object {
    (Resolve-Path (Join-Path $repoRoot $_)).ProviderPath
  }
)
$resolvedResultPath = Resolve-Path (Join-Path $repoRoot $config.TestResult.OutputPath) -ErrorAction SilentlyContinue
if ($resolvedResultPath) {
  $config.TestResult.OutputPath = $resolvedResultPath.ProviderPath
} else {
  $config.TestResult.OutputPath = Join-Path $repoRoot 'out/test-results/pester.xml'
}
if (-not $config.TestResult.OutputPath) {
  $config.TestResult.OutputPath = Join-Path $repoRoot 'out/test-results/pester.xml'
}

if ($Tag) {
  $config.Filter.Tag = @($Tag)
}
if ($ExcludeTag) {
  $config.Filter.ExcludeTag = @($ExcludeTag)
}

if ($CI) {
  $resultsPath = $config.TestResult.OutputPath
  $resultsDir = Split-Path $resultsPath -Parent
  if (-not (Test-Path $resultsDir)) { New-Item -ItemType Directory -Path $resultsDir -Force | Out-Null }
  $config.TestResult.Enabled = $true
  Write-Host "CI mode: writing Pester results to $resultsPath"
} else {
  $config.TestResult.Enabled = $false
}

Write-Host "Invoking Pester with tags: $($config.Filter.Tag -join ', ')" -ForegroundColor Cyan
Invoke-Pester -Configuration $config

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDYd2uoPAkTXPJb
# bn+j5BoktSlFrWLc2tx3vJ8l5hj/eaCCAxYwggMSMIIB+qADAgECAhBdQYHkWOx+
# qk0MB91GKqk0MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMjE0NzAxWhcNMjUxMTI3MjE1NzAxWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAr4Vp44wx8qO3r/9IArt2tVXFNj65Qi5BP9Ku+q9bNVDu
# LEKReQGmN6KJAQgcHgImBu1uIKZrtzPyKawiVa6GUPp4CUN+Vzw27+/F4S2W0+Lo
# xZyY/jAPqnzEBCE8/ywFk5Dyf9GBU/pEaujGVQo+NhrBCdHcsUHzzVRvUO2U454b
# xnrcJQx4Kk11dyBnd/6SHXSAtimAERjGC9drx81RZZSnJqaN0ENNpbn5UJVJJpik
# PGetE1sPdVxG7D8jz8D2tXUZCbY8qvQrHe14tBWt8jVvJiw9iQSWwQcvWbuqMUvm
# mGKq4gVswF3Ro5RFLxFqD2oL3aQx/+GLe23/xuAzUQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFLms5F46lx4o
# 55pJ9VNgM28cGnqVMA0GCSqGSIb3DQEBCwUAA4IBAQB+3/BlO+FgbnaLZKSoHa3q
# uDeSVeMGYZpBHpVfVoljdlf/yNsYfo8DGPXzZFbMMrPs/cnJH1A6XMeTedI+UtIb
# jx9fTLaonAsCzHM3BrcPMq+YariKH+T5eOQvketknEWImaJp9VSX+bJ1NuZFUOP0
# JgTG5uUFMtpsDpXVPbbUeeWDKq60Ob3GzKpbJFr5UX9StotB+lMf6aknb7Wu1TsV
# /wZTkEj8H2eZKH4XdMHBd+EyTPyLaLCcZoG3P3950WAwHCn8otWYr6sYrO64H7C4
# AnupAMnabiKnwp6n/WBYJSHIaN6QyZsMMFivNbSfVhh/EubI88sjS1LOIBCsID32
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBdQYHkWOx+qk0MB91GKqk0MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEII11SC6wt7Xz
# Nju6w2mLIcqzI70/iCgkEho6gi7yzw2NMA0GCSqGSIb3DQEBAQUABIIBAEeTv5GJ
# XsYlQ/GjtmgQdxoez7IlIDEzmynB83xKFJkp50Ohko9U4ES+y0JNXwIw/A+8fk36
# E8E0f8oL6jfcHzLuUf6zFogNbdkzKgJrGHSTd2UWYASrH2nUdCnnBr3yx204wfIN
# FyhQNj8bZ2VgRPKre1TJ2eN/pEs+tyHuuYnW5LAHgHKM07RyJYGbg9lLAGOF21tm
# TmnWUDCp8hGXeA7LrBYFVRbR7aCSdImPxtpyPIawlukNxKnQBE+ve5wOUer8dB3s
# v5zOy9BHJBiY8cX7dOMBwRmQWyKXVMc552+annEor78rkaXqXjAStbYYsN8bh0en
# 9lIl6OisUvkNw9Q=
# SIG # End signature block
