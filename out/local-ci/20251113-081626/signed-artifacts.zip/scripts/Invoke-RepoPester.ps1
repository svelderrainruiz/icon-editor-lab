#Requires -Version 7.0
<#
.SYNOPSIS
  Consistent entry point for running the repository's Pester suite.

.DESCRIPTION
  Loads tests/Pester.runsettings.psd1, applies optional tag/exclude filters,
  and runs Invoke-Pester. When -CI is specified, writes JUnit output under
  out/test-results/pester.xml (creating the folder if needed).

.PARAMETER Tag
  Only run tests tagged with any of the specified values.

.PARAMETER ExcludeTag
  Skip tests tagged with any of the specified values.

.PARAMETER CI
  Enables JUnit output to out/test-results/pester.xml.
#>

[CmdletBinding()]
param(
  [string[]]$Tag,
  [string[]]$ExcludeTag,
  [switch]$CI
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repoRoot = Resolve-Path (Join-Path $PSScriptRoot '..')
$configPath = Join-Path $repoRoot 'tests' 'Pester.runsettings.psd1'
if (-not (Test-Path $configPath)) {
  throw "Pester configuration not found: $configPath"
}

$config = Import-PowerShellDataFile -LiteralPath $configPath

# Normalize relative paths based on repo root
$config.Run.Path = @(
  $config.Run.Path | ForEach-Object {
    (Resolve-Path (Join-Path $repoRoot $_)).ProviderPath
  }
)
$resolvedResultPath = Resolve-Path (Join-Path $repoRoot $config.TestResult.OutputPath) -ErrorAction SilentlyContinue
if ($resolvedResultPath) {
  $config.TestResult.OutputPath = $resolvedResultPath.ProviderPath
} else {
  $config.TestResult.OutputPath = Join-Path $repoRoot 'out/test-results/pester.xml'
}
if (-not $config.TestResult.OutputPath) {
  $config.TestResult.OutputPath = Join-Path $repoRoot 'out/test-results/pester.xml'
}

if ($Tag) {
  $config.Filter.Tag = @($Tag)
}
if ($ExcludeTag) {
  $config.Filter.ExcludeTag = @($ExcludeTag)
}

if ($CI) {
  $resultsPath = $config.TestResult.OutputPath
  $resultsDir = Split-Path $resultsPath -Parent
  if (-not (Test-Path $resultsDir)) { New-Item -ItemType Directory -Path $resultsDir -Force | Out-Null }
  $config.TestResult.Enabled = $true
  Write-Host "CI mode: writing Pester results to $resultsPath"
} else {
  $config.TestResult.Enabled = $false
}

Write-Host "Invoking Pester with tags: $($config.Filter.Tag -join ', ')" -ForegroundColor Cyan
Invoke-Pester -Configuration $config

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDYd2uoPAkTXPJb
# bn+j5BoktSlFrWLc2tx3vJ8l5hj/eaCCAxYwggMSMIIB+qADAgECAhAebyMqhzBd
# p0NqD1NDfRuVMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTYwNzQwWhcNMjUxMTI3MTYxNzQwWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAvn8HFwuUrXwfO/V4bk79JtkyvVb8U9rNd3OOEBpfwiEB
# tSseLI6ydtRj0pjWSzRKNhEjO2GoMXcCWVfYONsB/79ho3XZ6KyE1TRxQbejvc4o
# WM+j6XGXSUGoTw5ej8NZJiZPMTh5hcqf/I8poGkxvfDbjZ3KeQhXvrzWvyY+zZhR
# +9OYHhii6BqCM3Cb1FA8MtPvUcQtQGO5dmiEQbLPZc4JVMnSJHLwtivIlwtrPaAn
# ElNf0sA1h2KSoHdEPGWOxGoWxSmCmCpgomH8N1h9O0xyDJF1hgxqC0ygOx8YxnPr
# XUF9KUIBxJPsMlj8Pk8Zs0GIdX/Csuhh9CZcUFy7yQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFM3ZlQ5KjhtM
# wDQzv0y5y0AjkxFWMA0GCSqGSIb3DQEBCwUAA4IBAQBFXtdF2/+r4NMk4uXR6VrC
# u4Ip+Ow+xJNFp0XRMEfmsUYPOXcdhEyCzXB8vgJQ58iVYFCDYsSBU028x48wRoii
# n347UON+L3Xi2BeqT66w3up64cLvqJi2KNTOT5rFLQg1JuTW71BNUkZbsXFqgWLo
# wEaZxFzqNLCU9KUrVai0mcq8xbEshQYko24nv0FCzpnwYZwvbKdCNddQqAqBNPiG
# OTYBYq38s7xAG3ehwVivmVysCLned6MY7pA0tLucY37khEDXnB2/Uu3DJSVy8Qjt
# b+GpRqfk9+RjQN2c4DxvbkYw2bl6GrgFtjqO5+8IlIqy7EkVY31ZEsNVEerlOVMS
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAebyMqhzBdp0NqD1NDfRuVMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEII11SC6wt7Xz
# Nju6w2mLIcqzI70/iCgkEho6gi7yzw2NMA0GCSqGSIb3DQEBAQUABIIBAIc51ePU
# V5niboBEcogWJot9cuvFqE/ra9hdaD76RN+N+yUewQZpsA+UbCzqJDn5WujrcOT7
# bRJNa5GkA1cSkChrAlJVHJbFfL20q/jutQ4ASHLmpEg2unsIuN4ccnHm8B5y9DnX
# jOAKvEndXe0WWbpj0NavmCumAWzV8qOA/XYOOIIw9WsFD8Gn4mKHXmBjW4wXH4Pv
# 0ZZ4QJ07hJfbewwTos7N5PmevesoIwvlFHW14bk3fcMIFrn6HPm2IMHhrPNIUa/e
# 3FoAvFQROqL7ftfzaBsrVpWVDk9KYK7qf4Qkx54DcMMXGcIUhIKDYuWtWpFJQTG0
# bGWHIklHeN1xUSo=
# SIG # End signature block
