# Verify-Signatures.ps1
[CmdletBinding()]
param(
  [Parameter()][string]$SearchRoot = (Get-Location).Path,
  [Parameter()][string[]]$Include = @("*.ps1","*.psm1"),
  [Parameter()][string[]]$ExcludeDirs = @(".git",".github",".venv","node_modules")
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'
$files = Get-ChildItem -LiteralPath $SearchRoot -Recurse -File -Include $Include | Where-Object {
  $rel = $_.FullName.Substring($SearchRoot.Length).TrimStart('\','/')
  -not ($ExcludeDirs | ForEach-Object { $rel -like ("{0}\*" -f $_) })
}
$bad = @()
foreach ($f in $files) {
  $sig = Get-AuthenticodeSignature -LiteralPath $f.FullName
  if ($sig.Status -ne 'Valid') { $bad += [pscustomobject]@{ Path = $f.FullName; Status = $sig.Status } }
}
if ($bad.Count -gt 0) {
  $bad | Format-Table -AutoSize | Out-String | Write-Output
  throw "Signature check failed for $($bad.Count) file(s)."
}
Write-Output "All script signatures are VALID."

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDA5chJevy6MGSV
# tHJMuyIwbEkqLQdD7aRYKil20DYfiaCCAxYwggMSMIIB+qADAgECAhAebyMqhzBd
# p0NqD1NDfRuVMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTYwNzQwWhcNMjUxMTI3MTYxNzQwWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAvn8HFwuUrXwfO/V4bk79JtkyvVb8U9rNd3OOEBpfwiEB
# tSseLI6ydtRj0pjWSzRKNhEjO2GoMXcCWVfYONsB/79ho3XZ6KyE1TRxQbejvc4o
# WM+j6XGXSUGoTw5ej8NZJiZPMTh5hcqf/I8poGkxvfDbjZ3KeQhXvrzWvyY+zZhR
# +9OYHhii6BqCM3Cb1FA8MtPvUcQtQGO5dmiEQbLPZc4JVMnSJHLwtivIlwtrPaAn
# ElNf0sA1h2KSoHdEPGWOxGoWxSmCmCpgomH8N1h9O0xyDJF1hgxqC0ygOx8YxnPr
# XUF9KUIBxJPsMlj8Pk8Zs0GIdX/Csuhh9CZcUFy7yQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFM3ZlQ5KjhtM
# wDQzv0y5y0AjkxFWMA0GCSqGSIb3DQEBCwUAA4IBAQBFXtdF2/+r4NMk4uXR6VrC
# u4Ip+Ow+xJNFp0XRMEfmsUYPOXcdhEyCzXB8vgJQ58iVYFCDYsSBU028x48wRoii
# n347UON+L3Xi2BeqT66w3up64cLvqJi2KNTOT5rFLQg1JuTW71BNUkZbsXFqgWLo
# wEaZxFzqNLCU9KUrVai0mcq8xbEshQYko24nv0FCzpnwYZwvbKdCNddQqAqBNPiG
# OTYBYq38s7xAG3ehwVivmVysCLned6MY7pA0tLucY37khEDXnB2/Uu3DJSVy8Qjt
# b+GpRqfk9+RjQN2c4DxvbkYw2bl6GrgFtjqO5+8IlIqy7EkVY31ZEsNVEerlOVMS
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAebyMqhzBdp0NqD1NDfRuVMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIIEZpCeYMGc2
# kHxmC59rnv7kFfu0+1EDOsevLQv84+74MA0GCSqGSIb3DQEBAQUABIIBACFD2CZ0
# VozpgI4/slI9JUxaWgffD/S361hIXlN0nzo3G0cFEJ0SOfoaz5CC9C7iVI/1HX4t
# argPtMeiVecQK4qvXVrzd3ZXctsHV9VGbt31MTgrNX6prgRDiHnN06QxBtth9mvq
# CWAnKbIjZB5XYwAS3cKP3ubIf+cclMr3Z2cuUH+j9aZKCclNzeG6rOM9Nc9ItjK2
# sb2XrOfsk3NeaRNpAf8hipS+qIm/mqPTqDL8+j1iC/LrU4F3PmAdFz8GzGROuEGg
# /EM22Z3oWPx0bLRIyjfbpstEi7QcL9RyoCkYnUOF98QaBCUTXw14Aya8pLJluGUM
# idSoEveujVgRXS0=
# SIG # End signature block
