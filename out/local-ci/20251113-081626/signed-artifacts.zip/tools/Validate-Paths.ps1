# Validate-Paths.ps1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Test-PathSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter()][switch]$RequireAbsolute
    )
    if ($Path -match '[;&|`]' -or $Path -match '\.\.') { return $false }
    try {
        $rp = Resolve-Path -LiteralPath $Path -ErrorAction Stop
        if ($RequireAbsolute -and -not ($rp.Path -match '^(?:[A-Za-z]:[\\/]|/)')) { return $false }
        return $true
    } catch { return $false }
}

function Validate-PathSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter()][switch]$RequireAbsolute
    )
    if (-not (Test-PathSafe -Path $Path -RequireAbsolute:$RequireAbsolute)) {
        throw "Unsafe or invalid path: $Path"
    }
    return (Resolve-Path -LiteralPath $Path).Path
}

Export-ModuleMember -Function Test-PathSafe, Validate-PathSafe

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBRKRGFgRiwJrUW
# ser+RbKUtmM3v2Ar6IG3lNNJMXHBxaCCAxYwggMSMIIB+qADAgECAhAebyMqhzBd
# p0NqD1NDfRuVMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTYwNzQwWhcNMjUxMTI3MTYxNzQwWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAvn8HFwuUrXwfO/V4bk79JtkyvVb8U9rNd3OOEBpfwiEB
# tSseLI6ydtRj0pjWSzRKNhEjO2GoMXcCWVfYONsB/79ho3XZ6KyE1TRxQbejvc4o
# WM+j6XGXSUGoTw5ej8NZJiZPMTh5hcqf/I8poGkxvfDbjZ3KeQhXvrzWvyY+zZhR
# +9OYHhii6BqCM3Cb1FA8MtPvUcQtQGO5dmiEQbLPZc4JVMnSJHLwtivIlwtrPaAn
# ElNf0sA1h2KSoHdEPGWOxGoWxSmCmCpgomH8N1h9O0xyDJF1hgxqC0ygOx8YxnPr
# XUF9KUIBxJPsMlj8Pk8Zs0GIdX/Csuhh9CZcUFy7yQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFM3ZlQ5KjhtM
# wDQzv0y5y0AjkxFWMA0GCSqGSIb3DQEBCwUAA4IBAQBFXtdF2/+r4NMk4uXR6VrC
# u4Ip+Ow+xJNFp0XRMEfmsUYPOXcdhEyCzXB8vgJQ58iVYFCDYsSBU028x48wRoii
# n347UON+L3Xi2BeqT66w3up64cLvqJi2KNTOT5rFLQg1JuTW71BNUkZbsXFqgWLo
# wEaZxFzqNLCU9KUrVai0mcq8xbEshQYko24nv0FCzpnwYZwvbKdCNddQqAqBNPiG
# OTYBYq38s7xAG3ehwVivmVysCLned6MY7pA0tLucY37khEDXnB2/Uu3DJSVy8Qjt
# b+GpRqfk9+RjQN2c4DxvbkYw2bl6GrgFtjqO5+8IlIqy7EkVY31ZEsNVEerlOVMS
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAebyMqhzBdp0NqD1NDfRuVMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEINpvsU+HHb6K
# gYnFC+DOD7Pi21ghNNfHTvYHF7x5UIBMMA0GCSqGSIb3DQEBAQUABIIBABbm/Fd0
# ca00ElCHesCMWW9s/AWU5tZTuqE6Yr/ueWzoTKDakvtoYiEz3D5ltuCnQaOVNqSG
# Dilj5/eQnSh74qMlNm8khSKTfxe8SSjvcKaft/GrG3+2mlGt4Lgb0HeB2qXeVj/M
# EDz6o0hk9OJIfxCMgE18fHwrogR004S0vQmo6I3leu1F7p22cRHXuUSAuxIcO8jL
# +S5ChrA/vxzbOvQoMHEVEMphDnHk78msl+c/ViVXhHuvmkU71A8ZU/780y8EigOW
# vA2i7N8ltHHZ1fqLe1JDFsUDSI2FRKXj7tvKh6O7XNXCG+ytmuFPXKk5O1uDl/zm
# aBfK+bbhcdx55qw=
# SIG # End signature block
