# Hash-Artifacts.ps1
[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$Root,
  [Parameter()][string]$Output = 'checksums.sha256'
)

Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'

$rootAbs = Resolve-Path -LiteralPath $Root -ErrorAction Stop
$rootPath = $rootAbs.ProviderPath
$items = Get-ChildItem -LiteralPath $rootPath -Recurse -File -ErrorAction Stop
$lines = New-Object System.Collections.Generic.List[string]
foreach ($i in $items) {
  $h = Get-FileHash -LiteralPath $i.FullName -Algorithm SHA256
  $relativePath = [System.IO.Path]::GetRelativePath($rootPath, $i.FullName)
  try {
    $lines.Add(("{0}  {1}" -f $h.Hash.ToLower(), $relativePath))
  } catch {
    throw "Failed to format hash entry for '$($i.FullName)' relative '$relativePath': $($_.Exception.Message)"
  }
}
$pathOut = Join-Path $rootPath $Output
$lines | Set-Content -LiteralPath $pathOut -Encoding UTF8 -NoNewline:$false
Write-Output "Wrote checksums to $pathOut"

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCASG2cZB9SxQNBP
# DwVC9asjKlcJItPjhuWB1EHHmj/2laCCAxYwggMSMIIB+qADAgECAhAebyMqhzBd
# p0NqD1NDfRuVMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTYwNzQwWhcNMjUxMTI3MTYxNzQwWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAvn8HFwuUrXwfO/V4bk79JtkyvVb8U9rNd3OOEBpfwiEB
# tSseLI6ydtRj0pjWSzRKNhEjO2GoMXcCWVfYONsB/79ho3XZ6KyE1TRxQbejvc4o
# WM+j6XGXSUGoTw5ej8NZJiZPMTh5hcqf/I8poGkxvfDbjZ3KeQhXvrzWvyY+zZhR
# +9OYHhii6BqCM3Cb1FA8MtPvUcQtQGO5dmiEQbLPZc4JVMnSJHLwtivIlwtrPaAn
# ElNf0sA1h2KSoHdEPGWOxGoWxSmCmCpgomH8N1h9O0xyDJF1hgxqC0ygOx8YxnPr
# XUF9KUIBxJPsMlj8Pk8Zs0GIdX/Csuhh9CZcUFy7yQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFM3ZlQ5KjhtM
# wDQzv0y5y0AjkxFWMA0GCSqGSIb3DQEBCwUAA4IBAQBFXtdF2/+r4NMk4uXR6VrC
# u4Ip+Ow+xJNFp0XRMEfmsUYPOXcdhEyCzXB8vgJQ58iVYFCDYsSBU028x48wRoii
# n347UON+L3Xi2BeqT66w3up64cLvqJi2KNTOT5rFLQg1JuTW71BNUkZbsXFqgWLo
# wEaZxFzqNLCU9KUrVai0mcq8xbEshQYko24nv0FCzpnwYZwvbKdCNddQqAqBNPiG
# OTYBYq38s7xAG3ehwVivmVysCLned6MY7pA0tLucY37khEDXnB2/Uu3DJSVy8Qjt
# b+GpRqfk9+RjQN2c4DxvbkYw2bl6GrgFtjqO5+8IlIqy7EkVY31ZEsNVEerlOVMS
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAebyMqhzBdp0NqD1NDfRuVMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIFwh7Ia6nNVg
# FzrXU1zSmX6Kq7zfAQC5vDsMmiqye02wMA0GCSqGSIb3DQEBAQUABIIBAHcgCC0A
# eL7YYrAw+DZlaVB7vdfm0uj3bMotQh5sNHFG2FTzjWJLM0hrVXEWCQzy6+/gmkBx
# Q+6wIyh6Bk9sYph2h0uf0BVwquqtTydnTZ8ucqSZXIkX7TnKVuVvrWLy53PvnoJw
# U/8eUY4yBY0bzyj/Sjnv/t06zMzm5VNhS89ZT3LqUG3T5E6aIwYrwrwTSQCk6/Dw
# 8bVli7W3YI5pscKjL9P7e4JZtYBoL+w+DaOJt30siZa33owSBFOXXKHLj6CIvhyd
# 5tP9TyEX5itxrBw7GNYBrQXpSMLBor1NRp45Jb5kFvTvq9UFbWqvsAY1f8Bg9K65
# Gtlywf1a20+NZXQ=
# SIG # End signature block
