# EnvGuard.psm1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Get-EnvSnapshot {
    [CmdletBinding()]
    param([string[]]$AllowList = @('PATH','TEMP','TMP','HOME','USERPROFILE'))
    $snap = @{}
    foreach ($name in [Environment]::GetEnvironmentVariables().Keys) {
        if ($AllowList -contains $name) { $snap[$name] = [Environment]::GetEnvironmentVariable($name,'Process') }
    }
    return $snap
}

function Set-EnvFromSnapshot {
    [CmdletBinding()]
    param([Parameter(Mandatory)][hashtable]$Snapshot)
    foreach ($k in $Snapshot.Keys) {
        [Environment]::SetEnvironmentVariable($k, [string]$Snapshot[$k], 'Process')
    }
}

Export-ModuleMember -Function Get-EnvSnapshot, Set-EnvFromSnapshot

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAzwwfWBljXiDkz
# 9AHE9bg618B2oMEor3Mbt2BkcXsxKKCCAxYwggMSMIIB+qADAgECAhAebyMqhzBd
# p0NqD1NDfRuVMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTYwNzQwWhcNMjUxMTI3MTYxNzQwWjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAvn8HFwuUrXwfO/V4bk79JtkyvVb8U9rNd3OOEBpfwiEB
# tSseLI6ydtRj0pjWSzRKNhEjO2GoMXcCWVfYONsB/79ho3XZ6KyE1TRxQbejvc4o
# WM+j6XGXSUGoTw5ej8NZJiZPMTh5hcqf/I8poGkxvfDbjZ3KeQhXvrzWvyY+zZhR
# +9OYHhii6BqCM3Cb1FA8MtPvUcQtQGO5dmiEQbLPZc4JVMnSJHLwtivIlwtrPaAn
# ElNf0sA1h2KSoHdEPGWOxGoWxSmCmCpgomH8N1h9O0xyDJF1hgxqC0ygOx8YxnPr
# XUF9KUIBxJPsMlj8Pk8Zs0GIdX/Csuhh9CZcUFy7yQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFM3ZlQ5KjhtM
# wDQzv0y5y0AjkxFWMA0GCSqGSIb3DQEBCwUAA4IBAQBFXtdF2/+r4NMk4uXR6VrC
# u4Ip+Ow+xJNFp0XRMEfmsUYPOXcdhEyCzXB8vgJQ58iVYFCDYsSBU028x48wRoii
# n347UON+L3Xi2BeqT66w3up64cLvqJi2KNTOT5rFLQg1JuTW71BNUkZbsXFqgWLo
# wEaZxFzqNLCU9KUrVai0mcq8xbEshQYko24nv0FCzpnwYZwvbKdCNddQqAqBNPiG
# OTYBYq38s7xAG3ehwVivmVysCLned6MY7pA0tLucY37khEDXnB2/Uu3DJSVy8Qjt
# b+GpRqfk9+RjQN2c4DxvbkYw2bl6GrgFtjqO5+8IlIqy7EkVY31ZEsNVEerlOVMS
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAebyMqhzBdp0NqD1NDfRuVMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIJlQaYHytxsd
# hJ21/Xd1OOTWhUd4iNiRCRC/DDWxp9vgMA0GCSqGSIb3DQEBAQUABIIBALxRX7m6
# bCN+JT10MacbYVDwJ6AEIIjV558TagRzcXMeoehMiaQifoAU9NYVkhgoerYQIQfp
# cE2Eo7iVYos7gFGtPH8C1NrF2JWFo+WGZtBRhZE6vRZn6vEoYlVE1PFox3vM6lez
# eII4b0LQticoG0BTMCWHYkDbApTJjunOiOakDDfwC/+aRb/DBgEob3vI2cpIuB7z
# dU9InsWScwZykKYPu1WROwjKFSMKOp7SPc7QPuNSDeWSm6KfmLdWsmMYL+RMe8tm
# uo+sqBXRzzdlALdqzOqOjon9K8mzAFkASgSBXk20aHzRh+AXMPxepoJCmpbYz1+n
# swZLHOskAxc/920=
# SIG # End signature block
