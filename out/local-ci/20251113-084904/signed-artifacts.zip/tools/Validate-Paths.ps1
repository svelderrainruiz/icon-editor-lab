# Validate-Paths.ps1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Test-PathSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter()][switch]$RequireAbsolute
    )
    if ($Path -match '[;&|`]' -or $Path -match '\.\.') { return $false }
    try {
        $rp = Resolve-Path -LiteralPath $Path -ErrorAction Stop
        if ($RequireAbsolute -and -not ($rp.Path -match '^(?:[A-Za-z]:[\\/]|/)')) { return $false }
        return $true
    } catch { return $false }
}

function Validate-PathSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter()][switch]$RequireAbsolute
    )
    if (-not (Test-PathSafe -Path $Path -RequireAbsolute:$RequireAbsolute)) {
        throw "Unsafe or invalid path: $Path"
    }
    return (Resolve-Path -LiteralPath $Path).Path
}

Export-ModuleMember -Function Test-PathSafe, Validate-PathSafe

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBRKRGFgRiwJrUW
# ser+RbKUtmM3v2Ar6IG3lNNJMXHBxaCCAxYwggMSMIIB+qADAgECAhBkcYdH+Ssg
# jUch2kYv9XfiMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTY0MDM4WhcNMjUxMTI3MTY1MDM4WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA6QaU7uGtooMq2EKjBgqEQvjSmYZeCxZA8gKB4xN+ZxIK
# O7InmqAWP3dvCorQW4oA/ppsP/8tI31wzzaGDMwtk71OEp9HEjR40YNuzpNN35fj
# JT55AgEgUAL91hcvY4nrel14/JVU4JMLFqGaBqbIiAvU3D00r4iF5T2/LIIAXuqr
# /3+HSfX84iR2lSsPXc7UUK9BOkutTCT4qFm1Qv7yjEVd7o842rodLnQoI0MqxfPl
# PNOChM2JBNWEwvSK/PWM5euBPVZbLTIj8hflMhlWkvwWlPputjiuC/1oGF7z55+T
# Z0wqKN4lIjPxGbVR3RjqVfWBsr8/ShCYt1gl4EblLQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFKVDd1pSkfIi
# up5raujIUjDVBtT5MA0GCSqGSIb3DQEBCwUAA4IBAQAOr55ahAkBGWtkPFC8rceO
# sGNDjOoq94X3IpKXWIalXKv4GZIdUGObYJ9MVy5iyARpJEyf3D5rhTle4VXo33wg
# jN551HVT3uYzLWeSDhnbX8rRA6kk5LBFL5MAdt1yq8zk1p3DrBU20Af7vr3MgqB6
# 6SqUP6vRjC+ShI+FcEFXQZCjGfZ/BvVGZY0fSH0BSyoQ4g4cpY3NmheLqjU3k3oA
# NVAA9px9PFRd5rRoZDwnLfKw0izi2wohOBvUe0GzgwZUYHdaYbPUYa8JQ74xp/aZ
# BKt0Cc3p7fjL7ljoeuicTIxxR4cyyO5HCP8wOLDsEC4IGJK7EdT7PN1BDW+L0T1N
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBkcYdH+SsgjUch2kYv9XfiMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEINpvsU+HHb6K
# gYnFC+DOD7Pi21ghNNfHTvYHF7x5UIBMMA0GCSqGSIb3DQEBAQUABIIBAGOrFK+U
# EGQt5LYEA2ZMg9xzhrGRko2Vod06W8pxlXR0/DBYqPNX9ZKbaPhdE/FNKUH67KEj
# IYrtpH5lCuGEVCNOnDqhX2q99yywTkOGjDI4nHqde5/H8fAErSRprdf/a7hg/PAR
# +sVtt8aG7Di8ZIH2T6IXB1YXh4oVEJRTiazE1JY9HfiOCxQH8Lf5VC5rPjGL4yzq
# kvywGcqiJ4rjz+JqPWzHBYIOtshAZPovbxEsXlTCU7FuVtJC0jaa07OYRSAkHEJB
# ytMIIiPyFiOuuW3XkiMkwqUKytQzXQwn3bJQdnoszXnA1neAETCsTHHhhpLRGEd9
# a24Yb8lyrVGAWoQ=
# SIG # End signature block
