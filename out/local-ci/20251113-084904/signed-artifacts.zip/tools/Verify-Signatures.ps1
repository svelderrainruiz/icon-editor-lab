# Verify-Signatures.ps1
[CmdletBinding()]
param(
  [Parameter()][string]$SearchRoot = (Get-Location).Path,
  [Parameter()][string[]]$Include = @("*.ps1","*.psm1"),
  [Parameter()][string[]]$ExcludeDirs = @(".git",".github",".venv","node_modules")
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'
$files = Get-ChildItem -LiteralPath $SearchRoot -Recurse -File -Include $Include | Where-Object {
  $rel = $_.FullName.Substring($SearchRoot.Length).TrimStart('\','/')
  -not ($ExcludeDirs | ForEach-Object { $rel -like ("{0}\*" -f $_) })
}
$bad = @()
foreach ($f in $files) {
  $sig = Get-AuthenticodeSignature -LiteralPath $f.FullName
  if ($sig.Status -ne 'Valid') { $bad += [pscustomobject]@{ Path = $f.FullName; Status = $sig.Status } }
}
if ($bad.Count -gt 0) {
  $bad | Format-Table -AutoSize | Out-String | Write-Output
  throw "Signature check failed for $($bad.Count) file(s)."
}
Write-Output "All script signatures are VALID."

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDA5chJevy6MGSV
# tHJMuyIwbEkqLQdD7aRYKil20DYfiaCCAxYwggMSMIIB+qADAgECAhBkcYdH+Ssg
# jUch2kYv9XfiMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTY0MDM4WhcNMjUxMTI3MTY1MDM4WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA6QaU7uGtooMq2EKjBgqEQvjSmYZeCxZA8gKB4xN+ZxIK
# O7InmqAWP3dvCorQW4oA/ppsP/8tI31wzzaGDMwtk71OEp9HEjR40YNuzpNN35fj
# JT55AgEgUAL91hcvY4nrel14/JVU4JMLFqGaBqbIiAvU3D00r4iF5T2/LIIAXuqr
# /3+HSfX84iR2lSsPXc7UUK9BOkutTCT4qFm1Qv7yjEVd7o842rodLnQoI0MqxfPl
# PNOChM2JBNWEwvSK/PWM5euBPVZbLTIj8hflMhlWkvwWlPputjiuC/1oGF7z55+T
# Z0wqKN4lIjPxGbVR3RjqVfWBsr8/ShCYt1gl4EblLQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFKVDd1pSkfIi
# up5raujIUjDVBtT5MA0GCSqGSIb3DQEBCwUAA4IBAQAOr55ahAkBGWtkPFC8rceO
# sGNDjOoq94X3IpKXWIalXKv4GZIdUGObYJ9MVy5iyARpJEyf3D5rhTle4VXo33wg
# jN551HVT3uYzLWeSDhnbX8rRA6kk5LBFL5MAdt1yq8zk1p3DrBU20Af7vr3MgqB6
# 6SqUP6vRjC+ShI+FcEFXQZCjGfZ/BvVGZY0fSH0BSyoQ4g4cpY3NmheLqjU3k3oA
# NVAA9px9PFRd5rRoZDwnLfKw0izi2wohOBvUe0GzgwZUYHdaYbPUYa8JQ74xp/aZ
# BKt0Cc3p7fjL7ljoeuicTIxxR4cyyO5HCP8wOLDsEC4IGJK7EdT7PN1BDW+L0T1N
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBkcYdH+SsgjUch2kYv9XfiMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIIEZpCeYMGc2
# kHxmC59rnv7kFfu0+1EDOsevLQv84+74MA0GCSqGSIb3DQEBAQUABIIBAFXgkgBS
# X0Lyw7dGzycWHdfNn2FreZbggwevJjpZzptlX9vYCsxRJ1sSisK6lKhEDdDswZ1/
# MIDBgaZpxMkTWIr26WATBDQQyMzkjYuiNb3suaBOxVv2vgN+O/8RUsjqtStcOF3A
# PCkL2OxdQOk8w7E4wcu9JI+x5AH2MzJlrL0Uzw7JrSIrJY1LAFlO3YCizhZcES77
# 4o2ZZTd7NmfFmqwyMamG5vTmCG663KMfRl1Ayj+CQoXca2O1kUedSxCAWODPfIZu
# oAJganr/eAwG0tu/GlFoR70Q28R1efUqfZrC7V8P0KMpl3AFMET4TTVlkzyxGG1l
# 7avZzMdCqBMYsNI=
# SIG # End signature block
