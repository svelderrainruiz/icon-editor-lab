# EnvGuard.psm1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Get-EnvSnapshot {
    [CmdletBinding()]
    param([string[]]$AllowList = @('PATH','TEMP','TMP','HOME','USERPROFILE'))
    $snap = @{}
    foreach ($name in [Environment]::GetEnvironmentVariables().Keys) {
        if ($AllowList -contains $name) { $snap[$name] = [Environment]::GetEnvironmentVariable($name,'Process') }
    }
    return $snap
}

function Set-EnvFromSnapshot {
    [CmdletBinding()]
    param([Parameter(Mandatory)][hashtable]$Snapshot)
    foreach ($k in $Snapshot.Keys) {
        [Environment]::SetEnvironmentVariable($k, [string]$Snapshot[$k], 'Process')
    }
}

Export-ModuleMember -Function Get-EnvSnapshot, Set-EnvFromSnapshot

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAzwwfWBljXiDkz
# 9AHE9bg618B2oMEor3Mbt2BkcXsxKKCCAxYwggMSMIIB+qADAgECAhBkcYdH+Ssg
# jUch2kYv9XfiMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTY0MDM4WhcNMjUxMTI3MTY1MDM4WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA6QaU7uGtooMq2EKjBgqEQvjSmYZeCxZA8gKB4xN+ZxIK
# O7InmqAWP3dvCorQW4oA/ppsP/8tI31wzzaGDMwtk71OEp9HEjR40YNuzpNN35fj
# JT55AgEgUAL91hcvY4nrel14/JVU4JMLFqGaBqbIiAvU3D00r4iF5T2/LIIAXuqr
# /3+HSfX84iR2lSsPXc7UUK9BOkutTCT4qFm1Qv7yjEVd7o842rodLnQoI0MqxfPl
# PNOChM2JBNWEwvSK/PWM5euBPVZbLTIj8hflMhlWkvwWlPputjiuC/1oGF7z55+T
# Z0wqKN4lIjPxGbVR3RjqVfWBsr8/ShCYt1gl4EblLQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFKVDd1pSkfIi
# up5raujIUjDVBtT5MA0GCSqGSIb3DQEBCwUAA4IBAQAOr55ahAkBGWtkPFC8rceO
# sGNDjOoq94X3IpKXWIalXKv4GZIdUGObYJ9MVy5iyARpJEyf3D5rhTle4VXo33wg
# jN551HVT3uYzLWeSDhnbX8rRA6kk5LBFL5MAdt1yq8zk1p3DrBU20Af7vr3MgqB6
# 6SqUP6vRjC+ShI+FcEFXQZCjGfZ/BvVGZY0fSH0BSyoQ4g4cpY3NmheLqjU3k3oA
# NVAA9px9PFRd5rRoZDwnLfKw0izi2wohOBvUe0GzgwZUYHdaYbPUYa8JQ74xp/aZ
# BKt0Cc3p7fjL7ljoeuicTIxxR4cyyO5HCP8wOLDsEC4IGJK7EdT7PN1BDW+L0T1N
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBkcYdH+SsgjUch2kYv9XfiMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIJlQaYHytxsd
# hJ21/Xd1OOTWhUd4iNiRCRC/DDWxp9vgMA0GCSqGSIb3DQEBAQUABIIBAGZL404p
# 6zsI5UbI/DNDTiOQpzKitdim2ryWyNnEo+4GlHb/h+ZqdoBSBcpv7jVMJo93eMud
# YJhtn0zg/oXgjOLTQyb/Up3MvnemFIRkxJhMk8kkXkPDAN9miDAdrbS6zOrK8sCh
# xWYS2SjPdm0sT8AGDnN/xblVXcUl7XFie7hjWU+fgOdQhPidbrj4+E8nkVxmVGAN
# ketskj2KDo1ghBhneGF1Ku2UQphMwoAhphHYs/r+3Bj75vEo1VUFObS64Q0sHEXA
# JYcrFMR/pL8dix4/P5JzdZpHKrHWIAijYZ3QZv34HCRUZ+esIlSBV+7qSP4Gi+3L
# Uqu5R97m1r+YNq8=
# SIG # End signature block
