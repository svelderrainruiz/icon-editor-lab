[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$ConfigPath,
  [Parameter()][string]$SchemaPath = (Join-Path $PSScriptRoot '..' 'configs' 'schema' 'vi-diff-heuristics.schema.json')
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'
. (Join-Path $PSScriptRoot 'Redaction.ps1')
$cfgContent = Get-Content -LiteralPath $ConfigPath -Raw
# Basic JSON validity check
$null = $cfgContent | ConvertFrom-Json -ErrorAction Stop
# Schema validation (if schema exists)
if (Test-Path -LiteralPath $SchemaPath -PathType Leaf) {
  $cfgContent | Test-Json -SchemaFile $SchemaPath -ErrorAction Stop | Out-Null
}
Write-Output "Config validated successfully:" (Resolve-Path -LiteralPath $ConfigPath).Path

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAtM1F8YzQ4xa9F
# 7QuDGJd4jTwMhZsuR+3nhXLiXLTUlKCCAxYwggMSMIIB+qADAgECAhBkcYdH+Ssg
# jUch2kYv9XfiMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTY0MDM4WhcNMjUxMTI3MTY1MDM4WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA6QaU7uGtooMq2EKjBgqEQvjSmYZeCxZA8gKB4xN+ZxIK
# O7InmqAWP3dvCorQW4oA/ppsP/8tI31wzzaGDMwtk71OEp9HEjR40YNuzpNN35fj
# JT55AgEgUAL91hcvY4nrel14/JVU4JMLFqGaBqbIiAvU3D00r4iF5T2/LIIAXuqr
# /3+HSfX84iR2lSsPXc7UUK9BOkutTCT4qFm1Qv7yjEVd7o842rodLnQoI0MqxfPl
# PNOChM2JBNWEwvSK/PWM5euBPVZbLTIj8hflMhlWkvwWlPputjiuC/1oGF7z55+T
# Z0wqKN4lIjPxGbVR3RjqVfWBsr8/ShCYt1gl4EblLQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFKVDd1pSkfIi
# up5raujIUjDVBtT5MA0GCSqGSIb3DQEBCwUAA4IBAQAOr55ahAkBGWtkPFC8rceO
# sGNDjOoq94X3IpKXWIalXKv4GZIdUGObYJ9MVy5iyARpJEyf3D5rhTle4VXo33wg
# jN551HVT3uYzLWeSDhnbX8rRA6kk5LBFL5MAdt1yq8zk1p3DrBU20Af7vr3MgqB6
# 6SqUP6vRjC+ShI+FcEFXQZCjGfZ/BvVGZY0fSH0BSyoQ4g4cpY3NmheLqjU3k3oA
# NVAA9px9PFRd5rRoZDwnLfKw0izi2wohOBvUe0GzgwZUYHdaYbPUYa8JQ74xp/aZ
# BKt0Cc3p7fjL7ljoeuicTIxxR4cyyO5HCP8wOLDsEC4IGJK7EdT7PN1BDW+L0T1N
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBkcYdH+SsgjUch2kYv9XfiMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPGNlwZgDGGO
# 4eoZqf6qFtcbYyZe5LvdTuTwGIaPVsX8MA0GCSqGSIb3DQEBAQUABIIBAFYNsmtU
# 1AX1sfV9xK7Z/bY1BB/4OQiC0TVHn2dgtpJqm4WLhd1m1HQ8SFt/nnkNxCNPGc31
# P1m9ErPuyX84DzqV7aRrXD28x1ni1zWbEyBmfGdqQgsx0nwrfrA71um2VpoY7Eg9
# EbDGIJPeiThEKwv0ccfj7S9/Lva93yc1kjruJUcAcmTR+boALOJ3aYeGQ862nj3r
# HnDG12S6qz9lt/GthNAZz/0AeSBpqMHZsfZIX7wOfDlzXt7ilvEFQRq6X55t0Hcb
# WwBT4G4gLpOxsyLY/HjsEj8T7FjKtZenGxSztCsVXxOv+1ePw29TLEfs/kO4HWrG
# 3A4StIGumQ1CMsk=
# SIG # End signature block
