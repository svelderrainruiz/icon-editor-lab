# Secure-Process.psm1
Set-StrictMode -Version Latest
. (Join-Path $PSScriptRoot 'Validate-Paths.ps1')
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Invoke-ProcessSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$FilePath,
        [Parameter()][string[]]$ArgumentList = @(),
        [Parameter()][int]$TimeoutSec = 600,
        [Parameter()][string]$WorkingDirectory = (Get-Location).Path
    )
    if (-not (Test-Path -LiteralPath $FilePath -PathType Leaf)) { throw "FilePath not found: $FilePath" }
    $psi = [System.Diagnostics.ProcessStartInfo]::new()
    $psi.FileName = $FilePath
    $psi.WorkingDirectory = (Validate-PathSafe -Path $WorkingDirectory)
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.UseShellExecute = $false
    foreach ($a in $ArgumentList) { $null = $psi.ArgumentList.Add($a) }

    $p = [System.Diagnostics.Process]::new()
    $p.StartInfo = $psi
    if (-not $p.Start()) { throw "Failed to start process: $FilePath" }
    try {
        if (-not $p.WaitForExit($TimeoutSec * 1000)) {
            try { $p.Kill($true) } catch {}
            throw "Process timed out after $TimeoutSec s: $FilePath"
        }
        $stdout = $p.StandardOutput.ReadToEnd()
        $stderr = $p.StandardError.ReadToEnd()
        return [pscustomobject]@{
            ExitCode = $p.ExitCode
            StdOut = $stdout
            StdErr = $stderr
        }
    } finally {
        if (-not $p.HasExited) { try { $p.Kill($true) } catch {} }
        $p.Dispose()
    }
}
Export-ModuleMember -Function Invoke-ProcessSafe

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDLM/hZ77J6ko3k
# J1T1SnSI3Zjg9T8EF5sOyyHIvgXLgqCCAxYwggMSMIIB+qADAgECAhBkcYdH+Ssg
# jUch2kYv9XfiMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTY0MDM4WhcNMjUxMTI3MTY1MDM4WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA6QaU7uGtooMq2EKjBgqEQvjSmYZeCxZA8gKB4xN+ZxIK
# O7InmqAWP3dvCorQW4oA/ppsP/8tI31wzzaGDMwtk71OEp9HEjR40YNuzpNN35fj
# JT55AgEgUAL91hcvY4nrel14/JVU4JMLFqGaBqbIiAvU3D00r4iF5T2/LIIAXuqr
# /3+HSfX84iR2lSsPXc7UUK9BOkutTCT4qFm1Qv7yjEVd7o842rodLnQoI0MqxfPl
# PNOChM2JBNWEwvSK/PWM5euBPVZbLTIj8hflMhlWkvwWlPputjiuC/1oGF7z55+T
# Z0wqKN4lIjPxGbVR3RjqVfWBsr8/ShCYt1gl4EblLQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFKVDd1pSkfIi
# up5raujIUjDVBtT5MA0GCSqGSIb3DQEBCwUAA4IBAQAOr55ahAkBGWtkPFC8rceO
# sGNDjOoq94X3IpKXWIalXKv4GZIdUGObYJ9MVy5iyARpJEyf3D5rhTle4VXo33wg
# jN551HVT3uYzLWeSDhnbX8rRA6kk5LBFL5MAdt1yq8zk1p3DrBU20Af7vr3MgqB6
# 6SqUP6vRjC+ShI+FcEFXQZCjGfZ/BvVGZY0fSH0BSyoQ4g4cpY3NmheLqjU3k3oA
# NVAA9px9PFRd5rRoZDwnLfKw0izi2wohOBvUe0GzgwZUYHdaYbPUYa8JQ74xp/aZ
# BKt0Cc3p7fjL7ljoeuicTIxxR4cyyO5HCP8wOLDsEC4IGJK7EdT7PN1BDW+L0T1N
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhBkcYdH+SsgjUch2kYv9XfiMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPEK5pYr/oiP
# 6zXDh72ZtLHO5VLyj1aDMXhTjDbbSs4wMA0GCSqGSIb3DQEBAQUABIIBAGGhiFh+
# QtQcmfx2zkToTtyE6DOYv3meHypKry9d9SpO5q6Qf079gkRDMJuq6fKo1LJKH18W
# l1qnSZ5mIcyThEV0DaqXIwrXtP7D4BKostim8ZHgtks0lTw0PgzNYvg4JLCt3I5J
# 7s+ydlnzWTIe23gjmMkfBvWM3wOCkjiWJ1CB3/o4wc7o0aN52bj9H2g8P/cOWZxt
# tjSewT2pHK/QObbMCIpPn1vcc1wfNvbAQHGa1JQmL/5xrCEJTXMo+DzMI2iCBssu
# JX5cLEDWTlYQMz2NCQuSjjNoMp/wO5q689p7o3HXgnP2xTb7TtddIAUT6RBHB5yq
# +a+z1UR/KiUW7wI=
# SIG # End signature block
