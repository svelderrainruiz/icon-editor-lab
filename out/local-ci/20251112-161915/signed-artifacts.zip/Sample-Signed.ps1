Write-Output 'Sample payload for local CI build.'
