#Requires -Version 7.0
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$BundleRoot,
    [switch]$WriteHost
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$bundleRoot = [System.IO.Path]::GetFullPath($BundleRoot)
if (-not (Test-Path -LiteralPath $bundleRoot -PathType Container)) {
    throw "Bundle root not found: $bundleRoot"
}

$summary = [ordered]@{
    schema      = 'icon-editor/semver-bundle-summary@v1'
    generatedAt = (Get-Date).ToString('o')
    bundleRoot  = $bundleRoot
    zipPath     = "$bundleRoot.zip"
    verified    = $true
}

$summaryPath = Join-Path $bundleRoot 'semver-summary.json'
$summary | ConvertTo-Json -Depth 4 | Out-File -FilePath $summaryPath -Encoding UTF8

if ($WriteHost) {
    Write-Host "[SemVerBundle] Summary"
    Write-Host ("  Bundle   : {0}" -f $bundleRoot)
    Write-Host ("  Zip      : {0}" -f "$bundleRoot.zip")
    Write-Host ("  Verified : {0}" -f $true)
    Write-Host ("  Summary  : {0}" -f $summaryPath)
}

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCv9pTtVq1odPNf
# nEfiuPuDX7rgU9AZjAmXsUzNPHHOOqCCAxYwggMSMIIB+qADAgECAhAtm/SxXUET
# uEmxvLNVOiC5MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMjE1NDM3WhcNMjUxMTI3MjIwNDM3WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAxd/sydsliCPS3KELyeSerxe4XojufCU7HeSQUrIw0nzG
# CozqXgb0Ro9IHDjysfK8qV8y3wnboxe49zg0JK0z9ICtIp7pFBOgbE4r7cIjB2VX
# WxlgmkI11AFBz8YT5gLTzRJYMh/xelewmdqmXnL96lmHzjglMD0kBKJIFCR1+czs
# OX2aPiLk77ZTUPPC80H4hq9jao+jfmwkZ11DSLNGsjP8bfiv4qhi7wblrPQuAMBR
# h6imOHfI2UxOoZbrZMU24gFSjmdFVZxkL1nVYpsOVPz8sUjEapGs7hzyd/+Di16W
# q/C1hMqmLyr7OCmYxXxSwMHgL4lHzfaflUY2qQTwPQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFESWXrkYB+iP
# E74gZD0nisZjkAsNMA0GCSqGSIb3DQEBCwUAA4IBAQBoxm+gfY/JqcldQo7Nh2Dl
# XlglmjfMrC7/MCBRuWKvR5sYa5uniPSg9/BcxCUD781L6StPX3iN+5l9T0Sli8aA
# kS52NfDA3p0au4cw+KCkMP1lgnMiKV/3iOgfmiu69zW+1CrdE4NdGD+sWlfVq5U5
# JNOJICCaf8rSXbjb/czWbBTCgUxvPbgyaRYFqxwiNTNdE/NMfT/FpACWoIWrUi0s
# HADCp6a/E6DviiLKWdLRkpNtzoZug3nifQlqG9DfOyO01itthyncvws89B/JPIn6
# VGDzDF8G1AJTgpg6f/VMZMFL71yVAm06tC6b9WTW9bb6t7UKjpn9kx+RWJtF0Tsz
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAtm/SxXUETuEmxvLNVOiC5MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPrmL4l37naI
# cuw6Hk+Z9Z0ioNWA4x/9X43uGcT1cTYyMA0GCSqGSIb3DQEBAQUABIIBAJzvBDZi
# AFOdHWHIoHhbyAMwrNm0GHxorGvMIxC0M0Zn582wUD6as0Lb8EwfewI8RHzBAt1a
# XFWZZi/X4jKjJc+BgM9EtrSoHKOQ+IIkno0B5mXd1ASV5X3Dd9AbvwmsJyA2vx7M
# Uc2MdKRmkTtUwVSCot5sVwILtII8IqxtHVSnP7sgxTz3NkLX388M0ss0v+lia0gb
# a2q0IP1KhXBZ635cn+FdRQY4DwmrEGB6fL4ktn+d6Mie6GuKyohbuUW6jjfHwEUm
# UuDlX2pEJVBNgSkjEk6YndtmcLuFnhboi9eUZjPyUkywko6Hvc6/23yF/PPduwXs
# DO9sJGVJac4zmfk=
# SIG # End signature block
