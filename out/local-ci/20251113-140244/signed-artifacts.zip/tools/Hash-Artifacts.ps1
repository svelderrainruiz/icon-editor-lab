# Hash-Artifacts.ps1
[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$Root,
  [Parameter()][string]$Output = 'checksums.sha256'
)

Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'

$rootAbs = Resolve-Path -LiteralPath $Root -ErrorAction Stop
$rootPath = $rootAbs.ProviderPath
$items = Get-ChildItem -LiteralPath $rootPath -Recurse -File -ErrorAction Stop
$lines = New-Object System.Collections.Generic.List[string]
foreach ($i in $items) {
  $h = Get-FileHash -LiteralPath $i.FullName -Algorithm SHA256
  $relativePath = [System.IO.Path]::GetRelativePath($rootPath, $i.FullName)
  try {
    $lines.Add(("{0}  {1}" -f $h.Hash.ToLower(), $relativePath))
  } catch {
    throw "Failed to format hash entry for '$($i.FullName)' relative '$relativePath': $($_.Exception.Message)"
  }
}
$pathOut = Join-Path $rootPath $Output
$lines | Set-Content -LiteralPath $pathOut -Encoding UTF8 -NoNewline:$false
Write-Output "Wrote checksums to $pathOut"

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCASG2cZB9SxQNBP
# DwVC9asjKlcJItPjhuWB1EHHmj/2laCCAxYwggMSMIIB+qADAgECAhAtm/SxXUET
# uEmxvLNVOiC5MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMjE1NDM3WhcNMjUxMTI3MjIwNDM3WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAxd/sydsliCPS3KELyeSerxe4XojufCU7HeSQUrIw0nzG
# CozqXgb0Ro9IHDjysfK8qV8y3wnboxe49zg0JK0z9ICtIp7pFBOgbE4r7cIjB2VX
# WxlgmkI11AFBz8YT5gLTzRJYMh/xelewmdqmXnL96lmHzjglMD0kBKJIFCR1+czs
# OX2aPiLk77ZTUPPC80H4hq9jao+jfmwkZ11DSLNGsjP8bfiv4qhi7wblrPQuAMBR
# h6imOHfI2UxOoZbrZMU24gFSjmdFVZxkL1nVYpsOVPz8sUjEapGs7hzyd/+Di16W
# q/C1hMqmLyr7OCmYxXxSwMHgL4lHzfaflUY2qQTwPQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFESWXrkYB+iP
# E74gZD0nisZjkAsNMA0GCSqGSIb3DQEBCwUAA4IBAQBoxm+gfY/JqcldQo7Nh2Dl
# XlglmjfMrC7/MCBRuWKvR5sYa5uniPSg9/BcxCUD781L6StPX3iN+5l9T0Sli8aA
# kS52NfDA3p0au4cw+KCkMP1lgnMiKV/3iOgfmiu69zW+1CrdE4NdGD+sWlfVq5U5
# JNOJICCaf8rSXbjb/czWbBTCgUxvPbgyaRYFqxwiNTNdE/NMfT/FpACWoIWrUi0s
# HADCp6a/E6DviiLKWdLRkpNtzoZug3nifQlqG9DfOyO01itthyncvws89B/JPIn6
# VGDzDF8G1AJTgpg6f/VMZMFL71yVAm06tC6b9WTW9bb6t7UKjpn9kx+RWJtF0Tsz
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAtm/SxXUETuEmxvLNVOiC5MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIFwh7Ia6nNVg
# FzrXU1zSmX6Kq7zfAQC5vDsMmiqye02wMA0GCSqGSIb3DQEBAQUABIIBAKy/yQtn
# 1QWmsdvMw5RPNlDIWj2cLuQbDLtdi7WXYye7EcUqQcjfZOSGlZ92aJvjwh0hv7BL
# h5+KwriKCvF9Z6aT7X0ecYHXAcc7108eiYrgJ1mDCYuCHUm58FNXrMjeU0vilZf4
# UGPzNnNzKpPpfTHTfhqdvG88J0MbtmhT+UbC3x/ELG+0WP8i5+Qtd5+0AVyM385J
# hdufSTHKrLQmakr+hBAU4C4SN0I34DhC+QuFRVmmjwZ5FSRkQVWHcHNbkI6aVp7V
# 5neigJJdY8pDBvsI+SK8NG/oCYFCazNtFmjFIR+CMKyA3NqbI9KrYZ9W3/ax0+MC
# Xp2Kzmm1YTAYbZU=
# SIG # End signature block
