#Requires -Version 7.0
[CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact='High')]
param(
  [string]$Thumbprint,
  [string]$OutDir = (Join-Path -Path $PWD -ChildPath 'out\test-codesign'),
  [string]$PfxPath,
  [switch]$DeleteGhSecrets,
  [string[]]$Environments = @('codesign-dev','codesign-prod'),
  [switch]$Force
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
if (-not $IsWindows) { throw "This script requires Windows." }

function Normalize-Thumb([string]$t) {
  if (-not $t) { return $null }
  ($t -replace '\s','').ToUpperInvariant()
}

function Resolve-PfxAndPassword {
  param([string]$OutDir,[string]$PfxPath)
  $pwdPathCandidates = @(
    (Join-Path $OutDir 'WIN_CODESIGN_PFX_PASSWORD.txt')
  )
  $pfxFile = $null

  if ($PfxPath) {
    if (-not (Test-Path -LiteralPath $PfxPath)) { throw "Specified PFX not found: $PfxPath" }
    $pfxFile = Get-Item -LiteralPath $PfxPath
  } else {
    if (-not (Test-Path -LiteralPath $OutDir)) { return $null }
    $pfxFile = Get-ChildItem -LiteralPath $OutDir -Filter 'test-codesign-*.pfx' -File -ErrorAction SilentlyContinue |
               Sort-Object LastWriteTime -Descending | Select-Object -First 1
  }
  if (-not $pfxFile) { return $null }

  $pwdFile = $pwdPathCandidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
  if (-not $pwdFile) { throw "Password file not found in $OutDir (expected WIN_CODESIGN_PFX_PASSWORD.txt)." }

  [pscustomobject]@{
    PfxPath = $pfxFile.FullName
    Password = (Get-Content -LiteralPath $pwdFile -Raw)
  }
}

function Resolve-Thumbprint {
  param([string]$Thumbprint,[string]$OutDir,[string]$PfxPath)
  $t = Normalize-Thumb $Thumbprint
  if ($t) { return $t }

  $p = Resolve-PfxAndPassword -OutDir $OutDir -PfxPath $PfxPath
  if (-not $p) { return $null }

  try {
    $bytes = [IO.File]::ReadAllBytes($p.PfxPath)
    $cert  = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2
    $cert.Import($bytes, $p.Password,
      [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::EphemeralKeySet)
    return (Normalize-Thumb $cert.Thumbprint)
  } catch {
    throw "Failed to derive thumbprint from PFX '$($p.PfxPath)': $($_.Exception.Message)"
  }
}

$resolvedThumb = Resolve-Thumbprint -Thumbprint $Thumbprint -OutDir $OutDir -PfxPath $PfxPath
if (-not $resolvedThumb) {
  throw "Could not resolve a certificate thumbprint. Provide -Thumbprint, or ensure $OutDir has a 'test-codesign-*.pfx' and 'WIN_CODESIGN_PFX_PASSWORD.txt'."
}

# --- Remove certificate from CurrentUser\My ---
$certPath = "Cert:\\CurrentUser\\My\\$resolvedThumb"
$removedCert = $false
if (Test-Path -LiteralPath $certPath) {
  if ($PSCmdlet.ShouldProcess("Delete certificate $resolvedThumb from CurrentUser\\My", "Remove-Item $certPath")) {
    try {
      Remove-Item -LiteralPath $certPath -Force
      $removedCert = $true
    } catch {
      # Fallback to certutil
      try {
        & certutil -user -delstore My $resolvedThumb | Out-Null
        $removedCert = $true
      } catch {
        Write-Warning "Failed to delete cert $resolvedThumb from store: $($_.Exception.Message)"
      }
    }
  }
} else {
  Write-Host "No matching cert in CurrentUser\\My (thumbprint $resolvedThumb)."
}

# --- Collect files to delete ---
$files = @()

if ($PfxPath -and (Test-Path -LiteralPath $PfxPath)) {
  $files += (Get-Item -LiteralPath $PfxPath).FullName
} elseif (Test-Path -LiteralPath $OutDir) {
  $files += (Get-ChildItem -LiteralPath $OutDir -Filter 'test-codesign-*.pfx' -File -ErrorAction SilentlyContinue |
             Select-Object -ExpandProperty FullName)
}

$sidecars = @(
  (Join-Path $OutDir 'WIN_CODESIGN_PFX_B64.txt'),
  (Join-Path $OutDir 'WIN_CODESIGN_PFX_PASSWORD.txt'),
  (Join-Path $OutDir 'test-codesign.pfx.b64'),
  (Join-Path $OutDir 'secrets.json'),
  (Join-Path $OutDir 'secrets.env')
)
$files += ($sidecars | Where-Object { Test-Path -LiteralPath $_ })

$files = $files | Select-Object -Unique

# --- Delete files ---
$deleted = New-Object System.Collections.Generic.List[string]
foreach ($f in $files) {
  if ($PSCmdlet.ShouldProcess("Delete file", $f)) {
    try {
      Remove-Item -LiteralPath $f -Force:$Force -ErrorAction Stop
      $deleted.Add($f) | Out-Null
    } catch {
      Write-Warning "Failed to delete $f: $($_.Exception.Message)"
    }
  }
}

# --- Optionally delete env secrets with gh ---
$secretsDeleted = @()
if ($DeleteGhSecrets) {
  if (-not (Get-Command gh -ErrorAction SilentlyContinue)) {
    Write-Warning "gh CLI not found; skipping environment secret deletion."
  } else {
    $names = @('WIN_CODESIGN_PFX_B64','WIN_CODESIGN_PFX_PASSWORD')
    foreach ($envName in $Environments) {
      foreach ($n in $names) {
        if ($PSCmdlet.ShouldProcess("Delete env secret", "$n (env=$envName)")) {
          try {
            $p = Start-Process -FilePath "gh" -ArgumentList @("secret","delete",$n,"--env",$envName,"--yes") `
                               -NoNewWindow -PassThru -Wait
            if ($p.ExitCode -eq 0) { $secretsDeleted += "$envName/$n" }
          } catch {
            Write-Warning "Failed to delete secret $n in env $envName: $($_.Exception.Message)"
          }
        }
      }
    }
  }
}

# --- Summary ---
Write-Host ""
Write-Host "Cleanup summary" -ForegroundColor Cyan
Write-Host ("  Thumbprint removed from store : {0}" -f ($removedCert ? $resolvedThumb : 'not found / not removed'))
if ($deleted.Count -gt 0) {
  Write-Host "  Files deleted:"; $deleted | ForEach-Object { Write-Host "    - $_" }
} else {
  Write-Host "  Files deleted: (none)"
}
if ($DeleteGhSecrets) {
  if ($secretsDeleted.Count -gt 0) {
    Write-Host "  Env secrets deleted:"; $secretsDeleted | ForEach-Object { Write-Host "    - $_" }
  } else {
    Write-Host "  Env secrets deleted: (none)"
  }
}


# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCC9+YAS6eyMazrc
# OORVNfBB8W9nXf2463upesKl4YoPNKCCAxYwggMSMIIB+qADAgECAhAtm/SxXUET
# uEmxvLNVOiC5MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMjE1NDM3WhcNMjUxMTI3MjIwNDM3WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAxd/sydsliCPS3KELyeSerxe4XojufCU7HeSQUrIw0nzG
# CozqXgb0Ro9IHDjysfK8qV8y3wnboxe49zg0JK0z9ICtIp7pFBOgbE4r7cIjB2VX
# WxlgmkI11AFBz8YT5gLTzRJYMh/xelewmdqmXnL96lmHzjglMD0kBKJIFCR1+czs
# OX2aPiLk77ZTUPPC80H4hq9jao+jfmwkZ11DSLNGsjP8bfiv4qhi7wblrPQuAMBR
# h6imOHfI2UxOoZbrZMU24gFSjmdFVZxkL1nVYpsOVPz8sUjEapGs7hzyd/+Di16W
# q/C1hMqmLyr7OCmYxXxSwMHgL4lHzfaflUY2qQTwPQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFESWXrkYB+iP
# E74gZD0nisZjkAsNMA0GCSqGSIb3DQEBCwUAA4IBAQBoxm+gfY/JqcldQo7Nh2Dl
# XlglmjfMrC7/MCBRuWKvR5sYa5uniPSg9/BcxCUD781L6StPX3iN+5l9T0Sli8aA
# kS52NfDA3p0au4cw+KCkMP1lgnMiKV/3iOgfmiu69zW+1CrdE4NdGD+sWlfVq5U5
# JNOJICCaf8rSXbjb/czWbBTCgUxvPbgyaRYFqxwiNTNdE/NMfT/FpACWoIWrUi0s
# HADCp6a/E6DviiLKWdLRkpNtzoZug3nifQlqG9DfOyO01itthyncvws89B/JPIn6
# VGDzDF8G1AJTgpg6f/VMZMFL71yVAm06tC6b9WTW9bb6t7UKjpn9kx+RWJtF0Tsz
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAtm/SxXUETuEmxvLNVOiC5MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIHdtx8lNxvdE
# GwQraeAY4Y6icbWBMysq/r8X9ubdHLmOMA0GCSqGSIb3DQEBAQUABIIBABNsPxbG
# tPuXMWRa6w0SFWiTybib703AVpmRU+5SzxlsMBN1H2VgxYaZ+/pclvY8YFLQOvl9
# qylWnXTkTc6mrJ22uoouCM3wViJsKrS0SRi0GyDfl8/Q/hO1v02UdYFiSlZBb7PA
# QbcqAv0XWyNYxaSsIfo2q1qw7+g7nTkKG6Mr2A4H4lqLgjEP6e3YGXFY7iBDIYQ+
# udLRi87YtF+S+hPOYdAL2yxD3tSZcsOsynL5sKeJpo7PhHMz8xtiq7+spGMlip7S
# XmGTiagdjLpY8zgly0bgd2RWojZcSD+7elti/48lwRDMOOIfFx2g3jcOMoctRkwY
# AyM2Te9GbRwBcs4=
# SIG # End signature block
