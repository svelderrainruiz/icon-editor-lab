#Requires -Version 7.0
[CmdletBinding()]
param(
    [string]$Root = 'out/semver-bundle'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$rootPath = [System.IO.Path]::GetFullPath($Root)
if (-not (Test-Path -LiteralPath $rootPath -PathType Container)) {
    throw "[SVB300] No SemVer bundles found under $rootPath"
}

$bundle = Get-ChildItem -LiteralPath $rootPath -Directory | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $bundle) {
    throw "[SVB300] No SemVer bundles found under $rootPath"
}

$summaryPath = Join-Path $bundle.FullName 'semver-summary.json'
$summary = $null
if (Test-Path -LiteralPath $summaryPath -PathType Leaf) {
    try {
        $summary = Get-Content -LiteralPath $summaryPath -Raw | ConvertFrom-Json -ErrorAction Stop
    } catch {
        Write-Warning ("[SVB202] Failed to read summary JSON: {0}" -f $_.Exception.Message)
    }
}

[pscustomobject]@{
    BundleRoot = $bundle.FullName
    ZipPath    = "$($bundle.FullName).zip"
    Summary    = $summary
}

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDX1yHpgv4n6QSq
# t5kkJikX+boV/u0FrptEuQebx9o3l6CCAxYwggMSMIIB+qADAgECAhAtm/SxXUET
# uEmxvLNVOiC5MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMjE1NDM3WhcNMjUxMTI3MjIwNDM3WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAxd/sydsliCPS3KELyeSerxe4XojufCU7HeSQUrIw0nzG
# CozqXgb0Ro9IHDjysfK8qV8y3wnboxe49zg0JK0z9ICtIp7pFBOgbE4r7cIjB2VX
# WxlgmkI11AFBz8YT5gLTzRJYMh/xelewmdqmXnL96lmHzjglMD0kBKJIFCR1+czs
# OX2aPiLk77ZTUPPC80H4hq9jao+jfmwkZ11DSLNGsjP8bfiv4qhi7wblrPQuAMBR
# h6imOHfI2UxOoZbrZMU24gFSjmdFVZxkL1nVYpsOVPz8sUjEapGs7hzyd/+Di16W
# q/C1hMqmLyr7OCmYxXxSwMHgL4lHzfaflUY2qQTwPQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFESWXrkYB+iP
# E74gZD0nisZjkAsNMA0GCSqGSIb3DQEBCwUAA4IBAQBoxm+gfY/JqcldQo7Nh2Dl
# XlglmjfMrC7/MCBRuWKvR5sYa5uniPSg9/BcxCUD781L6StPX3iN+5l9T0Sli8aA
# kS52NfDA3p0au4cw+KCkMP1lgnMiKV/3iOgfmiu69zW+1CrdE4NdGD+sWlfVq5U5
# JNOJICCaf8rSXbjb/czWbBTCgUxvPbgyaRYFqxwiNTNdE/NMfT/FpACWoIWrUi0s
# HADCp6a/E6DviiLKWdLRkpNtzoZug3nifQlqG9DfOyO01itthyncvws89B/JPIn6
# VGDzDF8G1AJTgpg6f/VMZMFL71yVAm06tC6b9WTW9bb6t7UKjpn9kx+RWJtF0Tsz
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAtm/SxXUETuEmxvLNVOiC5MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIEYBD5Y3r8tS
# z19YGGp/FTByrUm5EHI8CkcR3OTA0txvMA0GCSqGSIb3DQEBAQUABIIBALK+vXaZ
# cz8smR7jr8Dzmlthy0fuZ8FGHm7cgAS+qdafNxQ8YwAFFF8EjJEf5nyuQKysM3MW
# 7PIEKicuDSEpjdrAvdYC44a18GSfpD6JJBTfSLHXrYYywUFw96s3/CdFdvV624A0
# HdHBXa0fc7aNRnwnv+8lJm9Sf39bRE+jopBtYGhxRJEoVfQzFXtu3YdyyaFfa3wm
# 8a1JrVYia4fgrjPWvlhCGfxp6Tbi9PwXxsZ6PD+bDf7MGpxml1iMt39TY4DigTeo
# 6rDuqe6xk/7MFxvmnawbtrcQz9IVDbRYm4+p3mU88SpdVw9zsQXc3TT2dQaeeOrg
# dSRtlDZxBQ+ZsPo=
# SIG # End signature block
