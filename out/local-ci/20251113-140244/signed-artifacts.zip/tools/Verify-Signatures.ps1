# Verify-Signatures.ps1
[CmdletBinding()]
param(
  [Parameter()][string]$SearchRoot = (Get-Location).Path,
  [Parameter()][string[]]$Include = @("*.ps1","*.psm1"),
  [Parameter()][string[]]$ExcludeDirs = @(".git",".github",".venv","node_modules")
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'
$files = Get-ChildItem -LiteralPath $SearchRoot -Recurse -File -Include $Include | Where-Object {
  $rel = $_.FullName.Substring($SearchRoot.Length).TrimStart('\','/')
  -not ($ExcludeDirs | ForEach-Object { $rel -like ("{0}\*" -f $_) })
}
$bad = @()
foreach ($f in $files) {
  $sig = Get-AuthenticodeSignature -LiteralPath $f.FullName
  if ($sig.Status -ne 'Valid') { $bad += [pscustomobject]@{ Path = $f.FullName; Status = $sig.Status } }
}
if ($bad.Count -gt 0) {
  $bad | Format-Table -AutoSize | Out-String | Write-Output
  throw "Signature check failed for $($bad.Count) file(s)."
}
Write-Output "All script signatures are VALID."

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDA5chJevy6MGSV
# tHJMuyIwbEkqLQdD7aRYKil20DYfiaCCAxYwggMSMIIB+qADAgECAhAtm/SxXUET
# uEmxvLNVOiC5MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMjE1NDM3WhcNMjUxMTI3MjIwNDM3WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAxd/sydsliCPS3KELyeSerxe4XojufCU7HeSQUrIw0nzG
# CozqXgb0Ro9IHDjysfK8qV8y3wnboxe49zg0JK0z9ICtIp7pFBOgbE4r7cIjB2VX
# WxlgmkI11AFBz8YT5gLTzRJYMh/xelewmdqmXnL96lmHzjglMD0kBKJIFCR1+czs
# OX2aPiLk77ZTUPPC80H4hq9jao+jfmwkZ11DSLNGsjP8bfiv4qhi7wblrPQuAMBR
# h6imOHfI2UxOoZbrZMU24gFSjmdFVZxkL1nVYpsOVPz8sUjEapGs7hzyd/+Di16W
# q/C1hMqmLyr7OCmYxXxSwMHgL4lHzfaflUY2qQTwPQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFESWXrkYB+iP
# E74gZD0nisZjkAsNMA0GCSqGSIb3DQEBCwUAA4IBAQBoxm+gfY/JqcldQo7Nh2Dl
# XlglmjfMrC7/MCBRuWKvR5sYa5uniPSg9/BcxCUD781L6StPX3iN+5l9T0Sli8aA
# kS52NfDA3p0au4cw+KCkMP1lgnMiKV/3iOgfmiu69zW+1CrdE4NdGD+sWlfVq5U5
# JNOJICCaf8rSXbjb/czWbBTCgUxvPbgyaRYFqxwiNTNdE/NMfT/FpACWoIWrUi0s
# HADCp6a/E6DviiLKWdLRkpNtzoZug3nifQlqG9DfOyO01itthyncvws89B/JPIn6
# VGDzDF8G1AJTgpg6f/VMZMFL71yVAm06tC6b9WTW9bb6t7UKjpn9kx+RWJtF0Tsz
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAtm/SxXUETuEmxvLNVOiC5MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIIEZpCeYMGc2
# kHxmC59rnv7kFfu0+1EDOsevLQv84+74MA0GCSqGSIb3DQEBAQUABIIBAGGtZgTu
# fKdjUTN4tnGlzOn+Wpozn9u0n+aTm4gNxVHuAgnoHea18CgO7W7pFeB6mek/N95o
# cIWIJDF95+dtIPJS5WPNX2Xs89ngHt2b9XQkhj/hQ4GQq/LZVAsm0QgLuh+DqF/T
# 2u4FOhmYAxpLXiw0mQLsawCsO3gcr4ClOVOvK/y+PLsj35loetk5MnZag70C78Gh
# TCLe3N/XhScdm8d3ElAkge1MSv0PbkEwFKZtIYzhFG/1aqQ1XR9FFKGQLI4CDK4z
# HgNnZbL0NZu2SLopsg9hORYYMRcbZ11fROOmiVcEuIuU1n9PGp0GuVyV4SHYnSWT
# +udXrmlS12SzSD8=
# SIG # End signature block
