# Secure-Process.psm1
Set-StrictMode -Version Latest
. (Join-Path $PSScriptRoot 'Validate-Paths.ps1')
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Invoke-ProcessSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$FilePath,
        [Parameter()][string[]]$ArgumentList = @(),
        [Parameter()][int]$TimeoutSec = 600,
        [Parameter()][string]$WorkingDirectory = (Get-Location).Path
    )
    if (-not (Test-Path -LiteralPath $FilePath -PathType Leaf)) { throw "FilePath not found: $FilePath" }
    $psi = [System.Diagnostics.ProcessStartInfo]::new()
    $psi.FileName = $FilePath
    $psi.WorkingDirectory = (Validate-PathSafe -Path $WorkingDirectory)
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.UseShellExecute = $false
    foreach ($a in $ArgumentList) { $null = $psi.ArgumentList.Add($a) }

    $p = [System.Diagnostics.Process]::new()
    $p.StartInfo = $psi
    if (-not $p.Start()) { throw "Failed to start process: $FilePath" }
    try {
        if (-not $p.WaitForExit($TimeoutSec * 1000)) {
            try { $p.Kill($true) } catch {}
            throw "Process timed out after $TimeoutSec s: $FilePath"
        }
        $stdout = $p.StandardOutput.ReadToEnd()
        $stderr = $p.StandardError.ReadToEnd()
        return [pscustomobject]@{
            ExitCode = $p.ExitCode
            StdOut = $stdout
            StdErr = $stderr
        }
    } finally {
        if (-not $p.HasExited) { try { $p.Kill($true) } catch {} }
        $p.Dispose()
    }
}
Export-ModuleMember -Function Invoke-ProcessSafe

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDLM/hZ77J6ko3k
# J1T1SnSI3Zjg9T8EF5sOyyHIvgXLgqCCAxYwggMSMIIB+qADAgECAhAtm/SxXUET
# uEmxvLNVOiC5MA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMjE1NDM3WhcNMjUxMTI3MjIwNDM3WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAxd/sydsliCPS3KELyeSerxe4XojufCU7HeSQUrIw0nzG
# CozqXgb0Ro9IHDjysfK8qV8y3wnboxe49zg0JK0z9ICtIp7pFBOgbE4r7cIjB2VX
# WxlgmkI11AFBz8YT5gLTzRJYMh/xelewmdqmXnL96lmHzjglMD0kBKJIFCR1+czs
# OX2aPiLk77ZTUPPC80H4hq9jao+jfmwkZ11DSLNGsjP8bfiv4qhi7wblrPQuAMBR
# h6imOHfI2UxOoZbrZMU24gFSjmdFVZxkL1nVYpsOVPz8sUjEapGs7hzyd/+Di16W
# q/C1hMqmLyr7OCmYxXxSwMHgL4lHzfaflUY2qQTwPQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFESWXrkYB+iP
# E74gZD0nisZjkAsNMA0GCSqGSIb3DQEBCwUAA4IBAQBoxm+gfY/JqcldQo7Nh2Dl
# XlglmjfMrC7/MCBRuWKvR5sYa5uniPSg9/BcxCUD781L6StPX3iN+5l9T0Sli8aA
# kS52NfDA3p0au4cw+KCkMP1lgnMiKV/3iOgfmiu69zW+1CrdE4NdGD+sWlfVq5U5
# JNOJICCaf8rSXbjb/czWbBTCgUxvPbgyaRYFqxwiNTNdE/NMfT/FpACWoIWrUi0s
# HADCp6a/E6DviiLKWdLRkpNtzoZug3nifQlqG9DfOyO01itthyncvws89B/JPIn6
# VGDzDF8G1AJTgpg6f/VMZMFL71yVAm06tC6b9WTW9bb6t7UKjpn9kx+RWJtF0Tsz
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAtm/SxXUETuEmxvLNVOiC5MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPEK5pYr/oiP
# 6zXDh72ZtLHO5VLyj1aDMXhTjDbbSs4wMA0GCSqGSIb3DQEBAQUABIIBAK8pGaso
# obaRZdFKpHTxoH7mq0/cR/pZcYIF7zSZWJv2eK6OR48ZYyFU0qc46LUy7M0xptLZ
# jkuqTdb5ILM1kTsTbR8pqOhnuSpjLg0ol8BG3tdLI7r9hzozH3CuqlUR3xtxtFRm
# ouRJhM3ZwUqPS19W72J4bC96A1CMk6S75tBBLZgavhDcVmh0GplysVqMxcHZALHP
# YiIPm2ApZgqwrn6MTP5HzxItwwdZtQcHV7bg2YEnvdCV6kP1VA4Hxz6N8rUNCUz7
# n718pE3hbX2SAAI0wQf6OHtS5vCLBo0rQpQHQXyDhg6NqQQrn1p5t94Wp+o+u4O0
# 6h5DlutTfcrhjsY=
# SIG # End signature block
