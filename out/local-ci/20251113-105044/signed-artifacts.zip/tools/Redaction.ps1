# Redaction.ps1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Write-LogSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Message,
        [Parameter()][ValidateSet('INFO','WARN','ERROR')][string]$Level = 'INFO'
    )
    # Redact common secret/token patterns (simple heuristic)
    $msg = $Message -replace '([A-Za-z0-9-_]{20,})','****' `
                    -replace '(?i)(secret|token|password)\s*[:=]\s*[^ \t\r\n]+','$1=****'
    $ts = (Get-Date).ToString('s')
    Write-Output "[$ts][$Level] $msg"
}
if ($ExecutionContext.SessionState.Module) {
    Export-ModuleMember -Function Write-LogSafe
}

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCB5QE8/zfwZTTR5
# g9if2C7NwESBApxi1XkQIcw6fBWi3aCCAxYwggMSMIIB+qADAgECAhAWsJZaGEbb
# kE7aZcU2O38bMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTg0MjM0WhcNMjUxMTI3MTg1MjM0WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA6Igz7a8RZRAVwDW7SS1gN1FPvXA1m0Q/XygjxkTfk2jt
# r5CZ0BHSDmOEYg2vb6AN6VlxlLZLqUDkKdFCEuvaWkQqDNkqUpxsjoQWGAZP3SuW
# czKJJrdVtIcEJmXfch5Ur/8L+KgM6yjT6YgX+oj3wK4v/J+hW76pR8WxXOa+1Ug9
# ASRrFiqXffTM/NpKXszJMRbyuujAvLAnasw0O+g35dUCYOtTAPE+PvQvu+kUl8YD
# xpE8Lxr1564Gub/tdC+QegtiiImpXBy5yFEAiJ5YoE1I3jJFfPYAJGItfilLy+5x
# qKtzUgoEvUEwhl0QCy2iWe8XkxF+65G3jByaF4xYVQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFCJBsgEqkkT9
# 0cYIKTZJbhcHVPjgMA0GCSqGSIb3DQEBCwUAA4IBAQCz2cNJ/4qbUSlegViRugEm
# kgY2FShovr7ZrVpbTdVevcGDxAytsxel4drDhFBZSZes3hYen0sayzi/JQzhH7FT
# RLv8zMRxpdW2pYlIb+qZ/m6vM+bj2saSnE2xSCPxPjSIGQI6xS33HPZV+5qkL0l7
# wHMiBcC8PXH3YLlGfJb8c23j8TtHei1xBIKdNAGDqswRufdJmvM18yYeYXnrwGon
# ehPEZDBGSnJx3qaAuqf3NRdC/2I5aJYR1ubPRQnDnYqhy1CwGxLjZULvu+qNgwTv
# xoKWGWbmnAIHodNTxsSwALsmTkDYz+qg6qkDKooiik79zcROUcTQRO5mpEEcWVKT
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAWsJZaGEbbkE7aZcU2O38bMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIEfHLCIlw9Py
# EI3fUHQlFhw4tq7Q+oRZQIlIetQ/aFBMMA0GCSqGSIb3DQEBAQUABIIBALy0uOv5
# x4BT1qiY7r262iQ0qcfyUqgX/VVVr/V+Grc042OgphhMwzTr2mBk+nXYat5eFG6B
# A3CTitD+FCEWA1iO1iSWIVcC9/y/MMFnEkypKIeGdnYcQNoWd4nwn1NJyrPGxiNS
# utiEZcYe1Zz/4FlPJFXnw2I+79UcyjG/wCmDr57LzfSk8BjsMcZSYvGYPoZqy1oS
# iSmdTaFNovZTg7Qjv+r2rzDVt8LSPJaP4idZ/sLzLMS/wsbCK84NPonC2R0QZfn1
# GF/id+pkxbmcjPkwrTlwqQ4UAEJIRrypOO/CQatEcGnvHwb0f5B8TLGjMn46ASJN
# lyMVX9I+1CHeU5I=
# SIG # End signature block
