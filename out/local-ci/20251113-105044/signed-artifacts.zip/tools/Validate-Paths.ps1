# Validate-Paths.ps1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Test-PathSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter()][switch]$RequireAbsolute
    )
    if ($Path -match '[;&|`]' -or $Path -match '\.\.') { return $false }
    try {
        $rp = Resolve-Path -LiteralPath $Path -ErrorAction Stop
        if ($RequireAbsolute -and -not ($rp.Path -match '^(?:[A-Za-z]:[\\/]|/)')) { return $false }
        return $true
    } catch { return $false }
}

function Validate-PathSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter()][switch]$RequireAbsolute
    )
    if (-not (Test-PathSafe -Path $Path -RequireAbsolute:$RequireAbsolute)) {
        throw "Unsafe or invalid path: $Path"
    }
    return (Resolve-Path -LiteralPath $Path).Path
}

Export-ModuleMember -Function Test-PathSafe, Validate-PathSafe

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBRKRGFgRiwJrUW
# ser+RbKUtmM3v2Ar6IG3lNNJMXHBxaCCAxYwggMSMIIB+qADAgECAhAWsJZaGEbb
# kE7aZcU2O38bMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTg0MjM0WhcNMjUxMTI3MTg1MjM0WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA6Igz7a8RZRAVwDW7SS1gN1FPvXA1m0Q/XygjxkTfk2jt
# r5CZ0BHSDmOEYg2vb6AN6VlxlLZLqUDkKdFCEuvaWkQqDNkqUpxsjoQWGAZP3SuW
# czKJJrdVtIcEJmXfch5Ur/8L+KgM6yjT6YgX+oj3wK4v/J+hW76pR8WxXOa+1Ug9
# ASRrFiqXffTM/NpKXszJMRbyuujAvLAnasw0O+g35dUCYOtTAPE+PvQvu+kUl8YD
# xpE8Lxr1564Gub/tdC+QegtiiImpXBy5yFEAiJ5YoE1I3jJFfPYAJGItfilLy+5x
# qKtzUgoEvUEwhl0QCy2iWe8XkxF+65G3jByaF4xYVQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFCJBsgEqkkT9
# 0cYIKTZJbhcHVPjgMA0GCSqGSIb3DQEBCwUAA4IBAQCz2cNJ/4qbUSlegViRugEm
# kgY2FShovr7ZrVpbTdVevcGDxAytsxel4drDhFBZSZes3hYen0sayzi/JQzhH7FT
# RLv8zMRxpdW2pYlIb+qZ/m6vM+bj2saSnE2xSCPxPjSIGQI6xS33HPZV+5qkL0l7
# wHMiBcC8PXH3YLlGfJb8c23j8TtHei1xBIKdNAGDqswRufdJmvM18yYeYXnrwGon
# ehPEZDBGSnJx3qaAuqf3NRdC/2I5aJYR1ubPRQnDnYqhy1CwGxLjZULvu+qNgwTv
# xoKWGWbmnAIHodNTxsSwALsmTkDYz+qg6qkDKooiik79zcROUcTQRO5mpEEcWVKT
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAWsJZaGEbbkE7aZcU2O38bMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEINpvsU+HHb6K
# gYnFC+DOD7Pi21ghNNfHTvYHF7x5UIBMMA0GCSqGSIb3DQEBAQUABIIBAAOZjEdQ
# cuDyZwy6tsAd9MQTmsB7+TeqvTfzvjUcHKlMUPDZ44pbmVS1HosMF0Hao+4CNKwe
# tnfFRLO14V9cY3Vu2pXXkihE+WcPzmWFPkeroEecVbABqnX5TvOI1gjah8yahcIk
# uSd7k82Ws3Mg9cvUZJ7LM5vae4YoLTQ2vJ4NiST+PtLZi6a210UqGqyCV5uBO96y
# cS8D2DPt9CkLaRaxwzi/yHfFXn1YxZwp2IkBPEIic86Q59tlt76Kbbte830Qih/I
# qwV9AWeN52s+vtxM4Smh5cdjfw7WNAvmjRj9lAM4daE4rYBnHKFJ7KSPKL53TWEp
# iYJowshMjsnhYJM=
# SIG # End signature block
