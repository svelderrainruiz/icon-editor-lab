# Verify-Signatures.ps1
[CmdletBinding()]
param(
  [Parameter()][string]$SearchRoot = (Get-Location).Path,
  [Parameter()][string[]]$Include = @("*.ps1","*.psm1"),
  [Parameter()][string[]]$ExcludeDirs = @(".git",".github",".venv","node_modules")
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'
$files = Get-ChildItem -LiteralPath $SearchRoot -Recurse -File -Include $Include | Where-Object {
  $rel = $_.FullName.Substring($SearchRoot.Length).TrimStart('\','/')
  -not ($ExcludeDirs | ForEach-Object { $rel -like ("{0}\*" -f $_) })
}
$bad = @()
foreach ($f in $files) {
  $sig = Get-AuthenticodeSignature -LiteralPath $f.FullName
  if ($sig.Status -ne 'Valid') { $bad += [pscustomobject]@{ Path = $f.FullName; Status = $sig.Status } }
}
if ($bad.Count -gt 0) {
  $bad | Format-Table -AutoSize | Out-String | Write-Output
  throw "Signature check failed for $($bad.Count) file(s)."
}
Write-Output "All script signatures are VALID."

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDA5chJevy6MGSV
# tHJMuyIwbEkqLQdD7aRYKil20DYfiaCCAxYwggMSMIIB+qADAgECAhAWsJZaGEbb
# kE7aZcU2O38bMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTg0MjM0WhcNMjUxMTI3MTg1MjM0WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA6Igz7a8RZRAVwDW7SS1gN1FPvXA1m0Q/XygjxkTfk2jt
# r5CZ0BHSDmOEYg2vb6AN6VlxlLZLqUDkKdFCEuvaWkQqDNkqUpxsjoQWGAZP3SuW
# czKJJrdVtIcEJmXfch5Ur/8L+KgM6yjT6YgX+oj3wK4v/J+hW76pR8WxXOa+1Ug9
# ASRrFiqXffTM/NpKXszJMRbyuujAvLAnasw0O+g35dUCYOtTAPE+PvQvu+kUl8YD
# xpE8Lxr1564Gub/tdC+QegtiiImpXBy5yFEAiJ5YoE1I3jJFfPYAJGItfilLy+5x
# qKtzUgoEvUEwhl0QCy2iWe8XkxF+65G3jByaF4xYVQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFCJBsgEqkkT9
# 0cYIKTZJbhcHVPjgMA0GCSqGSIb3DQEBCwUAA4IBAQCz2cNJ/4qbUSlegViRugEm
# kgY2FShovr7ZrVpbTdVevcGDxAytsxel4drDhFBZSZes3hYen0sayzi/JQzhH7FT
# RLv8zMRxpdW2pYlIb+qZ/m6vM+bj2saSnE2xSCPxPjSIGQI6xS33HPZV+5qkL0l7
# wHMiBcC8PXH3YLlGfJb8c23j8TtHei1xBIKdNAGDqswRufdJmvM18yYeYXnrwGon
# ehPEZDBGSnJx3qaAuqf3NRdC/2I5aJYR1ubPRQnDnYqhy1CwGxLjZULvu+qNgwTv
# xoKWGWbmnAIHodNTxsSwALsmTkDYz+qg6qkDKooiik79zcROUcTQRO5mpEEcWVKT
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAWsJZaGEbbkE7aZcU2O38bMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIIEZpCeYMGc2
# kHxmC59rnv7kFfu0+1EDOsevLQv84+74MA0GCSqGSIb3DQEBAQUABIIBAJAArscq
# S46SnO+zrYiFhgYsLQGQMZoHyLjZMFyDUBclvkImnU/ctonPxuWIMs9HmQEB2f6q
# 8FfwoE7XpBnzpilzukMfIWZ+W+WHS0SUMp5s4i6e1xRNeFr/aYxuhb6RXC/U2qfN
# r6c2DiHfd762B1AOLvlH8PFjSkJWhsQ/atyMSc4qgc6OO7hqzVpW/m+ecuffc2lP
# eEiT9y2rf5vWlGtTPk6/9CTcUVIuWBP1cs5O+u5N3vDDxSKtAqBkt7kHNNxI8QI2
# Ty16GlEyfmEa/nzc3skWmbA4oCg9+NoVtUSbblRJeETMmlifENw0Hz2SlnbKF5uM
# LPig9NYgHFSxHF0=
# SIG # End signature block
