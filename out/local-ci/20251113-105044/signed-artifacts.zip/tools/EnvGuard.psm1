# EnvGuard.psm1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'

function Get-EnvSnapshot {
    [CmdletBinding()]
    param([string[]]$AllowList = @('PATH','TEMP','TMP','HOME','USERPROFILE'))
    $snap = @{}
    foreach ($name in [Environment]::GetEnvironmentVariables().Keys) {
        if ($AllowList -contains $name) { $snap[$name] = [Environment]::GetEnvironmentVariable($name,'Process') }
    }
    return $snap
}

function Set-EnvFromSnapshot {
    [CmdletBinding()]
    param([Parameter(Mandatory)][hashtable]$Snapshot)
    foreach ($k in $Snapshot.Keys) {
        [Environment]::SetEnvironmentVariable($k, [string]$Snapshot[$k], 'Process')
    }
}

Export-ModuleMember -Function Get-EnvSnapshot, Set-EnvFromSnapshot

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAzwwfWBljXiDkz
# 9AHE9bg618B2oMEor3Mbt2BkcXsxKKCCAxYwggMSMIIB+qADAgECAhAWsJZaGEbb
# kE7aZcU2O38bMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTg0MjM0WhcNMjUxMTI3MTg1MjM0WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA6Igz7a8RZRAVwDW7SS1gN1FPvXA1m0Q/XygjxkTfk2jt
# r5CZ0BHSDmOEYg2vb6AN6VlxlLZLqUDkKdFCEuvaWkQqDNkqUpxsjoQWGAZP3SuW
# czKJJrdVtIcEJmXfch5Ur/8L+KgM6yjT6YgX+oj3wK4v/J+hW76pR8WxXOa+1Ug9
# ASRrFiqXffTM/NpKXszJMRbyuujAvLAnasw0O+g35dUCYOtTAPE+PvQvu+kUl8YD
# xpE8Lxr1564Gub/tdC+QegtiiImpXBy5yFEAiJ5YoE1I3jJFfPYAJGItfilLy+5x
# qKtzUgoEvUEwhl0QCy2iWe8XkxF+65G3jByaF4xYVQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFCJBsgEqkkT9
# 0cYIKTZJbhcHVPjgMA0GCSqGSIb3DQEBCwUAA4IBAQCz2cNJ/4qbUSlegViRugEm
# kgY2FShovr7ZrVpbTdVevcGDxAytsxel4drDhFBZSZes3hYen0sayzi/JQzhH7FT
# RLv8zMRxpdW2pYlIb+qZ/m6vM+bj2saSnE2xSCPxPjSIGQI6xS33HPZV+5qkL0l7
# wHMiBcC8PXH3YLlGfJb8c23j8TtHei1xBIKdNAGDqswRufdJmvM18yYeYXnrwGon
# ehPEZDBGSnJx3qaAuqf3NRdC/2I5aJYR1ubPRQnDnYqhy1CwGxLjZULvu+qNgwTv
# xoKWGWbmnAIHodNTxsSwALsmTkDYz+qg6qkDKooiik79zcROUcTQRO5mpEEcWVKT
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAWsJZaGEbbkE7aZcU2O38bMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIJlQaYHytxsd
# hJ21/Xd1OOTWhUd4iNiRCRC/DDWxp9vgMA0GCSqGSIb3DQEBAQUABIIBAMkoqqxw
# Q26//6MNON1roieqhVkhTUwwBOZfeGM7ojgUyQ9dKSqOOTxsEOOc8aWrIwOnNyId
# udsvvWq7fVFiaM/YfUJjPbQJZLGtWwrYiW5tfD5zRa58Nv0Ljd14THyQMHy5JcjX
# CXBFG0UGl3Br1Uj0GopIuQIBGG9hOQnoi9+n9lkyH178KQQWWfDFrwudneYta9UI
# TnFlY4ykNiv7rsixW88Oji1yDUa3UMh4oMdizcZpzkvSzoec/T3zHz286X+9/50y
# rDjECYfFJ4OT0B5yi/kffVY1g43UmrRoPU4uuJRYZmTS39acUL/AnjM9EvJq+3Hf
# MqoEkhBWTVzxC3c=
# SIG # End signature block
