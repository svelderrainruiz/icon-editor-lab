# Sign-Scripts.ps1
[CmdletBinding()]
param(
  [Parameter()][string]$Thumbprint,
  [Parameter()][string]$SearchRoot = (Get-Location).Path,
  [Parameter()][string[]]$Include = @("*.ps1","*.psm1"),
  [Parameter()][string[]]$ExcludeDirs = @(".git",".github",".venv","node_modules"),
  [switch]$SkipTimestamp,
  [Parameter()][ValidateRange(1,1000)][int]$ProgressInterval = 25,
  [Parameter()][ValidateRange(0,1000)][int]$ThrottleMilliseconds = 0
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $PSModuleAutoLoadingPreference='None'
if (-not (Test-Path -LiteralPath $SearchRoot -PathType Container)) {
  throw "Search root not found: $SearchRoot"
}
Write-Host "Signing scripts under: $SearchRoot"
$includeMatchers = @(
  $Include | ForEach-Object {
    if ($_ -and $_.Trim()) {
      [System.Management.Automation.WildcardPattern]::new($_.Trim(),'IgnoreCase')
    }
  }
)
if ($includeMatchers.Count -eq 0) {
  $includeMatchers = @([System.Management.Automation.WildcardPattern]::new('*','IgnoreCase'))
}
function Get-GitTrackedFiles {
  param()
  $gitDir = Join-Path $SearchRoot '.git'
  if (-not (Test-Path -LiteralPath $gitDir -PathType Container)) {
    return @()
  }
  Push-Location $SearchRoot
  try {
    $arguments = @('ls-files','-z','--','*.ps1','*.psm1')
    $output = & git @arguments 2>$null
    if ($LASTEXITCODE -ne 0 -or -not $output) {
      return @()
    }
    return $output -split "`0" | Where-Object { $_ }
  }
  finally {
    Pop-Location
  }
}
function Get-CodeSigningCert {
  param([string]$Thumbprint)
  if ($Thumbprint) {
    $c = Get-ChildItem Cert:\CurrentUser\My\$Thumbprint -ErrorAction SilentlyContinue
    if ($c) { return $c }
  }
  $c = Get-ChildItem Cert:\CurrentUser\My | Where-Object { $_.HasPrivateKey -and $_.EnhancedKeyUsageList.FriendlyName -contains 'Code Signing' } | Select-Object -First 1
  if (-not $c) { throw 'No suitable code-signing certificate found.' }
  return $c
}
$cert = Get-CodeSigningCert -Thumbprint $Thumbprint
$gitCandidates = Get-GitTrackedFiles
if ($gitCandidates.Count -gt 0) {
  Write-Host ("Discovered {0} git-tracked candidate(s) via ls-files." -f $gitCandidates.Count)
  $candidates = @(
    $gitCandidates | ForEach-Object {
      $path = Join-Path $SearchRoot $_
      if (Test-Path -LiteralPath $path -PathType Leaf) { Get-Item -LiteralPath $path }
    } | Where-Object { $_ }
  )
}
else {
  Write-Host 'git ls-files returned no matches; falling back to filesystem enumeration.'
  $candidates = @(Get-ChildItem -LiteralPath $SearchRoot -Recurse -File)
}
Write-Host ("Discovered {0} candidate file(s) before filtering." -f $candidates.Count)
$files = @($candidates | Where-Object {
  $rel = $_.FullName.Substring($SearchRoot.Length).TrimStart('\','/')
  if ($ExcludeDirs | Where-Object { $rel -like ("{0}\*" -f $_) }) {
    return $false
  }
  foreach ($matcher in $includeMatchers) {
    if ($matcher.IsMatch($_.Name)) { return $true }
  }
  return $false
})
$total = $files.Count
if ($total -eq 0) {
  Write-Warning 'No files matched the signing criteria; nothing to do.'
  return
}
$stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
$processed = 0
foreach ($f in $files) {
  $sig = Get-AuthenticodeSignature -LiteralPath $f.FullName
  if ($sig.Status -ne 'Valid') {
    if ($SkipTimestamp) {
      Write-Verbose ("Signing {0} without timestamp (ephemeral cert)." -f $f.FullName)
      $null = Set-AuthenticodeSignature -LiteralPath $f.FullName -Certificate $cert
    }
    else {
      Write-Verbose ("Signing {0} with timestamp server." -f $f.FullName)
      $null = Set-AuthenticodeSignature -LiteralPath $f.FullName -Certificate $cert -TimestampServer 'http://timestamp.digicert.com'
    }
  }
  $processed++
  $logCheckpoint = ($ProgressInterval -gt 0) -and (($processed -eq 1) -or ($processed % $ProgressInterval -eq 0) -or ($processed -eq $total))
  if ($logCheckpoint) {
    Write-Host ("[{0}/{1}] Last signed: {2}" -f $processed, $total, $f.FullName)
  }
  if ($ThrottleMilliseconds -gt 0) {
    Start-Sleep -Milliseconds $ThrottleMilliseconds
  }
}
$stopwatch.Stop()
Write-Output ("Signed {0} script(s) in {1:n2}s." -f $processed, $stopwatch.Elapsed.TotalSeconds)

# SIG # Begin signature block
# MIIFpwYJKoZIhvcNAQcCoIIFmDCCBZQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDYpfv9H/2BrGi3
# 0MwBmTlEqdu/5KsCsUUBa2BGGZtVxKCCAxYwggMSMIIB+qADAgECAhAWsJZaGEbb
# kE7aZcU2O38bMA0GCSqGSIb3DQEBCwUAMCExHzAdBgNVBAMMFkNJIExvY2FsIHRy
# dXN0ZWQtbG9jYWwwHhcNMjUxMTEzMTg0MjM0WhcNMjUxMTI3MTg1MjM0WjAhMR8w
# HQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2FsMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEA6Igz7a8RZRAVwDW7SS1gN1FPvXA1m0Q/XygjxkTfk2jt
# r5CZ0BHSDmOEYg2vb6AN6VlxlLZLqUDkKdFCEuvaWkQqDNkqUpxsjoQWGAZP3SuW
# czKJJrdVtIcEJmXfch5Ur/8L+KgM6yjT6YgX+oj3wK4v/J+hW76pR8WxXOa+1Ug9
# ASRrFiqXffTM/NpKXszJMRbyuujAvLAnasw0O+g35dUCYOtTAPE+PvQvu+kUl8YD
# xpE8Lxr1564Gub/tdC+QegtiiImpXBy5yFEAiJ5YoE1I3jJFfPYAJGItfilLy+5x
# qKtzUgoEvUEwhl0QCy2iWe8XkxF+65G3jByaF4xYVQIDAQABo0YwRDAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFCJBsgEqkkT9
# 0cYIKTZJbhcHVPjgMA0GCSqGSIb3DQEBCwUAA4IBAQCz2cNJ/4qbUSlegViRugEm
# kgY2FShovr7ZrVpbTdVevcGDxAytsxel4drDhFBZSZes3hYen0sayzi/JQzhH7FT
# RLv8zMRxpdW2pYlIb+qZ/m6vM+bj2saSnE2xSCPxPjSIGQI6xS33HPZV+5qkL0l7
# wHMiBcC8PXH3YLlGfJb8c23j8TtHei1xBIKdNAGDqswRufdJmvM18yYeYXnrwGon
# ehPEZDBGSnJx3qaAuqf3NRdC/2I5aJYR1ubPRQnDnYqhy1CwGxLjZULvu+qNgwTv
# xoKWGWbmnAIHodNTxsSwALsmTkDYz+qg6qkDKooiik79zcROUcTQRO5mpEEcWVKT
# MYIB5zCCAeMCAQEwNTAhMR8wHQYDVQQDDBZDSSBMb2NhbCB0cnVzdGVkLWxvY2Fs
# AhAWsJZaGEbbkE7aZcU2O38bMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIBiG+2ADMClH
# s6Yi2OyfzhR1yY57aD5XUqXcEBcdbcrjMA0GCSqGSIb3DQEBAQUABIIBABasgoE0
# 500meglksaVeUzaTZfb82tMx2BukN91SPBSGDUhc+U2glJVN2nzkxgIaatqmsXgn
# vF7HpnXoIamrlh5EuKBl8XuBwR0LQheYoU1f8JWzSRdOQgFFA+mmZl7QRhZSS30t
# k6wTnCJG1vCXX7tWjrVhHCakw1PidNlIBlY9wIZ7+bHpKUkga+ZengtB8l2Ry5u4
# w1oswbdu+yrE4tekIkdNah1/+qoHWMMsqe8/mnE7EcDZ+mZwVJkqisbzzUN3cIAF
# RPeU/bmOKYIl+WDasiPhrd6aLfJj43kRt/4V15negZa7nOzehtTErjeuLWINTO+5
# mM8vR9+2GIjULHg=
# SIG # End signature block
