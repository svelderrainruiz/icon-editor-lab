## VI Comparison Report

Compared: 3 total, 0 same, 0 different, 0 skipped, 3 dry-run, 0 errors.

| VI | Status | Message | Artifacts |
| --- | --- | --- | --- |
| src/VIs/module_1.vi | dry-run |  | — |
| src/VIs/module_2.vi | dry-run |  | — |
| src/VIs/module_3.vi | dry-run |  | — |
