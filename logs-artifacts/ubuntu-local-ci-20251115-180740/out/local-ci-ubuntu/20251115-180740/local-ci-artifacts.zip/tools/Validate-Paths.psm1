. (Join-Path $PSScriptRoot 'Validate-Paths.ps1')
