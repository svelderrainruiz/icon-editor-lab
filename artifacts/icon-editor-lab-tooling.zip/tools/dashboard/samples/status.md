<!-- markdownlint-disable-next-line MD041 -->
# Session Samples

## Session Lock

- Status: acquired
- LockId: test-lock-id
- Group: pester-selfhosted
- Queue wait (s): 30
- File: tests/results/_session_lock/pester-selfhosted/lock.json
